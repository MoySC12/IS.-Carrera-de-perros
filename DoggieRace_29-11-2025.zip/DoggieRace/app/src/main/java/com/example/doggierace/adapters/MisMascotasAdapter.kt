package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.R
import com.example.doggierace.databinding.ItemMascotaBinding
import com.example.doggierace.data.entities.MascotaEntity

class MisMascotasAdapter(
    private val onItemClick: (MascotaEntity) -> Unit = {},
    private val onEditClick: ((MascotaEntity) -> Unit)? = null,
    private val onDeleteClick: ((MascotaEntity) -> Unit)? = null,
    private val onInscribirClick: ((MascotaEntity) -> Unit)? = null,
    private val onDesinscribirClick: ((MascotaEntity) -> Unit)? = null,
    private val modoInscripcion: Boolean = false,
    mascotasInscritasInicial: Set<Long> = emptySet()
) : ListAdapter<MascotaEntity, MisMascotasAdapter.MascotaViewHolder>(MascotaDiffCallback()) {

    // ✅ Variable mutable interna
    private var mascotasInscritas: Set<Long> = mascotasInscritasInicial

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MascotaViewHolder {
        val binding = ItemMascotaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MascotaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MascotaViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    // ✅ MÉTODO PARA ACTUALIZAR MASCOTAS INSCRITAS
    fun actualizarMascotasInscritas(nuevasInscritas: Set<Long>) {
        mascotasInscritas = nuevasInscritas
        notifyDataSetChanged() // Forzar actualización de todos los items
    }

    inner class MascotaViewHolder(
        private val binding: ItemMascotaBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(mascota: MascotaEntity) {
            binding.apply {
                // Nombre
                tvNombreMascota.text = mascota.nombre

                // Raza
                tvRazaMascota.text = mascota.raza

                // Edad y peso
                val detalles = "${mascota.edad} años • ${mascota.peso} kg"
                tvEdadPeso.text = detalles

                // Categoría según peso
                val categoria = when {
                    mascota.peso <= 15 -> "Pequeña"
                    mascota.peso <= 30 -> "Mediana"
                    mascota.peso <= 45 -> "Grande"
                    else -> "XL"
                }
                tvCategoriaMascota.text = categoria

                // ✅ MODO INSCRIPCIÓN CON BOTONES DINÁMICOS
                if (modoInscripcion) {
                    val estaInscrita = mascotasInscritas.contains(mascota.id)

                    if (estaInscrita) {
                        // ✅ Mascota YA inscrita: Mostrar botón "Eliminar"
                        btnInscribir.visibility = View.GONE
                        btnEditar.visibility = View.GONE
                        btnEliminar.visibility = View.VISIBLE
                        btnEliminar.text = "Desinscribir"
                        btnEliminar.setBackgroundColor(
                            binding.root.context.getColor(android.R.color.holo_red_light)
                        )
                        btnEliminar.setOnClickListener {
                            onDesinscribirClick?.invoke(mascota)
                        }
                    } else {
                        // ✅ NO inscrita: Mostrar botón "Inscribir"
                        btnInscribir.visibility = View.VISIBLE
                        btnEditar.visibility = View.GONE
                        btnEliminar.visibility = View.GONE
                        btnInscribir.setOnClickListener {
                            onInscribirClick?.invoke(mascota)
                        }
                    }
                } else {
                    // Modo normal (gestión de mascotas)
                    btnInscribir.visibility = View.GONE
                    btnEditar.visibility = if (onEditClick != null) View.VISIBLE else View.GONE
                    btnEliminar.visibility = if (onDeleteClick != null) View.VISIBLE else View.GONE

                    btnEditar.setOnClickListener {
                        onEditClick?.invoke(mascota)
                    }

                    btnEliminar.setOnClickListener {
                        onDeleteClick?.invoke(mascota)
                    }
                }

                // Click en la card completa
                root.setOnClickListener {
                    onItemClick(mascota)
                }
            }
        }
    }

    class MascotaDiffCallback : DiffUtil.ItemCallback<MascotaEntity>() {
        override fun areItemsTheSame(oldItem: MascotaEntity, newItem: MascotaEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: MascotaEntity, newItem: MascotaEntity): Boolean {
            return oldItem == newItem
        }
    }
}
