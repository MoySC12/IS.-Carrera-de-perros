package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentConfigPagosBinding
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.AdministradorViewModel
import kotlinx.coroutines.launch

class ConfigPagosFragment : Fragment() {

    private var _binding: FragmentConfigPagosBinding? = null
    private val binding get() = _binding!!

    private val administradorViewModel: AdministradorViewModel by viewModels()
    private lateinit var sessionManager: SessionManager
    private var organizadorId: Long = 0

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentConfigPagosBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())
        organizadorId = sessionManager.obtenerUserId()

        setupBancoDropdown()
        setupClickListeners()
        cargarDatosBancarios()
        observarResultados()
        setupToolbar()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun setupBancoDropdown() {
        val bancos = resources.getStringArray(R.array.bancos_array)
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            bancos
        )
        binding.actvBanco.setAdapter(adapter)
    }

    private fun setupClickListeners() {
        binding.btnGuardarCuenta.setOnClickListener {
            guardarCuenta()
        }
    }

    private fun cargarDatosBancarios() {
        lifecycleScope.launch {
            try {
                val organizador = administradorViewModel.obtenerAdministradorPorId(organizadorId)
                organizador?.let {
                    binding.etTitular.setText(it.titularCuenta ?: "")
                    binding.actvBanco.setText(it.banco ?: "", false)
                    binding.etClabe.setText(it.clabe ?: "")
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error al cargar datos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun guardarCuenta() {
        val titular = binding.etTitular.text.toString().trim()
        val banco = binding.actvBanco.text.toString().trim()
        val clabe = binding.etClabe.text.toString().trim()

        // Limpiar errores previos
        binding.inputLayoutTitular.error = null
        binding.inputLayoutBanco.error = null
        binding.inputLayoutClabe.error = null

        // Validación: Nombre del Titular
        if (titular.isEmpty()) {
            binding.inputLayoutTitular.error = "El nombre del titular es obligatorio"
            binding.etTitular.requestFocus()
            return
        }

        // Validación: Banco
        if (banco.isEmpty() || banco == "Selecciona un banco...") {
            binding.inputLayoutBanco.error = "Selecciona un banco"
            binding.actvBanco.requestFocus()
            return
        }

        // Validación: CLABE (debe tener exactamente 18 dígitos)
        if (clabe.length != 18 || !clabe.all { it.isDigit() }) {
            binding.inputLayoutClabe.error = "La CLABE debe tener 18 dígitos"
            binding.etClabe.requestFocus()
            return
        }

        // Guardar en base de datos
        administradorViewModel.actualizarCuentaBancaria(organizadorId, titular, banco, clabe)
    }

    private fun observarResultados() {
        administradorViewModel.resultadoOperacion.observe(viewLifecycleOwner) { resultado ->
            when (resultado) {
                is AdministradorViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(requireContext(), resultado.mensaje, Toast.LENGTH_SHORT).show()
                    findNavController().popBackStack()
                }
                is AdministradorViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(requireContext(), resultado.mensaje, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}
