package com.example.doggierace.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.doggierace.data.database.DoggieRaceDatabase
import com.example.doggierace.data.entities.InscripcionEntity
import com.example.doggierace.data.entities.MascotaEntity
import com.example.doggierace.data.repositories.InscripcionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class InscripcionViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: InscripcionRepository

    val todasInscripcionesActivas: LiveData<List<InscripcionEntity>>

    private val _inscripcionActual = MutableLiveData<InscripcionEntity?>()
    val inscripcionActual: LiveData<InscripcionEntity?> = _inscripcionActual

    init {
        val inscripcionDao = DoggieRaceDatabase.getDatabase(application).inscripcionDao()
        repository = InscripcionRepository(inscripcionDao)
        todasInscripcionesActivas = repository.obtenerTodasActivas()
    }

    // ========== INSERTAR ==========

    // Modificar en InscripcionViewModel.kt
    fun inscribirMascota(
        carreraId: Long,
        mascotaId: Long,
        participanteId: Long,
        categoria: String,
        onSuccess: (Long) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                // Validar si ya existe inscripción
                if (repository.existeInscripcion(carreraId, mascotaId)) {
                    onError("Esta mascota ya está inscrita en esta carrera")
                    return@launch
                }

                // Crear inscripción
                val inscripcion = InscripcionEntity(
                    carreraId = carreraId,
                    mascotaId = mascotaId,
                    participanteId = participanteId,
                    categoria = categoria,
                    estadoPago = InscripcionEntity.ESTADO_PENDIENTE,
                    activa = true
                )

                val inscripcionId = repository.insertar(inscripcion)

                // ✅ Decrementar cupos disponibles de la carrera
                val carreraDao = DoggieRaceDatabase.getDatabase(getApplication()).carreraDao()
                val cuposActualizados = carreraDao.decrementarCupoDisponible(carreraId)

                if (cuposActualizados > 0) {
                    onSuccess(inscripcionId)
                } else {
                    // Si no se pudo actualizar, eliminar la inscripción
                    repository.eliminarPorId(inscripcionId)
                    onError("No hay cupos disponibles")
                }


            } catch (e: Exception) {
                onError("Error al inscribir: ${e.message}")
            }
        }
    }



    // ========== ACTUALIZAR ==========

    fun confirmarPago(inscripcionId: Long, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                repository.actualizarEstadoPago(inscripcionId, InscripcionEntity.ESTADO_PAGADO)
                onSuccess()
            } catch (e: Exception) {
                onError("Error al confirmar pago: ${e.message}")
            }
        }
    }

    fun cancelarInscripcion(inscripcionId: Long, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                repository.cancelarInscripcion(inscripcionId)
                onSuccess()
            } catch (e: Exception) {
                onError("Error al cancelar: ${e.message}")
            }
        }
    }

    // ========== CONSULTAS ==========

    fun cargarInscripcionPorId(inscripcionId: Long) {
        viewModelScope.launch {
            try {
                val inscripcion = repository.obtenerPorId(inscripcionId)
                _inscripcionActual.postValue(inscripcion)
            } catch (e: Exception) {
                _inscripcionActual.postValue(null)
            }
        }
    }

    fun obtenerInscripcionesDeParticipante(participanteId: Long): LiveData<List<InscripcionEntity>> {
        return repository.obtenerInscripcionesDeParticipante(participanteId)
    }

    fun obtenerInscripcionesDeCarrera(carreraId: Long): LiveData<List<InscripcionEntity>> {
        return repository.obtenerInscripcionesDeCarrera(carreraId)
    }

    fun obtenerInscripcionesDeMascota(mascotaId: Long): LiveData<List<InscripcionEntity>> {
        return repository.obtenerInscripcionesDeMascota(mascotaId)
    }

    fun contarInscripcionesDeCarrera(carreraId: Long): LiveData<Int> {
        return repository.contarInscripcionesDeCarreraLiveData(carreraId)
    }

    fun obtenerIdsCarrerasInscritas(participanteId: Long): LiveData<List<Long>> {
        return repository.obtenerIdsCarrerasInscritasLiveData(participanteId)
    }

    // ========== VALIDACIONES ==========

    fun validarInscripcion(
        carreraId: Long,
        mascotaId: Long,
        onResult: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val existe = repository.existeInscripcion(carreraId, mascotaId)
                onResult(existe)
            } catch (e: Exception) {
                onResult(false)
            }
        }
    }

    fun obtenerMascotasInscritasEnCarrera(carreraId: Long, participanteId: Long): LiveData<List<MascotaEntity>> {
        return repository.obtenerMascotasInscritasEnCarrera(carreraId, participanteId)
    }
    suspend fun obtenerMascotasInscritasSync(carreraId: Long, participanteId: Long): List<MascotaEntity> {
        return withContext(Dispatchers.IO) {
            repository.obtenerMascotasInscritasSync(carreraId, participanteId)
        }
    }

    // Obtener IDs de carreras inscritas (versión síncrona)
    suspend fun obtenerIdsCarrerasInscritasSync(participanteId: Long): List<Long> {
        return withContext(Dispatchers.IO) {
            repository.obtenerIdsCarrerasInscritas(participanteId)
        }
    }

    // Verificar si tiene inscripción
    suspend fun participanteTieneInscripcion(carreraId: Long, participanteId: Long): Boolean {
        return withContext(Dispatchers.IO) {
            repository.participanteTieneInscripcion(carreraId, participanteId)
        }
    }

    // Contar inscripciones
    suspend fun contarInscripcionesDeParticipante(carreraId: Long, participanteId: Long): Int {
        return withContext(Dispatchers.IO) {
            val inscripciones = repository.obtenerInscripcionesDeParticipanteEnCarrera(participanteId, carreraId)
            inscripciones.size
        }
    }

    fun eliminarInscripcion(
        carreraId: Long,
        mascotaId: Long,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                // Buscar la inscripción
                val inscripcion = repository.obtenerInscripcionPorCarreraYMascota(carreraId, mascotaId)
                if (inscripcion != null) {
                    repository.eliminarPorId(inscripcion.id)

                    // ✅ Incrementar cupo disponible Y decrementar totalInscritos
                    val carreraDao = DoggieRaceDatabase.getDatabase(getApplication()).carreraDao()
                    carreraDao.incrementarCupoDisponible(carreraId)

                    onSuccess()
                } else {
                    onError("Inscripción no encontrada")
                }

            } catch (e: Exception) {
                onError("Error al eliminar inscripción: ${e.message}")
            }
        }
    }


    // ✅ Método para obtener IDs de mascotas inscritas
    suspend fun obtenerIdsMascotasInscritas(carreraId: Long, participanteId: Long): Set<Long> {
        return withContext(Dispatchers.IO) {
            try {
                val mascotas = repository.obtenerMascotasInscritasSync(carreraId, participanteId)
                mascotas.map { it.id }.toSet()
            } catch (e: Exception) {
                emptySet()
            }
        }
    }







}
