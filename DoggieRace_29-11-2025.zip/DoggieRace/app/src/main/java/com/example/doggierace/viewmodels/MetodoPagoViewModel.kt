package com.example.doggierace.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.doggierace.data.database.DoggieRaceDatabase
import com.example.doggierace.data.entities.MetodoPagoEntity
import com.example.doggierace.data.repositories.MetodoPagoRepository
import kotlinx.coroutines.launch

class MetodoPagoViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MetodoPagoRepository
    private val _resultadoOperacion = MutableLiveData<ResultadoOperacion>()
    val resultadoOperacion: LiveData<ResultadoOperacion> = _resultadoOperacion

    init {
        val metodoPagoDao = DoggieRaceDatabase.getDatabase(application).metodoPagoDao()
        repository = MetodoPagoRepository(metodoPagoDao)
    }

    fun obtenerMetodosPagoDeParticipante(participanteId: Long): LiveData<List<MetodoPagoEntity>> {
        return repository.obtenerMetodosPagoDeParticipante(participanteId)
    }

    fun insertarMetodoPago(metodoPago: MetodoPagoEntity) {
        viewModelScope.launch {
            try {
                // 1️⃣ Si la tarjeta se marca como predeterminada, actualizar primero
                if (metodoPago.esPredeterminada) {
                    // Este método ya quita todas y NO establece ninguna aún
                    // (lo haremos después de insertar)
                    val metodosActuales = repository.obtenerMetodosPagoDeParticipanteSuspend(metodoPago.participanteId)
                    metodosActuales.forEach { metodo ->
                        if (metodo.esPredeterminada) {
                            repository.actualizarMetodoPago(metodo.copy(esPredeterminada = false))
                        }
                    }
                }

                // 2️⃣ Insertar la nueva tarjeta
                val id = repository.insertarMetodoPago(metodoPago)

                // 3️⃣ Si es la PRIMERA tarjeta, marcarla como predeterminada automáticamente
                if (id > 0 && !metodoPago.esPredeterminada) {
                    val tarjetas = repository.obtenerMetodosPagoDeParticipanteSuspend(metodoPago.participanteId)
                    if (tarjetas.size == 1) {
                        // Es la primera tarjeta, marcarla como predeterminada
                        repository.establecerComoPredeterminada(id, metodoPago.participanteId)
                    }
                }

                _resultadoOperacion.value = ResultadoOperacion.Exito("Método de pago agregado exitosamente")
            } catch (e: Exception) {
                _resultadoOperacion.value = ResultadoOperacion.Error("Error al guardar método de pago: ${e.message}")
            }
        }
    }

    fun establecerComoPredeterminada(id: Long, participanteId: Long) {
        viewModelScope.launch {
            try {
                // ✅ Este método ya hace todo: quitar todas y establecer la nueva
                repository.establecerComoPredeterminada(id, participanteId)
                _resultadoOperacion.value = ResultadoOperacion.Exito("Método de pago predeterminado actualizado")
            } catch (e: Exception) {
                _resultadoOperacion.value = ResultadoOperacion.Error("Error al actualizar: ${e.message}")
            }
        }
    }

    fun eliminarMetodoPago(id: Long, participanteId: Long, eraPredeterminada: Boolean) {
        viewModelScope.launch {
            try {
                repository.eliminarMetodoPagoPorId(id)

                // Si era la predeterminada, marcar la primera disponible como predeterminada
                if (eraPredeterminada) {
                    val tarjetas = repository.obtenerMetodosPagoDeParticipanteSuspend(participanteId)
                    if (tarjetas.isNotEmpty()) {
                        repository.establecerComoPredeterminada(tarjetas.first().id, participanteId)
                    }
                }

                _resultadoOperacion.value = ResultadoOperacion.Exito("Método de pago eliminado")
            } catch (e: Exception) {
                _resultadoOperacion.value = ResultadoOperacion.Error("Error al eliminar: ${e.message}")
            }
        }
    }

    sealed class ResultadoOperacion {
        data class Exito(val mensaje: String) : ResultadoOperacion()
        data class Error(val mensaje: String) : ResultadoOperacion()
    }
}
