package com.example.doggierace.data.repository

import androidx.lifecycle.LiveData
import com.example.doggierace.data.dao.ParticipanteDao
import com.example.doggierace.data.entities.ParticipanteEntity

class ParticipanteRepository(private val participanteDao: ParticipanteDao) {

    // LiveData - se actualiza automáticamente
    val todosParticipantes: LiveData<List<ParticipanteEntity>> =
        participanteDao.obtenerTodosParticipantes()

    val participantesActivos: LiveData<List<ParticipanteEntity>> =
        participanteDao.obtenerParticipantesActivos()

    fun obtenerTopParticipantes(limite: Int = 10): LiveData<List<ParticipanteEntity>> {
        return participanteDao.obtenerTopParticipantes(limite)
    }

    // ========== OPERACIONES CRUD ==========

    suspend fun insertarParticipante(participante: ParticipanteEntity): Long {
        return participanteDao.insertarParticipante(participante)
    }

    suspend fun actualizarParticipante(participante: ParticipanteEntity): Int {
        return participanteDao.actualizarParticipante(participante)
    }

    suspend fun actualizarPerfil(
        id: Long,
        nombre: String,
        telefono: String?,
        direccion: String?,
        ciudad: String?
    ): Int {
        return participanteDao.actualizarPerfil(id, nombre, telefono, direccion, ciudad)
    }

    suspend fun actualizarFotoPerfil(id: Long, uri: String?): Int {
        return participanteDao.actualizarFotoPerfil(id, uri)
    }

    suspend fun actualizarPassword(id: Long, nuevaPassword: String): Int {
        return participanteDao.actualizarPassword(id, nuevaPassword)
    }

    suspend fun actualizarTotalMascotas(id: Long, total: Int): Int {
        return participanteDao.actualizarTotalMascotas(id, total)
    }

    suspend fun incrementarCarrerasParticipadas(id: Long): Int {
        return participanteDao.incrementarCarrerasParticipadas(id)
    }

    suspend fun eliminarParticipante(id: Long): Int {
        return participanteDao.eliminarParticipantePorId(id)
    }

    // ========== CONSULTAS ==========

    suspend fun obtenerParticipantePorId(id: Long): ParticipanteEntity? {
        return participanteDao.obtenerParticipantePorId(id)
    }

    fun obtenerParticipantePorIdLiveData(id: Long): LiveData<ParticipanteEntity?> {
        return participanteDao.obtenerParticipantePorIdLiveData(id)
    }

    suspend fun obtenerParticipantePorEmail(email: String): ParticipanteEntity? {
        return participanteDao.obtenerParticipantePorEmail(email)
    }

    suspend fun login(email: String, password: String): ParticipanteEntity? {
        return participanteDao.login(email, password)
    }

    fun obtenerParticipantesPorCiudad(ciudad: String): LiveData<List<ParticipanteEntity>> {
        return participanteDao.obtenerParticipantesPorCiudad(ciudad)
    }

    suspend fun verificarEmailExistente(email: String): Boolean {
        return participanteDao.verificarEmailExistente(email) > 0
    }

    suspend fun contarParticipantes(): Int {
        return participanteDao.contarParticipantes()
    }

    suspend fun contarParticipantesActivos(): Int {
        return participanteDao.contarParticipantesActivos()
    }
}
