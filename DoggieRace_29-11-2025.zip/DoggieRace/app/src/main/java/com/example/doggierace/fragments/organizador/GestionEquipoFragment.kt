package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.databinding.FragmentGestionEquipoBinding
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.AdministradorViewModel
import kotlinx.coroutines.launch

class GestionEquipoFragment : Fragment() {

    private var _binding: FragmentGestionEquipoBinding? = null
    private val binding get() = _binding!!

    private val administradorViewModel: AdministradorViewModel by viewModels()
    private lateinit var sessionManager: SessionManager
    private var organizadorId: Long = 0
    private var passwordReal: String = ""
    private var codigoOrganizador: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGestionEquipoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())
        organizadorId = sessionManager.obtenerUserId()

        setupToolbar()

        cargarDatosOrganizador()
        setupClickListeners()
    }
    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }


    private fun cargarDatosOrganizador() {
        lifecycleScope.launch {
            try {
                val organizador = administradorViewModel.obtenerAdministradorPorId(organizadorId)
                if (organizador != null) {
                    passwordReal = organizador.password
                    codigoOrganizador = organizador.codigoVerificacion
                } else {
                    Toast.makeText(requireContext(), "Error al cargar datos", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnDesbloquearCodigo.setOnClickListener {
            desbloquearCodigo()
        }
    }

    private fun desbloquearCodigo() {
        val passwordIngresada = binding.etPassword.text.toString().trim()

        // Validar que no esté vacío
        if (passwordIngresada.isEmpty()) {
            binding.inputLayoutPassword.error = "Ingresa tu contraseña"
            return
        }

        // Validar contra la contraseña real del organizador
        if (passwordIngresada == passwordReal) {
            // ✅ Contraseña Correcta: Mostrar código
            binding.containerBloqueado.visibility = View.GONE
            binding.containerDesbloqueado.visibility = View.VISIBLE

            // Mostrar el código de organizador
            binding.tvCodigoOrganizador.text = codigoOrganizador

            // Desactivar campos
            binding.btnDesbloquearCodigo.isEnabled = false
            binding.btnDesbloquearCodigo.text = "Código Desbloqueado"
            binding.inputLayoutPassword.isEnabled = false
            binding.inputLayoutPassword.error = null

            Toast.makeText(requireContext(), "Código revelado", Toast.LENGTH_SHORT).show()
        } else {
            // ❌ Contraseña Incorrecta
            binding.inputLayoutPassword.error = "Contraseña incorrecta"
            binding.etPassword.requestFocus()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
