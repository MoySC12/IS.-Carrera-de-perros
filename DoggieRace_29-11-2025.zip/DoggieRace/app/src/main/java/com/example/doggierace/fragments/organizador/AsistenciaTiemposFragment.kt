package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.adapters.AsistenciaTiemposAdapter
import com.example.doggierace.databinding.FragmentAsistenciaTiemposBinding
import com.example.doggierace.models.ParticipanteCategoria

class AsistenciaTiemposFragment : Fragment() {

    private var _binding: FragmentAsistenciaTiemposBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: AsistenciaTiemposAdapter

    // Argumentos recibidos
    private var categoriaId: String? = null
    private var categoriaNombre: String? = null
    private var carreraNombre: String? = null
    private var horaSalida: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            categoriaId = it.getString("categoriaId")
            categoriaNombre = it.getString("categoriaNombre")
            carreraNombre = it.getString("carreraNombre")
            horaSalida = it.getString("horaSalida")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAsistenciaTiemposBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        // Configurar Toolbar
        setupToolbar()

        // Cargar datos del header
        cargarDatosCategoria()

        // Datos de prueba (Mock Data)
        val participantes = mutableListOf(
            ParticipanteCategoria("p1", "Juan Pérez", "Fido", asistio = true, tiempo = "00:15:30"),
            ParticipanteCategoria("p2", "Ana García", "Luna", asistio = true, tiempo = "00:16:45"),
            ParticipanteCategoria("p3", "Miguel H.", "Max", asistio = false, tiempo = "")
        )

        // Configurar RecyclerView
        adapter = AsistenciaTiemposAdapter(participantes)
        binding.rvAsistenciaTiempos.layoutManager = LinearLayoutManager(requireContext())
        binding.rvAsistenciaTiempos.adapter = adapter

        // Botón: Guardar Cambios
        binding.btnGuardarCambios.setOnClickListener {
            guardarCambios()
        }
    }
    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun cargarDatosCategoria() {
        binding.tvCarreraNombre.text = carreraNombre ?: "Carrera del Bosque"
        binding.tvCategoriaNombre.text = "Categoría: ${categoriaNombre ?: "Razas Pequeñas"}"
        binding.tvCategoriaHora.text = "⏰ Hora de Salida: ${horaSalida ?: "9:00 AM"}"
    }

    private fun guardarCambios() {
        // Obtener datos actualizados del adapter
        val datosActualizados = adapter.getUpdatedData()

        // TODO: Guardar en base de datos
        // Por ahora, solo mostramos un Toast con resumen
        val asistentes = datosActualizados.count { it.asistio }

        Toast.makeText(
            requireContext(),
            "Asistencia y tiempos guardados: $asistentes participantes asistieron",
            Toast.LENGTH_SHORT
        ).show()

        // Volver a la pantalla anterior
        findNavController().popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
