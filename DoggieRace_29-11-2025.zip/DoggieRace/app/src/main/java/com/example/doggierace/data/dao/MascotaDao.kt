package com.example.doggierace.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.doggierace.data.entities.MascotaEntity

@Dao
interface MascotaDao {

    // ========== INSERTAR ==========
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarMascota(mascota: MascotaEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarMascotas(mascotas: List<MascotaEntity>): List<Long>

    // ========== ACTUALIZAR ==========
    @Update
    suspend fun actualizarMascota(mascota: MascotaEntity): Int

    @Query("""
        UPDATE mascotas 
        SET nombre = :nombre, 
            raza = :raza, 
            edad = :edad,
            categoria = :categoria,
            sexo = :sexo,
            peso = :peso,
            color = :color
        WHERE id = :id
    """)
    suspend fun actualizarDatosMascota(
        id: Long,
        nombre: String,
        raza: String,
        edad: Int,
        categoria: String,
        sexo: String,
        peso: Double?,
        color: String?
    ): Int

    @Query("UPDATE mascotas SET foto_perro_uri = :uri WHERE id = :id")
    suspend fun actualizarFotoMascota(id: Long, uri: String?): Int

    @Query("UPDATE mascotas SET activa = :activa WHERE id = :id")
    suspend fun actualizarEstadoActiva(id: Long, activa: Boolean): Int

    @Query("UPDATE mascotas SET total_carreras = total_carreras + 1 WHERE id = :id")
    suspend fun incrementarTotalCarreras(id: Long): Int

    @Query("UPDATE mascotas SET total_victorias = total_victorias + 1 WHERE id = :id")
    suspend fun incrementarTotalVictorias(id: Long): Int

    // ========== ELIMINAR ==========
    @Delete
    suspend fun eliminarMascota(mascota: MascotaEntity): Int

    @Query("DELETE FROM mascotas WHERE id = :id")
    suspend fun eliminarMascotaPorId(id: Long): Int

    @Query("DELETE FROM mascotas WHERE participante_id = :participanteId")
    suspend fun eliminarMascotasDeParticipante(participanteId: Long): Int

    @Query("DELETE FROM mascotas")
    suspend fun eliminarTodasMascotas(): Int

    // ========== CONSULTAS ==========
    @Query("SELECT * FROM mascotas WHERE id = :id")
    suspend fun obtenerMascotaPorId(id: Long): MascotaEntity?

    @Query("SELECT * FROM mascotas WHERE id = :id")
    fun obtenerMascotaPorIdLiveData(id: Long): LiveData<MascotaEntity?>

    @Query("SELECT * FROM mascotas WHERE participante_id = :participanteId")
    suspend fun obtenerMascotasDeParticipante(participanteId: Long): List<MascotaEntity>

    @Query("SELECT * FROM mascotas WHERE participante_id = :participanteId")
    fun obtenerMascotasDeParticipanteLiveData(participanteId: Long): LiveData<List<MascotaEntity>>

    @Query("SELECT * FROM mascotas WHERE participante_id = :participanteId AND activa = 1")
    fun obtenerMascotasActivasDeParticipante(participanteId: Long): LiveData<List<MascotaEntity>>

    @Query("SELECT * FROM mascotas WHERE categoria = :categoria AND activa = 1")
    fun obtenerMascotasPorCategoria(categoria: String): LiveData<List<MascotaEntity>>

    @Query("SELECT * FROM mascotas WHERE activa = 1 ORDER BY total_victorias DESC LIMIT :limite")
    fun obtenerTopMascotas(limite: Int = 10): LiveData<List<MascotaEntity>>

    @Query("SELECT * FROM mascotas ORDER BY fecha_registro DESC")
    fun obtenerTodasMascotas(): LiveData<List<MascotaEntity>>

    @Query("SELECT * FROM mascotas ORDER BY fecha_registro DESC")
    suspend fun obtenerTodasMascotasSuspend(): List<MascotaEntity>

    @Query("SELECT COUNT(*) FROM mascotas WHERE participante_id = :participanteId")
    suspend fun contarMascotasDeParticipante(participanteId: Long): Int

    @Query("SELECT COUNT(*) FROM mascotas WHERE participante_id = :participanteId AND activa = 1")
    suspend fun contarMascotasActivasDeParticipante(participanteId: Long): Int

    @Query("SELECT COUNT(*) FROM mascotas")
    suspend fun contarTodasMascotas(): Int

    @Query("""
        SELECT * FROM mascotas 
        WHERE nombre LIKE '%' || :busqueda || '%' 
           OR raza LIKE '%' || :busqueda || '%'
    """)
    fun buscarMascotas(busqueda: String): LiveData<List<MascotaEntity>>

    @Query("SELECT * FROM mascotas WHERE discapacidad IS NOT NULL AND activa = 1")
    fun obtenerMascotasConDiscapacidad(): LiveData<List<MascotaEntity>>

    @Query("SELECT * FROM mascotas WHERE peso BETWEEN :pesoMin AND :pesoMax AND activa = 1")
    fun obtenerMascotasPorRangoPeso(pesoMin: Double, pesoMax: Double): LiveData<List<MascotaEntity>>

    @Query("SELECT * FROM mascotas WHERE altura BETWEEN :alturaMin AND :alturaMax AND activa = 1")
    fun obtenerMascotasPorRangoAltura(alturaMin: Double, alturaMax: Double): LiveData<List<MascotaEntity>>
}
