package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.databinding.ItemCarreraFinalizadaBinding
import com.example.doggierace.data.entities.CarreraEntity
import java.text.SimpleDateFormat
import java.util.*

class CarrerasFinalizadasAdapter(
    private val onItemClick: (CarreraEntity) -> Unit
) : ListAdapter<CarreraEntity, CarrerasFinalizadasAdapter.CarreraViewHolder>(CarreraDiffCallback()) {

    inner class CarreraViewHolder(private val binding: ItemCarreraFinalizadaBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(carrera: CarreraEntity) {
            // Nombre de la carrera
            binding.tvNombreCarrera.text = carrera.nombre

            // Formatear fecha
            val formatoFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            binding.tvFechaCarrera.text = formatoFecha.format(Date(carrera.fecha))

            // Lugar
            binding.tvLugarCarrera.text = carrera.ubicacion

            // Click listener
            binding.root.setOnClickListener {
                onItemClick(carrera)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarreraViewHolder {
        val binding = ItemCarreraFinalizadaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CarreraViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CarreraViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class CarreraDiffCallback : DiffUtil.ItemCallback<CarreraEntity>() {
        override fun areItemsTheSame(oldItem: CarreraEntity, newItem: CarreraEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: CarreraEntity, newItem: CarreraEntity): Boolean {
            return oldItem == newItem
        }
    }
}
