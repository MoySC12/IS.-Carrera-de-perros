package com.example.doggierace.data.repository

import androidx.lifecycle.LiveData
import com.example.doggierace.data.dao.MascotaDao
import com.example.doggierace.data.entities.MascotaEntity

class MascotaRepository(private val mascotaDao: MascotaDao) {

    // LiveData - se actualiza automáticamente
    val todasMascotas: LiveData<List<MascotaEntity>> =
        mascotaDao.obtenerTodasMascotas()

    fun obtenerTopMascotas(limite: Int = 10): LiveData<List<MascotaEntity>> {
        return mascotaDao.obtenerTopMascotas(limite)
    }

    // ========== OPERACIONES CRUD ==========

    suspend fun insertarMascota(mascota: MascotaEntity): Long {
        return mascotaDao.insertarMascota(mascota)
    }

    suspend fun actualizarMascota(mascota: MascotaEntity): Int {
        return mascotaDao.actualizarMascota(mascota)
    }

    suspend fun actualizarDatosMascota(
        id: Long,
        nombre: String,
        raza: String,
        edad: Int,
        categoria: String,
        sexo: String,
        peso: Double?,
        color: String?
    ): Int {
        return mascotaDao.actualizarDatosMascota(
            id, nombre, raza, edad, categoria, sexo, peso, color
        )
    }

    suspend fun actualizarFotoMascota(id: Long, uri: String?): Int {
        return mascotaDao.actualizarFotoMascota(id, uri)
    }

    suspend fun actualizarEstadoActiva(id: Long, activa: Boolean): Int {
        return mascotaDao.actualizarEstadoActiva(id, activa)
    }

    suspend fun incrementarTotalCarreras(id: Long): Int {
        return mascotaDao.incrementarTotalCarreras(id)
    }

    suspend fun incrementarTotalVictorias(id: Long): Int {
        return mascotaDao.incrementarTotalVictorias(id)
    }

    suspend fun eliminarMascota(id: Long): Int {
        return mascotaDao.eliminarMascotaPorId(id)
    }

    suspend fun eliminarMascotasDeParticipante(participanteId: Long): Int {
        return mascotaDao.eliminarMascotasDeParticipante(participanteId)
    }

    // ========== CONSULTAS ==========

    suspend fun obtenerMascotaPorId(id: Long): MascotaEntity? {
        return mascotaDao.obtenerMascotaPorId(id)
    }

    fun obtenerMascotaPorIdLiveData(id: Long): LiveData<MascotaEntity?> {
        return mascotaDao.obtenerMascotaPorIdLiveData(id)
    }

    suspend fun obtenerMascotasDeParticipante(participanteId: Long): List<MascotaEntity> {
        return mascotaDao.obtenerMascotasDeParticipante(participanteId)
    }

    fun obtenerMascotasDeParticipanteLiveData(participanteId: Long): LiveData<List<MascotaEntity>> {
        return mascotaDao.obtenerMascotasDeParticipanteLiveData(participanteId)
    }

    fun obtenerMascotasActivasDeParticipante(participanteId: Long): LiveData<List<MascotaEntity>> {
        return mascotaDao.obtenerMascotasActivasDeParticipante(participanteId)
    }

    fun obtenerMascotasPorCategoria(categoria: String): LiveData<List<MascotaEntity>> {
        return mascotaDao.obtenerMascotasPorCategoria(categoria)
    }

    fun buscarMascotas(busqueda: String): LiveData<List<MascotaEntity>> {
        return mascotaDao.buscarMascotas(busqueda)
    }

    suspend fun contarMascotasDeParticipante(participanteId: Long): Int {
        return mascotaDao.contarMascotasDeParticipante(participanteId)
    }

    suspend fun contarMascotasActivasDeParticipante(participanteId: Long): Int {
        return mascotaDao.contarMascotasActivasDeParticipante(participanteId)
    }

    suspend fun contarTodasMascotas(): Int {
        return mascotaDao.contarTodasMascotas()
    }
}
