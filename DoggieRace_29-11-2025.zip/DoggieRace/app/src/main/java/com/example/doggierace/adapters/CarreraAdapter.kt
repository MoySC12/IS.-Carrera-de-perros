package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.databinding.ItemCarreraBinding
import com.example.doggierace.data.entities.CarreraEntity
import java.text.SimpleDateFormat
import java.util.*

class CarreraAdapter(
    private val onItemClick: (CarreraEntity) -> Unit
) : ListAdapter<CarreraEntity, CarreraAdapter.CarreraViewHolder>(CarreraDiffCallback()) {

    inner class CarreraViewHolder(private val binding: ItemCarreraBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(carrera: CarreraEntity) {
            // Nombre
            binding.tvNombreCarrera.text = carrera.nombre

            // Fecha y hora formateada
            val formatoFecha = SimpleDateFormat("dd 'de' MMM. - hh:mm a", Locale.forLanguageTag("es-ES"))
            val fechaTexto = formatoFecha.format(Date(carrera.fecha))
            binding.tvFechaCarrera.text = fechaTexto

            // Lugar
            binding.tvLugarCarrera.text = carrera.ubicacion

            // Click listener
            binding.root.setOnClickListener {
                onItemClick(carrera)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarreraViewHolder {
        val binding = ItemCarreraBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CarreraViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CarreraViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class CarreraDiffCallback : DiffUtil.ItemCallback<CarreraEntity>() {
        override fun areItemsTheSame(oldItem: CarreraEntity, newItem: CarreraEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: CarreraEntity, newItem: CarreraEntity): Boolean {
            return oldItem == newItem
        }
    }
}
