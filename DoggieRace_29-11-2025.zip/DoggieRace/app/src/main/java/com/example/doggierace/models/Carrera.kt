package com.example.doggierace.models

data class Carrera(
    val id: String,
    val nombre: String,
    val fecha: String,
    val lugar: String
)
