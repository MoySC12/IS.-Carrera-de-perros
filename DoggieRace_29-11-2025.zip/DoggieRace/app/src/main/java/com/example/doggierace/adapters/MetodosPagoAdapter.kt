package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.R
import com.example.doggierace.data.entities.MetodoPagoEntity
import com.example.doggierace.databinding.ItemMetodoPagoBinding

class MetodosPagoAdapter(
    private val onItemClick: (MetodoPagoEntity) -> Unit,
    private val onEliminarClick: (MetodoPagoEntity) -> Unit,
    private val onPredeterminadaClick: (MetodoPagoEntity) -> Unit
) : ListAdapter<MetodoPagoEntity, MetodosPagoAdapter.MetodoPagoViewHolder>(MetodoPagoDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MetodoPagoViewHolder {
        val binding = ItemMetodoPagoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MetodoPagoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MetodoPagoViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class MetodoPagoViewHolder(
        private val binding: ItemMetodoPagoBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(metodoPago: MetodoPagoEntity) {
            binding.apply {
                // Icono según tipo de tarjeta
                val iconoRes = when (metodoPago.tipo.uppercase()) {
                    "VISA" -> R.drawable.ic_visa
                    "MASTERCARD" -> R.drawable.ic_mastercard
                    "AMEX" -> R.drawable.ic_amex
                    else -> R.drawable.ic_credit_card
                }
                // Si no tienes estos iconos, usa el genérico por ahora
                // imgTipoTarjeta.setImageResource(iconoRes)

                tvTipoTarjeta.text = metodoPago.tipo
                tvNumeroTarjeta.text = "•••• ${metodoPago.numeroTarjeta}"
                tvNombreTitular.text = metodoPago.nombreTitular
                tvVencimiento.text = "Vence: ${metodoPago.fechaVencimiento}"

                // Mostrar badge de predeterminada
                if (metodoPago.esPredeterminada) {
                    tvPredeterminada.visibility = android.view.View.VISIBLE
                    btnEstablecerPredeterminada.visibility = android.view.View.GONE
                } else {
                    tvPredeterminada.visibility = android.view.View.GONE
                    btnEstablecerPredeterminada.visibility = android.view.View.VISIBLE
                }

                // Click listeners
                root.setOnClickListener { onItemClick(metodoPago) }
                btnEliminar.setOnClickListener { onEliminarClick(metodoPago) }
                btnEstablecerPredeterminada.setOnClickListener { onPredeterminadaClick(metodoPago) }
            }
        }
    }

    class MetodoPagoDiffCallback : DiffUtil.ItemCallback<MetodoPagoEntity>() {
        override fun areItemsTheSame(oldItem: MetodoPagoEntity, newItem: MetodoPagoEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: MetodoPagoEntity, newItem: MetodoPagoEntity): Boolean {
            return oldItem == newItem
        }
    }
}
