package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.databinding.FragmentAgregarMascotaBinding
import com.example.doggierace.data.entities.MascotaEntity
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.MascotaViewModel

class AgregarMascotaFragment : Fragment() {

    private var _binding: FragmentAgregarMascotaBinding? = null
    private val binding get() = _binding!!

    private val mascotaViewModel: MascotaViewModel by viewModels()
    private lateinit var sessionManager: SessionManager

    private var fotoPerroUri: String? = null
    private var cartillaUri: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAgregarMascotaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())

        setupToolbar()
        setupClickListeners()
        observarResultados()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun setupClickListeners() {
        // Botón: Agregar Foto del Perro
        binding.btnAgregarFotoPerro.setOnClickListener {
            // TODO: Implementar selección de foto desde galería o cámara
            Toast.makeText(
                requireContext(),
                "Función 'Agregar Foto' en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Botón: Subir Cartilla de Vacunación
        binding.btnSubirCartilla.setOnClickListener {
            // TODO: Implementar selección de archivo/foto de cartilla
            Toast.makeText(
                requireContext(),
                "Función 'Subir Cartilla' en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Botón: Guardar Mascota
        binding.btnGuardarMascota.setOnClickListener {
            guardarMascota()
        }
    }

    private fun guardarMascota() {
        // Limpiar errores previos
        limpiarErrores()

        // Obtener valores de los campos
        val nombre = binding.etNombreMascota.text.toString().trim()
        val raza = binding.etRaza.text.toString().trim()
        val edadStr = binding.etEdad.text.toString().trim()
        val pesoStr = binding.etPeso.text.toString().trim()
        val alturaStr = binding.etAltura.text.toString().trim()
        val discapacidad = binding.etDiscapacidad.text.toString().trim()

        // Validaciones
        if (!validarCampos(nombre, raza, edadStr, pesoStr, alturaStr)) {
            return
        }

        // Convertir valores numéricos
        val edad = edadStr.toIntOrNull() ?: 0
        val peso = pesoStr.toDoubleOrNull() ?: 0.0
        val altura = alturaStr.toDoubleOrNull() ?: 0.0

        // Obtener ID del participante de la sesión
        val participanteId = sessionManager.obtenerUserId()

        if (participanteId == -1L) {
            Toast.makeText(
                requireContext(),
                "Error: No hay sesión activa",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // Determinar categoría automáticamente según peso
        val categoria = determinarCategoria(peso)

        // Crear entidad
        val nuevaMascota = MascotaEntity(
            participanteId = participanteId,
            nombre = nombre,
            raza = raza,
            edad = edad,
            peso = peso,
            altura = altura,
            categoria = categoria,
            discapacidad = if (discapacidad.isEmpty()) null else discapacidad,
            fotoPerroUri = fotoPerroUri,
            cartillaVacunacionUri = cartillaUri
        )

        // Insertar en la base de datos
        mascotaViewModel.insertarMascota(nuevaMascota)
    }

    private fun validarCampos(
        nombre: String,
        raza: String,
        edad: String,
        peso: String,
        altura: String
    ): Boolean {

        // Validar nombre
        if (nombre.isEmpty()) {
            binding.inputLayoutNombreMascota.error = "El nombre es obligatorio"
            binding.etNombreMascota.requestFocus()
            return false
        }

        // Validar raza
        if (raza.isEmpty()) {
            binding.inputLayoutRaza.error = "La raza es obligatoria"
            binding.etRaza.requestFocus()
            return false
        }

        // Validar edad
        if (edad.isEmpty()) {
            binding.inputLayoutEdad.error = "La edad es obligatoria"
            binding.etEdad.requestFocus()
            return false
        }

        val edadNum = edad.toIntOrNull()
        if (edadNum == null || edadNum <= 0 || edadNum > 20) {
            binding.inputLayoutEdad.error = "Edad inválida (1-20 años)"
            binding.etEdad.requestFocus()
            return false
        }

        // Validar peso
        if (peso.isEmpty()) {
            binding.inputLayoutPeso.error = "El peso es obligatorio"
            binding.etPeso.requestFocus()
            return false
        }

        val pesoNum = peso.toDoubleOrNull()
        if (pesoNum == null || pesoNum <= 0 || pesoNum > 100) {
            binding.inputLayoutPeso.error = "Peso inválido (0-100 kg)"
            binding.etPeso.requestFocus()
            return false
        }

        // Validar altura
        if (altura.isEmpty()) {
            binding.inputLayoutAltura.error = "La altura es obligatoria"
            binding.etAltura.requestFocus()
            return false
        }

        val alturaNum = altura.toDoubleOrNull()
        if (alturaNum == null || alturaNum <= 0 || alturaNum > 200) {
            binding.inputLayoutAltura.error = "Altura inválida (0-200 cm)"
            binding.etAltura.requestFocus()
            return false
        }

        return true
    }

    private fun limpiarErrores() {
        binding.inputLayoutNombreMascota.error = null
        binding.inputLayoutRaza.error = null
        binding.inputLayoutEdad.error = null
        binding.inputLayoutPeso.error = null
        binding.inputLayoutAltura.error = null
    }

    private fun determinarCategoria(peso: Double): String {
        return when {
            peso < 10.0 -> "Pequeña"
            peso < 25.0 -> "Mediana"
            peso < 45.0 -> "Grande"
            else -> "XL"
        }
    }

    private fun observarResultados() {
        mascotaViewModel.resultadoOperacion.observe(viewLifecycleOwner) { resultado ->
            when (resultado) {
                is MascotaViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(
                        requireContext(),
                        "Mascota guardada exitosamente",
                        Toast.LENGTH_SHORT
                    ).show()
                    // Volver a la pantalla anterior
                    findNavController().popBackStack()
                }
                is MascotaViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(
                        requireContext(),
                        resultado.mensaje,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
