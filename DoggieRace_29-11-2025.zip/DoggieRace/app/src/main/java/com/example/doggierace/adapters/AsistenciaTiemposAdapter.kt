package com.example.doggierace.adapters

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.R
import com.example.doggierace.databinding.ItemAsistenciaTiempoBinding
import com.example.doggierace.models.ParticipanteCategoria

class AsistenciaTiemposAdapter(
    private val participantes: MutableList<ParticipanteCategoria>
) : RecyclerView.Adapter<AsistenciaTiemposAdapter.AsistenciaViewHolder>() {

    inner class AsistenciaViewHolder(val binding: ItemAsistenciaTiempoBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AsistenciaViewHolder {
        val binding = ItemAsistenciaTiempoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AsistenciaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AsistenciaViewHolder, position: Int) {
        val participante = participantes[position]

        // Asignar nombres
        holder.binding.tvNombreMascota.text = "🐶 ${participante.nombreMascota}"
        holder.binding.tvNombreDueno.text = "Dueño: ${participante.nombreDueño}"

        // Sincronizar RadioGroup
        holder.binding.rgAsistencia.setOnCheckedChangeListener(null) // Evitar loops
        holder.binding.rgAsistencia.check(
            if (participante.asistio) R.id.rb_asistio_si else R.id.rb_asistio_no
        )

        // Sincronizar EditText
        holder.binding.etTiempo.removeTextChangedListener(holder.binding.etTiempo.tag as? TextWatcher)
        holder.binding.etTiempo.setText(participante.tiempo)

        // Listener bidireccional para RadioGroup
        holder.binding.rgAsistencia.setOnCheckedChangeListener { _, checkedId ->
            participante.asistio = (checkedId == R.id.rb_asistio_si)
        }

        // Listener bidireccional para EditText
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                participante.tiempo = s.toString()
            }
            override fun afterTextChanged(s: Editable?) {}
        }
        holder.binding.etTiempo.tag = textWatcher
        holder.binding.etTiempo.addTextChangedListener(textWatcher)
    }

    override fun getItemCount(): Int = participantes.size

    // Función pública para obtener los datos actualizados
    fun getUpdatedData(): List<ParticipanteCategoria> {
        return participantes
    }
}
