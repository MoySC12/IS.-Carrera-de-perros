package com.example.doggierace.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "carreras",
    foreignKeys = [
        ForeignKey(
            entity = AdministradorEntity::class,
            parentColumns = ["id"],
            childColumns = ["organizador_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["organizador_id"]),
        Index(value = ["fecha"]),
        Index(value = ["estado"])
    ]
)
data class CarreraEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,

    @ColumnInfo(name = "organizador_id")
    val organizadorId: Long,

    @ColumnInfo(name = "nombre")
    val nombre: String,

    @ColumnInfo(name = "descripcion")
    val descripcion: String,

    @ColumnInfo(name = "fecha")
    val fecha: Long,

    @ColumnInfo(name = "hora_inicio")
    val horaInicio: String,

    @ColumnInfo(name = "ubicacion")
    val ubicacion: String,

    @ColumnInfo(name = "direccion")
    val direccion: String,

    @ColumnInfo(name = "ciudad")
    val ciudad: String,

    @ColumnInfo(name = "categoria")
    val categoria: String, // ✅ Tipo de carrera: Obstáculos, Paseos, Trineos, Canicross

    @ColumnInfo(name = "costo_inscripcion")
    val costoInscripcion: Double,

    @ColumnInfo(name = "cupos_totales")
    val cuposTotales: Int,

    @ColumnInfo(name = "cupos_disponibles")
    val cuposDisponibles: Int,

    @ColumnInfo(name = "estado")
    val estado: String,

    @ColumnInfo(name = "edad_minima")
    val edadMinima: Int = 1,

    @ColumnInfo(name = "imagen_uri")
    val imagenUri: String? = null,

    @ColumnInfo(name = "requisitos")
    val requisitos: String? = null,

    @ColumnInfo(name = "premios")
    val premios: String? = null,

    @ColumnInfo(name = "distancia_metros")
    val distanciaMetros: Int? = null,

    @ColumnInfo(name = "total_inscritos")
    val totalInscritos: Int = 0,

    @ColumnInfo(name = "fecha_creacion")
    val fechaCreacion: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "fecha_limite_inscripcion")
    val fechaLimiteInscripcion: Long? = null,

    @ColumnInfo(name = "activa")
    val activa: Boolean = true,



) {
    companion object {
        // Estados de la carrera
        const val ESTADO_PROXIMA = "PROXIMA"
        const val ESTADO_EN_CURSO = "EN_CURSO"
        const val ESTADO_FINALIZADA = "FINALIZADA"
        const val ESTADO_CANCELADA = "CANCELADA"

        // ✅ SOLO Categorías de CARRERAS (tipos de evento)
        const val CATEGORIA_OBSTACULOS = "Obstáculos"
        const val CATEGORIA_PASEOS = "Paseos"
        const val CATEGORIA_TRINEOS = "Trineos"
        const val CATEGORIA_CANICROSS = "Canicross"

    }

}
