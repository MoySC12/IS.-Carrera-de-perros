package com.example.doggierace.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.doggierace.data.entities.InscripcionEntity
import com.example.doggierace.data.entities.MascotaEntity

@Dao
interface InscripcionDao {

    // ========== INSERTAR ==========

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertar(inscripcion: InscripcionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarTodas(inscripciones: List<InscripcionEntity>)

    // ========== ACTUALIZAR ==========

    @Update
    suspend fun actualizar(inscripcion: InscripcionEntity)

    @Query("UPDATE inscripciones SET estadoPago = :estadoPago WHERE id = :inscripcionId")
    suspend fun actualizarEstadoPago(inscripcionId: Long, estadoPago: String)

    @Query("UPDATE inscripciones SET activa = :activa WHERE id = :inscripcionId")
    suspend fun actualizarEstado(inscripcionId: Long, activa: Boolean)

    // ========== ELIMINAR ==========

    @Delete
    suspend fun eliminar(inscripcion: InscripcionEntity)

    @Query("DELETE FROM inscripciones WHERE id = :inscripcionId")
    suspend fun eliminarPorId(inscripcionId: Long)

    // ========== CONSULTAS BÁSICAS ==========

    @Query("SELECT * FROM inscripciones WHERE id = :inscripcionId")
    suspend fun obtenerPorId(inscripcionId: Long): InscripcionEntity?

    @Query("SELECT * FROM inscripciones WHERE id = :inscripcionId")
    fun obtenerPorIdLiveData(inscripcionId: Long): LiveData<InscripcionEntity?>

    @Query("SELECT * FROM inscripciones WHERE activa = 1")
    fun obtenerTodasActivas(): LiveData<List<InscripcionEntity>>

    // ========== CONSULTAS POR PARTICIPANTE ==========

    @Query("SELECT * FROM inscripciones WHERE participanteId = :participanteId AND activa = 1")
    fun obtenerInscripcionesDeParticipante(participanteId: Long): LiveData<List<InscripcionEntity>>

    @Query("SELECT * FROM inscripciones WHERE participanteId = :participanteId AND activa = 1")
    suspend fun obtenerInscripcionesDeParticipanteSync(participanteId: Long): List<InscripcionEntity>

    // ========== CONSULTAS POR CARRERA ==========

    @Query("SELECT * FROM inscripciones WHERE carreraId = :carreraId AND activa = 1")
    fun obtenerInscripcionesDeCarrera(carreraId: Long): LiveData<List<InscripcionEntity>>

    @Query("SELECT * FROM inscripciones WHERE carreraId = :carreraId AND activa = 1")
    suspend fun obtenerInscripcionesDeCarreraSync(carreraId: Long): List<InscripcionEntity>

    @Query("SELECT COUNT(*) FROM inscripciones WHERE carreraId = :carreraId AND activa = 1")
    suspend fun contarInscripcionesDeCarrera(carreraId: Long): Int

    @Query("SELECT COUNT(*) FROM inscripciones WHERE carreraId = :carreraId AND activa = 1")
    fun contarInscripcionesDeCarreraLiveData(carreraId: Long): LiveData<Int>

    // ========== CONSULTAS POR MASCOTA ==========

    @Query("SELECT * FROM inscripciones WHERE mascotaId = :mascotaId AND activa = 1")
    fun obtenerInscripcionesDeMascota(mascotaId: Long): LiveData<List<InscripcionEntity>>

    @Query("SELECT * FROM inscripciones WHERE mascotaId = :mascotaId AND activa = 1")
    suspend fun obtenerInscripcionesDeMascotaSync(mascotaId: Long): List<InscripcionEntity>

    // ========== VALIDACIONES ==========

    @Query("""
        SELECT EXISTS(
            SELECT 1 FROM inscripciones 
            WHERE carreraId = :carreraId 
            AND mascotaId = :mascotaId 
            AND activa = 1
        )
    """)
    suspend fun existeInscripcion(carreraId: Long, mascotaId: Long): Boolean

    @Query("""
        SELECT EXISTS(
            SELECT 1 FROM inscripciones 
            WHERE carreraId = :carreraId 
            AND participanteId = :participanteId 
            AND activa = 1
        )
    """)
    suspend fun participanteTieneInscripcion(carreraId: Long, participanteId: Long): Boolean

    // ========== CONSULTAS COMBINADAS ==========

    @Query("""
        SELECT * FROM inscripciones 
        WHERE participanteId = :participanteId 
        AND carreraId = :carreraId 
        AND activa = 1
    """)
    suspend fun obtenerInscripcionesDeParticipanteEnCarrera(
        participanteId: Long,
        carreraId: Long
    ): List<InscripcionEntity>

    @Query("""
        SELECT DISTINCT carreraId FROM inscripciones 
        WHERE participanteId = :participanteId 
        AND activa = 1
    """)
    suspend fun obtenerIdsCarrerasInscritas(participanteId: Long): List<Long>

    @Query("""
        SELECT DISTINCT carreraId FROM inscripciones 
        WHERE participanteId = :participanteId 
        AND activa = 1
    """)
    fun obtenerIdsCarrerasInscritasLiveData(participanteId: Long): LiveData<List<Long>>
    @Query("""
    SELECT m.* FROM mascotas m
    INNER JOIN inscripciones i ON m.id = i.mascotaId
    WHERE i.carreraId = :carreraId 
    AND i.participanteId = :participanteId
    AND i.activa = 1
""")
    fun obtenerMascotasInscritasEnCarrera(carreraId: Long, participanteId: Long): LiveData<List<MascotaEntity>>

    // Agrega este método al final de InscripcionDao.kt
    @Query("""
    SELECT m.* FROM mascotas m
    INNER JOIN inscripciones i ON m.id = i.mascotaId
    WHERE i.carreraId = :carreraId 
    AND i.participanteId = :participanteId
    AND i.activa = 1
""")
    suspend fun obtenerMascotasInscritasSync(carreraId: Long, participanteId: Long): List<MascotaEntity>

    // Contar inscripciones de un participante en una carrera
    @Query("SELECT COUNT(*) FROM inscripciones WHERE carreraId = :carreraId AND participanteId = :participanteId AND activa = 1")
    suspend fun contarInscripcionesDeParticipante(carreraId: Long, participanteId: Long): Int

    // En InscripcionDao.kt, agregar:

    @Query("SELECT * FROM inscripciones WHERE carreraId = :carreraId AND mascotaId = :mascotaId LIMIT 1")
    suspend fun obtenerInscripcionPorCarreraYMascota(carreraId: Long, mascotaId: Long): InscripcionEntity?

}
