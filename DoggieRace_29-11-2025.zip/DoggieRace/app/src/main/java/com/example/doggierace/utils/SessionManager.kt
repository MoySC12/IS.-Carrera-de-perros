package com.example.doggierace.utils

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    companion object {
        private const val PREFS_NAME = "doggierace_session"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_TYPE = "user_type"

        const val USER_TYPE_PARTICIPANTE = "PARTICIPANTE"
        const val USER_TYPE_ORGANIZADOR = "ORGANIZADOR"
    }

    // ========== GUARDAR SESIÓN ==========

    fun guardarSesionParticipante(id: Long, email: String, nombre: String) {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putLong(KEY_USER_ID, id)
            putString(KEY_USER_EMAIL, email)
            putString(KEY_USER_NAME, nombre)
            putString(KEY_USER_TYPE, USER_TYPE_PARTICIPANTE)
            apply()
        }
    }

    fun guardarSesionOrganizador(id: Long, email: String, nombre: String) {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putLong(KEY_USER_ID, id)
            putString(KEY_USER_EMAIL, email)
            putString(KEY_USER_NAME, nombre)
            putString(KEY_USER_TYPE, USER_TYPE_ORGANIZADOR)
            apply()
        }
    }

    // ========== OBTENER DATOS DE SESIÓN ==========

    fun estaLogueado(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    fun obtenerUserId(): Long {
        return prefs.getLong(KEY_USER_ID, -1L)
    }

    fun obtenerUserEmail(): String? {
        return prefs.getString(KEY_USER_EMAIL, null)
    }

    fun obtenerUserName(): String? {
        return prefs.getString(KEY_USER_NAME, null)
    }

    fun obtenerUserType(): String? {
        return prefs.getString(KEY_USER_TYPE, null)
    }

    fun esParticipante(): Boolean {
        return obtenerUserType() == USER_TYPE_PARTICIPANTE
    }

    fun esOrganizador(): Boolean {
        return obtenerUserType() == USER_TYPE_ORGANIZADOR
    }

    // ========== CERRAR SESIÓN ==========

    fun cerrarSesion() {
        prefs.edit().clear().apply()
    }
}
