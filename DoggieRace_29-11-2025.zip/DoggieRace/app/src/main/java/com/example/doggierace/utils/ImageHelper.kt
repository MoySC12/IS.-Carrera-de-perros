package com.example.doggierace.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream

object ImageHelper {

    /**
     * Copia una imagen desde un URI temporal al almacenamiento interno de la app
     * y devuelve el path absoluto del archivo guardado
     */
    fun guardarImagenEnAlmacenamiento(context: Context, uri: Uri, nombreArchivo: String): String? {
        return try {
            // Leer imagen desde el URI
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (bitmap == null) {
                return null
            }

            // Corregir orientación si es necesario
            val bitmapCorregido = corregirOrientacionImagen(context, uri, bitmap)

            // Redimensionar para ahorrar espacio (máximo 1200x1200)
            val bitmapRedimensionado = redimensionarBitmap(bitmapCorregido, 1200, 1200)

            // Crear directorio de carreras si no existe
            val directorioCarreras = File(context.filesDir, "imagenes_carreras")
            if (!directorioCarreras.exists()) {
                directorioCarreras.mkdirs()
            }

            // Crear archivo con nombre único
            val archivoImagen = File(directorioCarreras, "$nombreArchivo.jpg")

            // Guardar imagen
            val outputStream = FileOutputStream(archivoImagen)
            bitmapRedimensionado.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            outputStream.flush()
            outputStream.close()

            // Liberar memoria
            if (bitmap != bitmapCorregido) {
                bitmap.recycle()
            }
            if (bitmapRedimensionado != bitmapCorregido) {
                bitmapCorregido.recycle()
            }
            bitmapRedimensionado.recycle()

            // Devolver path absoluto
            archivoImagen.absolutePath

        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Redimensiona un bitmap manteniendo la proporción
     */
    private fun redimensionarBitmap(bitmap: Bitmap, maxWidth: Int, maxHeight: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height

        if (width <= maxWidth && height <= maxHeight) {
            return bitmap
        }

        val ratioBitmap = width.toFloat() / height.toFloat()
        val ratioMax = maxWidth.toFloat() / maxHeight.toFloat()

        var finalWidth = maxWidth
        var finalHeight = maxHeight

        if (ratioMax > ratioBitmap) {
            finalWidth = (maxHeight.toFloat() * ratioBitmap).toInt()
        } else {
            finalHeight = (maxWidth.toFloat() / ratioBitmap).toInt()
        }

        return Bitmap.createScaledBitmap(bitmap, finalWidth, finalHeight, true)
    }

    /**
     * Corrige la orientación de la imagen según los datos EXIF
     */
    private fun corregirOrientacionImagen(context: Context, uri: Uri, bitmap: Bitmap): Bitmap {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val exif = ExifInterface(inputStream!!)
            inputStream.close()

            val orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )

            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> rotarBitmap(bitmap, 90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> rotarBitmap(bitmap, 180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> rotarBitmap(bitmap, 270f)
                else -> bitmap
            }
        } catch (e: IOException) {
            bitmap
        }
    }

    /**
     * Rota un bitmap
     */
    private fun rotarBitmap(bitmap: Bitmap, grados: Float): Bitmap {
        val matrix = Matrix()
        matrix.postRotate(grados)
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    /**
     * Elimina una imagen del almacenamiento interno
     */
    fun eliminarImagen(path: String?): Boolean {
        if (path.isNullOrEmpty()) return false

        return try {
            val archivo = File(path)
            if (archivo.exists()) {
                archivo.delete()
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Carga un bitmap desde un path
     */
    fun cargarImagenDesdePath(path: String?): Bitmap? {
        if (path.isNullOrEmpty()) return null

        return try {
            val archivo = File(path)
            if (archivo.exists()) {
                BitmapFactory.decodeFile(path)
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
