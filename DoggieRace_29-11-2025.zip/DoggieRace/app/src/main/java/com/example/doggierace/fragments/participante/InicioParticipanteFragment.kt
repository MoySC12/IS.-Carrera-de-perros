package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.R
import com.example.doggierace.adapters.CarreraAdapter
import com.example.doggierace.databinding.FragmentInicioParticipanteBinding
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.CarreraViewModel
import java.text.SimpleDateFormat
import java.util.*

class InicioParticipanteFragment : Fragment() {

    private var _binding: FragmentInicioParticipanteBinding? = null
    private val binding get() = _binding!!

    private lateinit var sessionManager: SessionManager
    private lateinit var carreraAdapter: CarreraAdapter
    private val carreraViewModel: CarreraViewModel by viewModels()

    private var proximaCarrera: CarreraEntity? = null
    private var participanteId: Long = -1L

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInicioParticipanteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())
        participanteId = sessionManager.obtenerUserId()

        cargarSaludoUsuario()
        configurarRecyclerView()
        setupClickListeners()
        cargarCarreras()
    }

    override fun onResume() {
        super.onResume()
        if (::carreraAdapter.isInitialized) {
            recargarCarrerasDisponibles()
        }
    }

    private fun cargarSaludoUsuario() {
        val nombreUsuario = sessionManager.obtenerUserName()
        binding.tvSaludo.text = if (!nombreUsuario.isNullOrEmpty()) {
            "¡Hola, $nombreUsuario!"
        } else {
            "¡Hola, Usuario!"
        }
    }

    private fun setupClickListeners() {
        binding.cardProximaCarrera.setOnClickListener {
            proximaCarrera?.let { carrera ->
                navegarADetalleCarrera(carrera.id)
            }
        }

        binding.tvVerTodas.setOnClickListener {
            findNavController().navigate(R.id.fragmentProximasCarrerasParticipante)
        }
    }

    private fun configurarRecyclerView() {
        carreraAdapter = CarreraAdapter { carrera ->
            navegarADetalleCarrera(carrera.id)
        }

        binding.rvCarrerasDisponibles.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = carreraAdapter
            setHasFixedSize(true)
        }
    }

    private fun cargarCarreras() {
        carreraViewModel.obtenerProximaCarreraConInscripcion(participanteId)
            .observe(viewLifecycleOwner) { carrera ->
                if (carrera != null) {
                    proximaCarrera = carrera
                    mostrarProximaCarrera(carrera)
                } else {
                    mostrarEstadoVacioProximaCarrera()
                }
            }

        carreraViewModel.obtenerCarrerasSinInscripcion(participanteId)
            .observe(viewLifecycleOwner) { carrerasDisponibles ->
                mostrarCarrerasDisponibles(carrerasDisponibles)
            }
    }

    private fun recargarCarrerasDisponibles() {
        carreraViewModel.obtenerCarrerasSinInscripcion(participanteId)
            .observe(viewLifecycleOwner) { carrerasDisponibles ->
                mostrarCarrerasDisponibles(carrerasDisponibles)
            }
    }

    private fun mostrarCarrerasDisponibles(carrerasDisponibles: List<CarreraEntity>) {
        if (carrerasDisponibles.isNotEmpty()) {
            val carrerasAMostrar = carrerasDisponibles.take(5)

            carreraAdapter.submitList(null) {
                carreraAdapter.submitList(carrerasAMostrar.toList()) {
                    binding.rvCarrerasDisponibles.post {
                        carreraAdapter.notifyDataSetChanged()
                    }
                }
            }

            binding.tvCarrerasDisponibles.visibility = View.VISIBLE
            binding.rvCarrerasDisponibles.visibility = View.VISIBLE
        } else {
            carreraAdapter.submitList(emptyList())
            binding.tvCarrerasDisponibles.visibility = View.GONE
            binding.rvCarrerasDisponibles.visibility = View.GONE
        }
    }

    private fun mostrarProximaCarrera(carrera: CarreraEntity) {
        binding.cardProximaCarrera.visibility = View.VISIBLE
        binding.layoutVacioProximaCarrera.visibility = View.GONE

        binding.tvNombreProximaCarrera.text = carrera.nombre

        val formatoFecha = SimpleDateFormat("dd 'de' MMMM - HH:mm", Locale.forLanguageTag("es-ES"))
        val fechaTexto = formatoFecha.format(Date(carrera.fecha))
        binding.tvFechaProximaCarrera.text = "📅 $fechaTexto"

        binding.tvLugarProximaCarrera.text = "📍 ${carrera.ubicacion}"
    }

    private fun mostrarEstadoVacioProximaCarrera() {
        binding.cardProximaCarrera.visibility = View.GONE
        binding.layoutVacioProximaCarrera.visibility = View.VISIBLE
    }

    private fun navegarADetalleCarrera(carreraId: Long) {
        val action = InicioParticipanteFragmentDirections
            .accionInicioADetalleCarrera(carreraId)
        findNavController().navigate(action)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
