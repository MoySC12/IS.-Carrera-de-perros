package com.example.doggierace.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.doggierace.data.entities.AdministradorEntity

@Dao
interface AdministradorDao {

    // ========== INSERTAR ==========
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarAdministrador(administrador: AdministradorEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarAdministradores(administradores: List<AdministradorEntity>): List<Long>

    // ========== ACTUALIZAR ==========
    @Update
    suspend fun actualizarAdministrador(administrador: AdministradorEntity): Int

    @Query("""
        UPDATE administradores 
        SET nombre = :nombre, 
            telefono = :telefono, 
            organizacion = :organizacion, 
            descripcion = :descripcion 
        WHERE id = :id
    """)
    suspend fun actualizarPerfil(
        id: Long,
        nombre: String,
        telefono: String?,
        organizacion: String?,
        descripcion: String?
    ): Int

    @Query("UPDATE administradores SET foto_perfil_uri = :uri WHERE id = :id")
    suspend fun actualizarFotoPerfil(id: Long, uri: String?): Int

    @Query("UPDATE administradores SET password = :nuevaPassword WHERE id = :id")
    suspend fun actualizarPassword(id: Long, nuevaPassword: String): Int

    // ========== ELIMINAR ==========
    @Delete
    suspend fun eliminarAdministrador(administrador: AdministradorEntity): Int

    @Query("DELETE FROM administradores WHERE id = :id")
    suspend fun eliminarAdministradorPorId(id: Long): Int

    @Query("DELETE FROM administradores")
    suspend fun eliminarTodosAdministradores(): Int

    // ========== CONSULTAS ==========
    @Query("SELECT * FROM administradores WHERE id = :id")
    suspend fun obtenerAdministradorPorId(id: Long): AdministradorEntity?

    @Query("SELECT * FROM administradores WHERE id = :id")
    fun obtenerAdministradorPorIdLiveData(id: Long): LiveData<AdministradorEntity?>

    @Query("SELECT * FROM administradores WHERE email = :email LIMIT 1")
    suspend fun obtenerAdministradorPorEmail(email: String): AdministradorEntity?

    @Query("""
        SELECT * FROM administradores 
        WHERE email = :email AND password = :password 
        LIMIT 1
    """)
    suspend fun login(email: String, password: String): AdministradorEntity?

    @Query("SELECT * FROM administradores WHERE activo = 1")
    fun obtenerAdministradoresActivos(): LiveData<List<AdministradorEntity>>

    @Query("SELECT * FROM administradores ORDER BY fecha_registro DESC")
    fun obtenerTodosAdministradores(): LiveData<List<AdministradorEntity>>

    @Query("SELECT * FROM administradores ORDER BY fecha_registro DESC")
    suspend fun obtenerTodosAdministradoresSuspend(): List<AdministradorEntity>

    @Query("SELECT COUNT(*) FROM administradores WHERE email = :email")
    suspend fun verificarEmailExistente(email: String): Int

    @Query("SELECT COUNT(*) FROM administradores")
    suspend fun contarAdministradores(): Int

    @Query("""
    UPDATE administradores 
    SET titular_cuenta = :titular,
        banco = :banco,
        clabe = :clabe
    WHERE id = :organizadorId
    """)
    suspend fun actualizarCuentaBancaria(
        organizadorId: Long,
        titular: String,
        banco: String,
        clabe: String
    ): Int

}
