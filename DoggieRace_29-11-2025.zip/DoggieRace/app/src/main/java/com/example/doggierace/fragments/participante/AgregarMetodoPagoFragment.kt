package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentAgregarMetodoPagoBinding
import com.example.doggierace.data.entities.MetodoPagoEntity
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.MetodoPagoViewModel
import java.util.Calendar

class AgregarMetodoPagoFragment : Fragment() {

    private var _binding: FragmentAgregarMetodoPagoBinding? = null
    private val binding get() = _binding!!

    private val metodoPagoViewModel: MetodoPagoViewModel by viewModels()
    private lateinit var sessionManager: SessionManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAgregarMetodoPagoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sessionManager = SessionManager(requireContext())

        setupToolbar()
        configurarSpinnerTipoTarjeta()
        configurarFormato()
        configurarBotones()
        observarResultados()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun configurarSpinnerTipoTarjeta() {
        val tiposTarjeta = arrayOf("VISA", "MASTERCARD", "AMEX")
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            tiposTarjeta
        )
        binding.spinnerTipoTarjeta.setAdapter(adapter)
    }

    private fun configurarFormato() {
        binding.etVencimiento.addTextChangedListener(object : TextWatcher {
            private var isEditing = false

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                if (isEditing || s.isNullOrEmpty()) return

                isEditing = true

                // Eliminar todo lo que no sea número
                val clean = s.toString().replace("[^0-9]".toRegex(), "")

                val formatted = StringBuilder()
                for (i in clean.indices) {
                    if (i == 2) formatted.append("/")
                    if (i < 4) formatted.append(clean[i])
                }

                s.clear()
                s.append(formatted.toString())

                isEditing = false
            }
        })
    }



    private fun configurarBotones() {
        binding.btnGuardar.setOnClickListener {
            guardarMetodoPago()
        }
    }

    private fun guardarMetodoPago() {
        val tipo = binding.spinnerTipoTarjeta.text.toString().trim()
        val numeroCompleto = binding.etNumeroTarjeta.text.toString().trim()
        val nombreTitular = binding.etNombreTitular.text.toString().trim().uppercase()
        val vencimiento = binding.etVencimiento.text.toString().trim()
        val cvv = binding.etCvv.text.toString().trim()
        val esPredeterminada = binding.checkboxPredeterminada.isChecked

        // Validaciones
        if (!validarCampos(tipo, numeroCompleto, nombreTitular, vencimiento, cvv)) {
            return
        }

        // Guardar solo últimos 4 dígitos
        val ultimos4Digitos = numeroCompleto.takeLast(4)

        val participanteId = sessionManager.obtenerUserId()
        if (participanteId == -1L) {
            Toast.makeText(requireContext(), "Error: No hay sesión activa", Toast.LENGTH_SHORT).show()
            return
        }

        val metodoPago = MetodoPagoEntity(
            participanteId = participanteId,
            tipo = tipo,
            numeroTarjeta = ultimos4Digitos,
            nombreTitular = nombreTitular,
            fechaVencimiento = vencimiento,
            esPredeterminada = esPredeterminada,
            activa = true  // ✅ AGREGAR ESTA LÍNEA
        )


        binding.progressBar.visibility = View.VISIBLE
        metodoPagoViewModel.insertarMetodoPago(metodoPago)

        // En AgregarMetodoPagoFragment, agrega un log después de crear el objeto:
        Log.d("MetodoPago", "Guardando: activa=${metodoPago.activa}")

    }

    private fun validarCampos(
        tipo: String,
        numero: String,
        titular: String,
        vencimiento: String,
        cvv: String
    ): Boolean {

        if (tipo.isEmpty()) {
            binding.tilTipoTarjeta.error = "Selecciona el tipo de tarjeta"
            Toast.makeText(requireContext(), "Selecciona el tipo de tarjeta", Toast.LENGTH_SHORT).show()
            return false
        }

        if (numero.isEmpty() || numero.length < 13) {
            binding.tilNumeroTarjeta.error = "Número de tarjeta inválido"
            Toast.makeText(requireContext(), "El número de tarjeta debe tener al menos 13 dígitos", Toast.LENGTH_SHORT).show()
            return false
        }

        if (titular.isEmpty() || titular.length < 3) {
            binding.tilNombreTitular.error = "Nombre inválido"
            Toast.makeText(requireContext(), "Ingresa el nombre del titular", Toast.LENGTH_SHORT).show()
            return false
        }

        if (vencimiento.isEmpty() || !vencimiento.matches(Regex("\\d{2}/\\d{2}"))) {
            binding.tilVencimiento.error = "Formato inválido (MM/AA)"
            Toast.makeText(requireContext(), "Ingresa una fecha válida (MM/AA)", Toast.LENGTH_SHORT).show()
            return false
        }

        if (cvv.isEmpty() || cvv.length < 3) {
            binding.tilCvv.error = "CVV inválido"
            Toast.makeText(requireContext(), "El CVV debe tener 3 o 4 dígitos", Toast.LENGTH_SHORT).show()
            return false
        }

        // Validar formato y valores de la fecha
        if (vencimiento.isEmpty() || !vencimiento.matches(Regex("^(0[1-9]|1[0-2])/\\d{2}$"))) {
            binding.tilVencimiento.error = "Formato inválido (MM/AA)"
            Toast.makeText(requireContext(), "Ingresa una fecha válida (MM/AA)", Toast.LENGTH_SHORT).show()
            return false
        }

        // Validar que no esté vencida
        val partes = vencimiento.split("/")
        val mes = partes[0].toInt()
        val anio = 2000 + partes[1].toInt() // Convertir AA a AAAA

        val calendar = Calendar.getInstance()
        val mesActual = calendar.get(Calendar.MONTH) + 1
        val anioActual = calendar.get(Calendar.YEAR)

        if (anio < anioActual || (anio == anioActual && mes < mesActual)) {
            binding.tilVencimiento.error = "Tarjeta vencida"
            Toast.makeText(requireContext(), "La tarjeta está vencida", Toast.LENGTH_SHORT).show()
            return false
        }


        return true
    }

    private fun observarResultados() {
        metodoPagoViewModel.resultadoOperacion.observe(viewLifecycleOwner) { resultado ->
            binding.progressBar.visibility = View.GONE

            when (resultado) {
                is MetodoPagoViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(requireContext(), "✓ ${resultado.mensaje}", Toast.LENGTH_SHORT).show()
                    findNavController().popBackStack()
                }
                is MetodoPagoViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(requireContext(), "❌ ${resultado.mensaje}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
