package com.example.doggierace.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.doggierace.data.database.DoggieRaceDatabase
import com.example.doggierace.data.entities.AdministradorEntity
import com.example.doggierace.data.repository.AdministradorRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AdministradorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AdministradorRepository
    val todosAdministradores: LiveData<List<AdministradorEntity>>
    val administradoresActivos: LiveData<List<AdministradorEntity>>

    // LiveData para resultados de operaciones
    private val _resultadoOperacion = MutableLiveData<ResultadoOperacion>()
    val resultadoOperacion: LiveData<ResultadoOperacion> = _resultadoOperacion

    private val _administradorActual = MutableLiveData<AdministradorEntity?>()
    val administradorActual: LiveData<AdministradorEntity?> = _administradorActual

    init {
        val administradorDao = DoggieRaceDatabase.getDatabase(application).administradorDao()
        repository = AdministradorRepository(administradorDao)
        todosAdministradores = repository.todosAdministradores
        administradoresActivos = repository.administradoresActivos
    }

    // ========== OPERACIONES CRUD ==========

    fun insertarAdministrador(administrador: AdministradorEntity) = viewModelScope.launch {
        try {
            val id = repository.insertarAdministrador(administrador)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Administrador registrado con ID: $id")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al registrar: ${e.message}")
            )
        }
    }

    fun actualizarPerfil(
        id: Long,
        nombre: String,
        telefono: String?,
        organizacion: String?,
        descripcion: String?
    ) = viewModelScope.launch {
        try {
            val filasActualizadas = repository.actualizarPerfil(
                id, nombre, telefono, organizacion, descripcion
            )
            if (filasActualizadas > 0) {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Exito("Perfil actualizado correctamente")
                )
            } else {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("No se pudo actualizar el perfil")
                )
            }
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error: ${e.message}")
            )
        }
    }

    fun actualizarFotoPerfil(id: Long, uri: String?) = viewModelScope.launch {
        try {
            repository.actualizarFotoPerfil(id, uri)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Foto actualizada")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al actualizar foto: ${e.message}")
            )
        }
    }

    fun actualizarPassword(id: Long, passwordAntigua: String, passwordNueva: String) =
        viewModelScope.launch {
            try {
                // Primero verificar la contraseña antigua
                val admin = repository.obtenerAdministradorPorId(id)
                if (admin?.password == passwordAntigua) {
                    repository.actualizarPassword(id, passwordNueva)
                    _resultadoOperacion.postValue(
                        ResultadoOperacion.Exito("Contraseña actualizada")
                    )
                } else {
                    _resultadoOperacion.postValue(
                        ResultadoOperacion.Error("Contraseña antigua incorrecta")
                    )
                }
            } catch (e: Exception) {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("Error: ${e.message}")
                )
            }
        }

    // ========== LOGIN Y REGISTRO ==========

    fun login(email: String, password: String) = viewModelScope.launch {
        try {
            val administrador = repository.login(email, password)
            if (administrador != null && administrador.activo) {
                _administradorActual.postValue(administrador)
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Exito("Login exitoso")
                )
            } else {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("Email o contraseña incorrectos")
                )
            }
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error en login: ${e.message}")
            )
        }
    }

    suspend fun verificarEmailExistente(email: String): Boolean {
        return withContext(Dispatchers.IO) {
            repository.verificarEmailExistente(email)
        }
    }

    fun cargarAdministradorPorId(id: Long) = viewModelScope.launch {
        try {
            val admin = repository.obtenerAdministradorPorId(id)
            _administradorActual.postValue(admin)
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al cargar administrador: ${e.message}")
            )
        }
    }

    fun cerrarSesion() {
        _administradorActual.postValue(null)
    }


    // ✅ NUEVO: Obtener administrador por ID (suspendido)
    suspend fun obtenerAdministradorPorId(id: Long): AdministradorEntity? {
        return withContext(Dispatchers.IO) {
            repository.obtenerAdministradorPorId(id)
        }
    }

    // ✅ NUEVO: Actualizar cuenta bancaria
    fun actualizarCuentaBancaria(
        organizadorId: Long,
        titular: String,
        banco: String,
        clabe: String
    ) = viewModelScope.launch {
        try {
            val filasActualizadas = repository.actualizarCuentaBancaria(organizadorId, titular, banco, clabe)
            if (filasActualizadas > 0) {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Exito("Cuenta bancaria actualizada")
                )
            } else {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("No se pudo actualizar")
                )
            }
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error: ${e.message}")
            )
        }
    }


    // ========== CLASE RESULTADO ==========

    sealed class ResultadoOperacion {
        data class Exito(val mensaje: String) : ResultadoOperacion()
        data class Error(val mensaje: String) : ResultadoOperacion()
    }
    // Agregar al final de la clase AdministradorViewModel
    suspend fun obtenerAdministradorPorEmail(email: String): AdministradorEntity? {
        return withContext(Dispatchers.IO) {
            repository.obtenerAdministradorPorEmail(email)
        }
    }

}
