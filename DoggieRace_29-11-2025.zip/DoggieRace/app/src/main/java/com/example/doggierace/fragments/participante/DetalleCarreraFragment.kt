package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.adapters.PerroInscritoAdapter
import com.example.doggierace.databinding.FragmentDetalleCarreraBinding
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.utils.ImageHelper
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.CarreraViewModel
import com.example.doggierace.viewmodels.InscripcionViewModel
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class DetalleCarreraFragment : Fragment() {

    private var _binding: FragmentDetalleCarreraBinding? = null
    private val binding get() = _binding!!

    private val carreraViewModel: CarreraViewModel by viewModels()
    private val inscripcionViewModel: InscripcionViewModel by viewModels()
    private val args: DetalleCarreraFragmentArgs by navArgs()

    private lateinit var sessionManager: SessionManager
    private lateinit var perroAdapter: PerroInscritoAdapter

    private var carreraActual: CarreraEntity? = null
    private var participanteId: Long = 0L
    private var listaVisible = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetalleCarreraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())
        participanteId = sessionManager.obtenerUserId()

        val carreraId = args.carreraId

        // ✅ LISTENER para actualizar el botón al regresar de InscribirMascotaFragment
        findNavController().currentBackStackEntry?.savedStateHandle?.getLiveData<Boolean>("actualizarBoton")?.observe(viewLifecycleOwner) { actualizar ->
            if (actualizar == true) {
                // Simplemente recargar la carrera actual
                carreraActual?.let {
                    configurarBotonInscripcion()
                }
                // Limpiar flag
                findNavController().currentBackStackEntry?.savedStateHandle?.set("actualizarBoton", false)
            }
        }

        setupToolbar()
        configurarRecyclerView()
        cargarDetalleCarrera()
    }


    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }


    private fun configurarRecyclerView() {
        perroAdapter = PerroInscritoAdapter()
        binding.rvPerrosInscritos.adapter = perroAdapter
    }

    private fun cargarDetalleCarrera() {
        val carreraId = args.carreraId
        carreraViewModel.cargarCarreraPorId(carreraId)

        carreraViewModel.carreraActual.observe(viewLifecycleOwner) { carrera ->
            if (carrera != null) {
                carreraActual = carrera
                mostrarDetalles(carrera)
                configurarBotonInscripcion()
            } else {
                Toast.makeText(requireContext(), "Carrera no encontrada", Toast.LENGTH_LONG).show()
                findNavController().popBackStack()
            }
        }
    }

    private fun mostrarDetalles(carrera: CarreraEntity) {
        // Título
        binding.toolbar.title = carrera.nombre
        binding.tvTituloCarrera.text = carrera.nombre

        // Fecha y hora
        val formatoFecha = SimpleDateFormat("dd 'de' MMMM, yyyy", Locale.forLanguageTag("es-ES"))
        val fechaTexto = "${formatoFecha.format(Date(carrera.fecha))} - ${carrera.horaInicio}"
        binding.tvFechaDetalle.text = fechaTexto

        // Lugar
        val lugarCompleto = if (carrera.ciudad.isNotEmpty() && carrera.ciudad != "Ciudad") {
            "${carrera.ubicacion}, ${carrera.ciudad}"
        } else {
            carrera.ubicacion
        }
        binding.tvLugarDetalle.text = lugarCompleto

        // Tipo de carrera
        binding.tvTipoCarrera.text = carrera.categoria

        // Categorías
        binding.tvCategorias.text = "Todos los perros pueden participar (cualquier tamaño)"

        // Requisitos con edad mínima
        val requisitosTexto = if (!carrera.requisitos.isNullOrEmpty()) {
            "• Edad mínima: ${carrera.edadMinima} año(s)\n${carrera.requisitos}"
        } else {
            "• Edad mínima: ${carrera.edadMinima} año(s)\n• Vacunas al día\n• Certificado de salud"
        }
        binding.tvRequisitos.text = requisitosTexto

        // Descripción/Seguridad
        binding.tvSeguridad.text = carrera.descripcion.ifEmpty {
            "Veterinario en sitio y puntos de hidratación"
        }

        // Costo
        val formatoCosto = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
        val costoTexto = if (carrera.costoInscripcion > 0) {
            "${formatoCosto.format(carrera.costoInscripcion)} por perro"
        } else {
            "Gratis"
        }
        binding.tvCosto.text = costoTexto


        // Cupos disponibles
        val cuposTexto = "${carrera.cuposDisponibles} cupos disponibles de ${carrera.cuposTotales}"
        binding.tvCuposDisponibles.text = cuposTexto

        // Cargar imagen del circuito
        carrera.imagenUri?.let { path ->
            val bitmap = ImageHelper.cargarImagenDesdePath(path)
            if (bitmap != null) {
                binding.imgMapaEstatico.setImageBitmap(bitmap)
                binding.imgMapaEstatico.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            } else {
                binding.imgMapaEstatico.setImageResource(android.R.drawable.ic_menu_gallery)
                binding.imgMapaEstatico.scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            }
        } ?: run {
            binding.imgMapaEstatico.setImageResource(android.R.drawable.ic_menu_gallery)
            binding.imgMapaEstatico.scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
        }
    }

    private fun configurarBotonInscripcion() {
        carreraActual?.let { carrera ->
            lifecycleScope.launch {
                try {
                    val tieneInscripciones = inscripcionViewModel.participanteTieneInscripcion(
                        carrera.id,
                        participanteId
                    )

                    if (tieneInscripciones) {
                        configurarBotonMisInscripciones(carrera)
                    } else {
                        configurarBotonInscribir(carrera)
                    }

                } catch (e: Exception) {
                    configurarBotonInscribir(carrera)
                }
            }
        }
    }

    private suspend fun configurarBotonMisInscripciones(carrera: CarreraEntity) {
        val cantidad = inscripcionViewModel.contarInscripcionesDeParticipante(
            carrera.id,
            participanteId
        )

        // ✅ SIEMPRE mostrar lista automáticamente
        cargarPerrosInscritos(carrera.id)
        binding.rvPerrosInscritos.visibility = View.VISIBLE
        binding.tvPerrosInscritos.visibility = View.VISIBLE
        listaVisible = true

        // ✅ Configurar botón según cupos y cantidad de inscritos
        val hayCupos = carrera.cuposDisponibles > 0
        val tieneInscripciones = cantidad > 0

        when {
            // CASO 1: HAY CUPOS → Permitir inscribir más perros
            hayCupos -> {
                binding.btnInscribirPerro.isEnabled = true
                binding.btnInscribirPerro.alpha = 1.0f
                binding.btnInscribirPerro.text = if (cantidad == 1) {
                    "+ Inscribir otra mascota (1 inscrita)"
                } else {
                    "+ Inscribir otra mascota ($cantidad inscritas)"
                }
            }

            // CASO 2: SIN CUPOS PERO CON PERROS INSCRITOS → Permitir entrar para eliminar
            tieneInscripciones -> {
                binding.btnInscribirPerro.isEnabled = true
                binding.btnInscribirPerro.alpha = 1.0f
                binding.btnInscribirPerro.text = if (cantidad == 1) {
                    "Ver mi mascota inscrita (Sin cupos)"
                } else {
                    "Ver mis $cantidad mascotas inscritas (Sin cupos)"
                }
            }

            // CASO 3: SIN CUPOS Y SIN PERROS INSCRITOS → NO permitir entrar
            else -> {
                binding.btnInscribirPerro.isEnabled = false
                binding.btnInscribirPerro.alpha = 0.5f
                binding.btnInscribirPerro.text = "Sin cupos disponibles"
            }
        }

        // ✅ Acción del botón
        binding.btnInscribirPerro.setOnClickListener {
            if (hayCupos || tieneInscripciones) {
                inscribirPerro(carrera)
            } else {
                Toast.makeText(
                    requireContext(),
                    "No hay cupos disponibles",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun configurarBotonInscribir(carrera: CarreraEntity) {
        if (carrera.cuposDisponibles <= 0) {
            binding.btnInscribirPerro.isEnabled = false
            binding.btnInscribirPerro.text = "Sin cupos disponibles"
        } else if (carrera.estado != CarreraEntity.ESTADO_PROXIMA) {
            binding.btnInscribirPerro.isEnabled = false
            binding.btnInscribirPerro.text = "Inscripciones cerradas"
        } else {
            binding.btnInscribirPerro.isEnabled = true
            binding.btnInscribirPerro.text = "Inscribir Mascota"

            binding.btnInscribirPerro.setOnClickListener {
                inscribirPerro(carrera)
            }
        }
    }

    private fun cargarPerrosInscritos(carreraId: Long) {
        lifecycleScope.launch {
            val mascotas = inscripcionViewModel.obtenerMascotasInscritasSync(carreraId, participanteId)
            if (mascotas.isNotEmpty()) {
                binding.tvPerrosInscritos.visibility = View.VISIBLE
                binding.rvPerrosInscritos.visibility = View.VISIBLE
                perroAdapter.submitList(mascotas)
                listaVisible = true
            } else {
                binding.tvPerrosInscritos.visibility = View.GONE
                binding.rvPerrosInscritos.visibility = View.GONE
                listaVisible = false
            }
        }
    }

    private fun inscribirPerro(carrera: CarreraEntity) {
        // ✅ SIEMPRE NAVEGAR - La validación se hace DENTRO de InscribirMascotaFragment
        val action = DetalleCarreraFragmentDirections
            .accionDetalleAInscribir(
                carreraId = carrera.id,
                carreraNombre = carrera.nombre
            )
        findNavController().navigate(action)
    }

    override fun onResume() {
        super.onResume()
        carreraActual?.let {
            carreraViewModel.cargarCarreraPorId(it.id)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
        listaVisible = false
    }
}
