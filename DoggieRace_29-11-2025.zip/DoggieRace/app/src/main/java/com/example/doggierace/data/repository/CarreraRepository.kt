package com.example.doggierace.data.repository

import androidx.lifecycle.LiveData
import com.example.doggierace.data.dao.CarreraDao
import com.example.doggierace.data.entities.CarreraEntity

class CarreraRepository(private val carreraDao: CarreraDao) {

    // ========== INSERTAR ==========
    suspend fun insertarCarrera(carrera: CarreraEntity): Long {
        return carreraDao.insertarCarrera(carrera)
    }

    // ========== ACTUALIZAR ==========
    suspend fun actualizarCarrera(carrera: CarreraEntity): Int {
        return carreraDao.actualizarCarrera(carrera)
    }

    suspend fun actualizarEstado(id: Long, estado: String): Int {
        return carreraDao.actualizarEstado(id, estado)
    }

    suspend fun decrementarCupoDisponible(id: Long): Int {
        return carreraDao.decrementarCupoDisponible(id)
    }

    suspend fun incrementarCupoDisponible(id: Long): Int {
        return carreraDao.incrementarCupoDisponible(id)
    }

    // ========== ELIMINAR ==========
    suspend fun eliminarCarrera(id: Long): Int {
        return carreraDao.eliminarCarreraPorId(id)
    }

    // ========== CONSULTAS GENERALES ==========
    suspend fun obtenerCarreraPorId(id: Long): CarreraEntity? {
        return carreraDao.obtenerCarreraPorId(id)
    }

    fun obtenerCarreraPorIdLiveData(id: Long): LiveData<CarreraEntity?> {
        return carreraDao.obtenerCarreraPorIdLiveData(id)
    }

    fun obtenerProximasCarrerasParticipante(): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerProximasCarrerasParticipante()
    }

    fun obtenerProximasCarrerasOrganizador(fechaActual: Long): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerProximasCarrerasOrganizador(fechaActual)
    }

    fun obtenerCarrerasFinalizadas(): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerCarrerasFinalizadas()
    }

    fun obtenerCarrerasPorCategoria(categoria: String): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerCarrerasPorCategoria(categoria)
    }

    fun buscarCarreras(busqueda: String): LiveData<List<CarreraEntity>> {
        return carreraDao.buscarCarreras(busqueda)
    }

    // ========== CONSULTAS PARA ORGANIZADOR ==========
    fun obtenerCarrerasDeOrganizador(organizadorId: Long): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerCarrerasDeOrganizador(organizadorId)
    }

    suspend fun contarCarrerasDeOrganizador(organizadorId: Long): Int {
        return carreraDao.contarCarrerasDeOrganizador(organizadorId)
    }

    // ========== CONSULTAS PARA PARTICIPANTES ==========

    /**
     * Obtiene carreras donde el participante NO tiene inscripción
     * Para "Carreras Disponibles"
     */
    fun obtenerCarrerasSinInscripcion(participanteId: Long, fechaActual: Long): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerCarrerasSinInscripcion(participanteId, fechaActual)
    }

    /**
     * Obtiene la próxima carrera donde el participante SÍ tiene inscripción
     * Para "Tu Próxima Carrera"
     */
    fun obtenerProximaCarreraConInscripcion(participanteId: Long, fechaActual: Long): LiveData<CarreraEntity?> {
        return carreraDao.obtenerProximaCarreraConInscripcion(participanteId, fechaActual)
    }

    /**
     * Obtiene todas las carreras próximas con inscripción
     * Para "Ver todas mis próximas carreras"
     */
    fun obtenerCarrerasInscritasProximas(participanteId: Long, fechaActual: Long): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerCarrerasInscritasProximas(participanteId, fechaActual)
    }

    /**
     * Obtiene carreras finalizadas con inscripción
     * Para historial
     */
    fun obtenerCarrerasInscritasFinalizadas(participanteId: Long): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerCarrerasInscritasFinalizadas(participanteId)
    }

    /**
     * Obtiene TODAS las carreras con inscripción (próximas + finalizadas)
     */
    fun obtenerProximasCarrerasParticipanteInscritas(participanteId: Long): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerProximasCarrerasParticipanteInscritas(participanteId)
    }

    // ========== MÉTODOS ADICIONALES ==========

    /**
     * Actualiza datos específicos de la carrera
     */
    suspend fun actualizarDatosCarrera(
        id: Long,
        nombre: String,
        descripcion: String,
        fecha: Long,
        horaInicio: String,
        ubicacion: String,
        direccion: String,
        ciudad: String,
        categoria: String,
        precioInscripcion: Double,
        cuposTotales: Int
    ): Int {
        return carreraDao.actualizarDatosCarrera(
            id, nombre, descripcion, fecha, horaInicio,
            ubicacion, direccion, ciudad, categoria,
            precioInscripcion, cuposTotales
        )
    }

    /**
     * Actualiza la imagen de la carrera
     */
    suspend fun actualizarImagenCarrera(id: Long, uri: String?): Int {
        return carreraDao.actualizarImagenCarrera(id, uri)
    }

    /**
     * Inscribe un participante (decrementa cupo disponible)
     */
    suspend fun inscribirParticipante(carreraId: Long): Boolean {
        val resultado = carreraDao.decrementarCupoDisponible(carreraId)
        return resultado > 0
    }

    /**
     * Cancela inscripción (incrementa cupo disponible)
     */
    suspend fun cancelarInscripcion(carreraId: Long) {
        carreraDao.incrementarCupoDisponible(carreraId)
    }

    /**
     * Obtiene carreras por estado específico
     */
    fun obtenerCarrerasPorEstado(estado: String): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerCarrerasPorEstado(estado)
    }

    /**
     * Obtiene carreras por ciudad
     */
    fun obtenerCarrerasPorCiudad(ciudad: String): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerCarrerasPorCiudad(ciudad)
    }

    /**
     * Obtiene carreras en un rango de fechas
     */
    fun obtenerCarrerasPorRangoFecha(fechaInicio: Long, fechaFin: Long): LiveData<List<CarreraEntity>> {
        return carreraDao.obtenerCarrerasPorRangoFecha(fechaInicio, fechaFin)
    }

    /**
     * Cuenta carreras por estado de un organizador
     */
    suspend fun contarCarrerasPorEstado(organizadorId: Long, estado: String): Int {
        return carreraDao.contarCarrerasPorEstado(organizadorId, estado)
    }

    /**
     * Obtiene carreras por lista de IDs
     */
    suspend fun obtenerCarrerasPorIds(ids: List<Long>): List<CarreraEntity> {
        return carreraDao.obtenerCarrerasPorIds(ids)
    }

    
}
