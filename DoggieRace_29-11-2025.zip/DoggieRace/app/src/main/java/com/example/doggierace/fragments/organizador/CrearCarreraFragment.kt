package com.example.doggierace.fragments.organizador

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentCrearCarreraBinding
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.utils.ImageHelper
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.CarreraViewModel
import java.text.SimpleDateFormat
import java.util.*

class CrearCarreraFragment : Fragment() {

    private var _binding: FragmentCrearCarreraBinding? = null
    private val binding get() = _binding!!

    private val carreraViewModel: CarreraViewModel by viewModels()
    private lateinit var sessionManager: SessionManager

    private var imagenCircuitoUri: Uri? = null
    private var fechaSeleccionadaTimestamp: Long = 0

    private val seleccionarImagenLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            imagenCircuitoUri = it
            binding.imgCircuitoPlaceholder.setImageURI(it)
            binding.imgCircuitoPlaceholder.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCrearCarreraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())

        setupToolbar()
        setupDropdownCategoria()
        setupClickListeners()
        observarResultados()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }


    private fun setupDropdownCategoria() {
        val categorias = resources.getStringArray(R.array.tipos_carrera)
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            categorias
        )
        binding.autocompleteTipoCarrera.setAdapter(adapter)
    }

    private fun setupClickListeners() {
        binding.btnSubirImagen.setOnClickListener {
            seleccionarImagenLauncher.launch("image/*")
        }

        binding.etFecha.setOnClickListener {
            mostrarDatePicker()
        }

        binding.btnGuardarCarrera.setOnClickListener {
            guardarCarrera()
        }
    }

    private fun mostrarDatePicker() {
        val calendario = Calendar.getInstance()
        val anio = calendario.get(Calendar.YEAR)
        val mes = calendario.get(Calendar.MONTH)
        val dia = calendario.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                val fechaSeleccionada = Calendar.getInstance()
                fechaSeleccionada.set(year, month, dayOfMonth)

                fechaSeleccionadaTimestamp = fechaSeleccionada.timeInMillis

                val formatoFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                binding.etFecha.setText(formatoFecha.format(fechaSeleccionada.time))

                mostrarTimePicker()
            },
            anio,
            mes,
            dia
        )

        datePickerDialog.datePicker.minDate = System.currentTimeMillis()
        datePickerDialog.show()
    }

    private fun mostrarTimePicker() {
        val calendario = Calendar.getInstance()
        val hora = calendario.get(Calendar.HOUR_OF_DAY)
        val minutos = calendario.get(Calendar.MINUTE)

        TimePickerDialog(
            requireContext(),
            { _, hourOfDay, minute ->
                val horaFormateada = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute)
                Toast.makeText(requireContext(), "Hora de inicio: $horaFormateada", Toast.LENGTH_SHORT).show()
            },
            hora,
            minutos,
            true
        ).show()
    }

    private fun guardarCarrera() {
        limpiarErrores()
        val nombre = binding.etNombre.text.toString().trim()
        val categoria = binding.autocompleteTipoCarrera.text.toString().trim()
        val fecha = binding.etFecha.text.toString().trim()
        val ubicacion = binding.etLugar.text.toString().trim()
        val cupoStr = binding.etCupo.text.toString().trim()
        val edadMinimaStr = binding.etEdadMinima.text.toString().trim()
        val prohibiciones = binding.etProhibiciones.text.toString().trim()
        val costo = binding.etCostoInscripcion.text.toString().toDoubleOrNull() ?: 0.0

        if (!validarCampos(nombre, categoria, fecha, ubicacion, cupoStr, edadMinimaStr)) {
            return
        }

        // ✅ CONVERTIR A NÚMEROS
        val cupo = cupoStr.toIntOrNull() ?: 0
        val edadMinima = edadMinimaStr.toIntOrNull() ?: 1  // 👈 ESTO FALTABA

        val organizadorId = sessionManager.obtenerUserId()

        if (organizadorId == -1L) {
            Toast.makeText(requireContext(), "Error: No hay sesión activa", Toast.LENGTH_SHORT).show()
            return
        }

        val imagenPath = imagenCircuitoUri?.let { uri ->
            val nombreArchivo = "carrera_${System.currentTimeMillis()}"
            ImageHelper.guardarImagenEnAlmacenamiento(requireContext(), uri, nombreArchivo)
        }

        // ✅ CREAR ENTIDAD CON EDAD MÍNIMA

        val nuevaCarrera = CarreraEntity(
            organizadorId = organizadorId,
            nombre = nombre,
            descripcion = prohibiciones.ifEmpty { "Sin descripción" },
            fecha = fechaSeleccionadaTimestamp,
            horaInicio = "09:00",
            ubicacion = ubicacion,
            direccion = ubicacion,
            ciudad = "Ciudad",
            categoria = categoria,
            costoInscripcion = costo,
            cuposTotales = cupo,
            cuposDisponibles = cupo,
            estado = CarreraEntity.ESTADO_PROXIMA,
            edadMinima = edadMinima,  // 👈 AGREGAR ESTO
            imagenUri = imagenPath,
            requisitos = null,  // 👈 CAMBIAR A null o eliminar texto duplicado
            activa = true
        )

        carreraViewModel.insertarCarrera(nuevaCarrera)
    }

    private fun validarCampos(
        nombre: String,
        categoria: String,
        fecha: String,
        ubicacion: String,
        cupo: String,
        edadMinima: String
    ): Boolean {

        if (nombre.isEmpty()) {
            binding.inputLayoutNombre.error = "El nombre es obligatorio"
            binding.etNombre.requestFocus()
            return false
        }

        if (categoria.isEmpty()) {
            binding.inputLayoutTipoCarrera.error = "Selecciona una categoría"
            binding.autocompleteTipoCarrera.requestFocus()
            return false
        }

        if (fecha.isEmpty()) {
            binding.inputLayoutFecha.error = "La fecha es obligatoria"
            binding.etFecha.requestFocus()
            return false
        }

        if (ubicacion.isEmpty()) {
            binding.inputLayoutLugar.error = "El lugar es obligatorio"
            binding.etLugar.requestFocus()
            return false
        }

        if (cupo.isEmpty()) {
            binding.inputLayoutCupo.error = "El cupo es obligatorio"
            binding.etCupo.requestFocus()
            return false
        }

        val cupoNum = cupo.toIntOrNull()
        if (cupoNum == null || cupoNum <= 0) {
            binding.inputLayoutCupo.error = "Cupo inválido"
            binding.etCupo.requestFocus()
            return false
        }

        if (edadMinima.isEmpty()) {
            binding.inputLayoutEdadMinima.error = "La edad mínima es obligatoria"
            binding.etEdadMinima.requestFocus()
            return false
        }

        val edadNum = edadMinima.toIntOrNull()
        if (edadNum == null || edadNum < 0 || edadNum > 20) {
            binding.inputLayoutEdadMinima.error = "Edad inválida (0-20 años)"
            binding.etEdadMinima.requestFocus()
            return false
        }
        if (binding.etCostoInscripcion.text.toString().isEmpty()) {
            binding.etCostoInscripcion.error = "Ingresa el costo de inscripción (0 para gratis)"
            return false
        }


        return true
    }

    private fun limpiarErrores() {
        binding.inputLayoutNombre.error = null
        binding.inputLayoutTipoCarrera.error = null
        binding.inputLayoutFecha.error = null
        binding.inputLayoutLugar.error = null
        binding.inputLayoutCupo.error = null
        binding.inputLayoutEdadMinima.error = null
    }

    private fun observarResultados() {
        carreraViewModel.resultadoOperacion.observe(viewLifecycleOwner) { resultado ->
            when (resultado) {
                is CarreraViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(requireContext(), "Carrera creada exitosamente", Toast.LENGTH_SHORT).show()
                    findNavController().popBackStack()
                }
                is CarreraViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(requireContext(), resultado.mensaje, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
