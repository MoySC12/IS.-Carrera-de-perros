package com.example.doggierace.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.doggierace.data.database.DoggieRaceDatabase
import com.example.doggierace.data.entities.MascotaEntity
import com.example.doggierace.data.repository.MascotaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MascotaViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MascotaRepository
    val todasMascotas: LiveData<List<MascotaEntity>>

    // LiveData para resultados de operaciones
    private val _resultadoOperacion = MutableLiveData<ResultadoOperacion>()
    val resultadoOperacion: LiveData<ResultadoOperacion> = _resultadoOperacion

    private val _mascotaActual = MutableLiveData<MascotaEntity?>()
    val mascotaActual: LiveData<MascotaEntity?> = _mascotaActual

    private val _mascotasParticipante = MutableLiveData<List<MascotaEntity>>()
    val mascotasParticipante: LiveData<List<MascotaEntity>> = _mascotasParticipante

    init {
        val mascotaDao = DoggieRaceDatabase.getDatabase(application).mascotaDao()
        repository = MascotaRepository(mascotaDao)
        todasMascotas = repository.todasMascotas
    }

    // ========== OPERACIONES CRUD ==========

    fun insertarMascota(mascota: MascotaEntity) = viewModelScope.launch {
        try {
            val id = repository.insertarMascota(mascota)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Mascota registrada con ID: $id")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al registrar mascota: ${e.message}")
            )
        }
    }

    fun actualizarDatosMascota(
        id: Long,
        nombre: String,
        raza: String,
        edad: Int,
        categoria: String,
        sexo: String,
        peso: Double?,
        color: String?
    ) = viewModelScope.launch {
        try {
            val filasActualizadas = repository.actualizarDatosMascota(
                id, nombre, raza, edad, categoria, sexo, peso, color
            )
            if (filasActualizadas > 0) {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Exito("Mascota actualizada correctamente")
                )
            } else {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("No se pudo actualizar la mascota")
                )
            }
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error: ${e.message}")
            )
        }
    }

    fun actualizarFotoMascota(id: Long, uri: String?) = viewModelScope.launch {
        try {
            repository.actualizarFotoMascota(id, uri)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Foto actualizada")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al actualizar foto: ${e.message}")
            )
        }
    }

    fun activarDesactivarMascota(id: Long, activa: Boolean) = viewModelScope.launch {
        try {
            repository.actualizarEstadoActiva(id, activa)
            val mensaje = if (activa) "Mascota activada" else "Mascota desactivada"
            _resultadoOperacion.postValue(ResultadoOperacion.Exito(mensaje))
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error: ${e.message}")
            )
        }
    }

    fun eliminarMascota(id: Long) = viewModelScope.launch {
        try {
            repository.eliminarMascota(id)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Mascota eliminada")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al eliminar: ${e.message}")
            )
        }
    }

    fun incrementarTotalCarreras(id: Long) = viewModelScope.launch {
        try {
            repository.incrementarTotalCarreras(id)
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al actualizar estadísticas: ${e.message}")
            )
        }
    }

    fun incrementarTotalVictorias(id: Long) = viewModelScope.launch {
        try {
            repository.incrementarTotalVictorias(id)
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al actualizar estadísticas: ${e.message}")
            )
        }
    }

    // ========== CONSULTAS ==========

    fun cargarMascotaPorId(id: Long) = viewModelScope.launch {
        try {
            val mascota = repository.obtenerMascotaPorId(id)
            _mascotaActual.postValue(mascota)
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al cargar mascota: ${e.message}")
            )
        }
    }

    fun cargarMascotasDeParticipante(participanteId: Long) = viewModelScope.launch {
        try {
            val mascotas = repository.obtenerMascotasDeParticipante(participanteId)
            _mascotasParticipante.postValue(mascotas)
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al cargar mascotas: ${e.message}")
            )
        }
    }

    fun obtenerMascotasDeParticipanteLiveData(participanteId: Long): LiveData<List<MascotaEntity>> {
        return repository.obtenerMascotasDeParticipanteLiveData(participanteId)
    }

    fun obtenerMascotasActivasDeParticipante(participanteId: Long): LiveData<List<MascotaEntity>> {
        return repository.obtenerMascotasActivasDeParticipante(participanteId)
    }

    fun obtenerMascotasPorCategoria(categoria: String): LiveData<List<MascotaEntity>> {
        return repository.obtenerMascotasPorCategoria(categoria)
    }

    fun obtenerTopMascotas(limite: Int = 10): LiveData<List<MascotaEntity>> {
        return repository.obtenerTopMascotas(limite)
    }

    fun buscarMascotas(busqueda: String): LiveData<List<MascotaEntity>> {
        return repository.buscarMascotas(busqueda)
    }

    suspend fun contarMascotasDeParticipante(participanteId: Long): Int {
        return withContext(Dispatchers.IO) {
            repository.contarMascotasDeParticipante(participanteId)
        }
    }

    // ========== CLASE RESULTADO ==========

    sealed class ResultadoOperacion {
        data class Exito(val mensaje: String) : ResultadoOperacion()
        data class Error(val mensaje: String) : ResultadoOperacion()
    }
}
