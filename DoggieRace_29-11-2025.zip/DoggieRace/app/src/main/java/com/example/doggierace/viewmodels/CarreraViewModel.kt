package com.example.doggierace.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.doggierace.data.database.DoggieRaceDatabase
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.data.repository.CarreraRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CarreraViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CarreraRepository
    val proximasCarrerasParticipante: LiveData<List<CarreraEntity>>
    val proximasCarrerasOrganizador: LiveData<List<CarreraEntity>>
    val carrerasFinalizadas: LiveData<List<CarreraEntity>>
    val carrerasConCupos: LiveData<List<CarreraEntity>>

    private val _resultadoOperacion = MutableLiveData<ResultadoOperacion>()
    val resultadoOperacion: LiveData<ResultadoOperacion> = _resultadoOperacion

    private val _carreraActual = MutableLiveData<CarreraEntity?>()
    val carreraActual: LiveData<CarreraEntity?> = _carreraActual

    private val _carrerasOrganizador = MutableLiveData<List<CarreraEntity>>()
    val carrerasOrganizador: LiveData<List<CarreraEntity>> = _carrerasOrganizador

    init {
        val carreraDao = DoggieRaceDatabase.getDatabase(application).carreraDao()
        repository = CarreraRepository(carreraDao)
        val fechaActual = System.currentTimeMillis()
        proximasCarrerasParticipante = repository.obtenerProximasCarrerasParticipante()
        proximasCarrerasOrganizador = repository.obtenerProximasCarrerasOrganizador(fechaActual)
        carrerasFinalizadas = repository.obtenerCarrerasFinalizadas()
        carrerasConCupos = repository.obtenerProximasCarrerasOrganizador(fechaActual) // Temporalmente usa próximas
    }



    // ========== OPERACIONES CRUD ==========

    fun insertarCarrera(carrera: CarreraEntity) = viewModelScope.launch {
        try {
            val id = repository.insertarCarrera(carrera)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Carrera creada con ID: $id")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al crear carrera: ${e.message}")
            )
        }
    }

    fun actualizarCarrera(carrera: CarreraEntity) = viewModelScope.launch {
        try {
            val filasActualizadas = repository.actualizarCarrera(carrera)
            if (filasActualizadas > 0) {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Exito("Carrera actualizada correctamente")
                )
            } else {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("No se pudo actualizar la carrera")
                )
            }
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error: ${e.message}")
            )
        }
    }

    fun actualizarDatosCarrera(
        id: Long,
        nombre: String,
        descripcion: String,
        fecha: Long,
        horaInicio: String,
        ubicacion: String,
        direccion: String,
        ciudad: String,
        categoria: String,
        precioInscripcion: Double,
        cuposTotales: Int
    ) = viewModelScope.launch {
        try {
            val filasActualizadas = repository.actualizarDatosCarrera(
                id, nombre, descripcion, fecha, horaInicio,
                ubicacion, direccion, ciudad, categoria,
                precioInscripcion, cuposTotales
            )
            if (filasActualizadas > 0) {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Exito("Carrera actualizada")
                )
            } else {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("No se pudo actualizar")
                )
            }
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error: ${e.message}")
            )
        }
    }

    fun actualizarEstadoCarrera(id: Long, estado: String) = viewModelScope.launch {
        try {
            repository.actualizarEstado(id, estado)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Estado actualizado a: $estado")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al actualizar estado: ${e.message}")
            )
        }
    }

    fun inscribirParticipante(carreraId: Long) = viewModelScope.launch {
        try {
            val exito = repository.inscribirParticipante(carreraId)
            if (exito) {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Exito("Inscripción exitosa")
                )
            } else {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("No hay cupos disponibles")
                )
            }
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error en inscripción: ${e.message}")
            )
        }
    }

    fun cancelarInscripcion(carreraId: Long) = viewModelScope.launch {
        try {
            repository.cancelarInscripcion(carreraId)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Inscripción cancelada")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al cancelar: ${e.message}")
            )
        }
    }

    fun actualizarImagenCarrera(id: Long, uri: String?) = viewModelScope.launch {
        try {
            repository.actualizarImagenCarrera(id, uri)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Imagen actualizada")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al actualizar imagen: ${e.message}")
            )
        }
    }

    fun eliminarCarrera(id: Long) = viewModelScope.launch {
        try {
            repository.eliminarCarrera(id)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Carrera eliminada")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al eliminar: ${e.message}")
            )
        }
    }

    // ========== CONSULTAS ==========

    // ========== CONSULTAS ==========

    fun cargarCarreraPorId(id: Long) = viewModelScope.launch {
        try {
            val carrera = repository.obtenerCarreraPorId(id)
            _carreraActual.postValue(carrera)
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al cargar carrera: ${e.message}")
            )
        }
    }

    // ✅ NUEVA FUNCIÓN SUSPENDIDA
    suspend fun obtenerCarreraPorId(id: Long): CarreraEntity? {
        return withContext(Dispatchers.IO) {
            repository.obtenerCarreraPorId(id)
        }
    }

    fun cargarCarrerasDeOrganizador(organizadorId: Long) = viewModelScope.launch {
        try {
            // Este método retorna LiveData, así que no necesita postValue
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al cargar carreras: ${e.message}")
            )
        }
    }

// ... resto del código


    fun obtenerCarrerasDeOrganizadorLiveData(organizadorId: Long): LiveData<List<CarreraEntity>> {
        return repository.obtenerCarrerasDeOrganizador(organizadorId)
    }

    fun obtenerCarreraPorIdLiveData(id: Long): LiveData<CarreraEntity?> {
        return repository.obtenerCarreraPorIdLiveData(id)
    }

    fun obtenerCarrerasPorEstado(estado: String): LiveData<List<CarreraEntity>> {
        return repository.obtenerCarrerasPorEstado(estado)
    }

    fun obtenerCarrerasPorCategoria(categoria: String): LiveData<List<CarreraEntity>> {
        return repository.obtenerCarrerasPorCategoria(categoria)
    }

    fun obtenerCarrerasPorCiudad(ciudad: String): LiveData<List<CarreraEntity>> {
        return repository.obtenerCarrerasPorCiudad(ciudad)
    }

    fun buscarCarreras(busqueda: String): LiveData<List<CarreraEntity>> {
        return repository.buscarCarreras(busqueda)
    }

    fun obtenerCarrerasPorRangoFecha(fechaInicio: Long, fechaFin: Long): LiveData<List<CarreraEntity>> {
        return repository.obtenerCarrerasPorRangoFecha(fechaInicio, fechaFin)
    }

    suspend fun contarCarrerasDeOrganizador(organizadorId: Long): Int {
        return withContext(Dispatchers.IO) {
            repository.contarCarrerasDeOrganizador(organizadorId)
        }
    }

    suspend fun contarCarrerasPorEstado(organizadorId: Long, estado: String): Int {
        return withContext(Dispatchers.IO) {
            repository.contarCarrerasPorEstado(organizadorId, estado)
        }
    }

    // ========== CLASE RESULTADO ==========

    sealed class ResultadoOperacion {
        data class Exito(val mensaje: String) : ResultadoOperacion()
        data class Error(val mensaje: String) : ResultadoOperacion()
    }

    // ========== MÉTODOS PARA PARTICIPANTES ==========

    /**
     * Obtiene carreras disponibles (sin inscripción del participante)
     * Para "Carreras Disponibles" en InicioParticipanteFragment
     */
    fun obtenerCarrerasSinInscripcion(participanteId: Long): LiveData<List<CarreraEntity>> {
        val fechaActual = System.currentTimeMillis()
        return repository.obtenerCarrerasSinInscripcion(participanteId, fechaActual)
    }

    /**
     * Obtiene la próxima carrera donde el participante está inscrito
     * Para "Tu Próxima Carrera" en InicioParticipanteFragment
     */
    fun obtenerProximaCarreraConInscripcion(participanteId: Long): LiveData<CarreraEntity?> {
        val fechaActual = System.currentTimeMillis()
        return repository.obtenerProximaCarreraConInscripcion(participanteId, fechaActual)
    }

    /**
     * Obtiene todas las carreras próximas donde el participante está inscrito
     * Para "Ver todas mis próximas carreras" en HistorialCarrerasFragment
     */
    fun obtenerCarrerasInscritasProximas(participanteId: Long): LiveData<List<CarreraEntity>> {
        val fechaActual = System.currentTimeMillis()
        return repository.obtenerCarrerasInscritasProximas(participanteId, fechaActual)
    }

    /**
     * Obtiene carreras finalizadas donde el participante estuvo inscrito
     * Para historial de carreras completadas
     */
    fun obtenerCarrerasInscritasFinalizadas(participanteId: Long): LiveData<List<CarreraEntity>> {
        return repository.obtenerCarrerasInscritasFinalizadas(participanteId)
    }

    /**
     * Obtiene TODAS las carreras inscritas (próximas + finalizadas)
     * Para vista completa de "Mis Carreras"
     */
    fun obtenerProximasCarrerasParticipanteInscritas(participanteId: Long): LiveData<List<CarreraEntity>> {
        return repository.obtenerProximasCarrerasParticipanteInscritas(participanteId)
    }

    // Agregar en CarreraViewModel.kt
    fun decrementarCuposCarrera(carreraId: Long, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val actualizado = repository.decrementarCupoDisponible(carreraId)
                if (actualizado > 0) {
                    onSuccess()
                } else {
                    onError("No hay cupos disponibles")
                }
            } catch (e: Exception) {
                onError("Error al actualizar cupos: ${e.message}")
            }
        }
    }



}
