package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.R
import com.example.doggierace.adapters.MetodosPagoAdapter
import com.example.doggierace.databinding.FragmentMetodosPagoBinding
import com.example.doggierace.data.entities.MetodoPagoEntity
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.MetodoPagoViewModel

class MetodosPagoFragment : Fragment() {

    private var _binding: FragmentMetodosPagoBinding? = null
    private val binding get() = _binding!!

    private val metodoPagoViewModel: MetodoPagoViewModel by viewModels()
    private lateinit var sessionManager: SessionManager
    private lateinit var metodosAdapter: MetodosPagoAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMetodosPagoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sessionManager = SessionManager(requireContext())

        configurarRecyclerView()
        configurarBotones()
        observarMetodosPago()  // ✅ Observar UNA SOLA VEZ
        observarResultados()
    }

    private fun configurarRecyclerView() {
        metodosAdapter = MetodosPagoAdapter(
            onItemClick = { metodoPago ->
                // Opcional: mostrar detalles
            },
            onEliminarClick = { metodoPago ->
                confirmarEliminar(metodoPago)
            },
            onPredeterminadaClick = { metodoPago ->
                establecerComoPredeterminada(metodoPago)
            }
        )

        binding.rvMetodosPago.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = metodosAdapter
            setHasFixedSize(true)
        }
    }

    private fun configurarBotones() {
        binding.btnAgregarMetodo.setOnClickListener {
            findNavController().navigate(R.id.action_metodosPago_to_agregarMetodoPago)
        }
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    // ✅ OBSERVAR UNA SOLA VEZ
    private fun observarMetodosPago() {
        val participanteId = sessionManager.obtenerUserId()
        if (participanteId == -1L) {
            Toast.makeText(requireContext(), "Error: No hay sesión activa", Toast.LENGTH_SHORT).show()
            return
        }

        metodoPagoViewModel.obtenerMetodosPagoDeParticipante(participanteId)
            .observe(viewLifecycleOwner) { metodos ->
                if (metodos.isEmpty()) {
                    mostrarEstadoVacio()
                } else {
                    mostrarMetodos(metodos)
                }
            }
    }

    private fun mostrarMetodos(metodos: List<MetodoPagoEntity>) {
        binding.rvMetodosPago.visibility = View.VISIBLE
        binding.layoutVacio.visibility = View.GONE
        metodosAdapter.submitList(metodos)
    }

    private fun mostrarEstadoVacio() {
        binding.rvMetodosPago.visibility = View.GONE
        binding.layoutVacio.visibility = View.VISIBLE
    }

    private fun confirmarEliminar(metodoPago: MetodoPagoEntity) {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Eliminar Método de Pago")
            .setMessage("¿Deseas eliminar la tarjeta ${metodoPago.tipo} •••• ${metodoPago.numeroTarjeta}?")
            .setPositiveButton("Eliminar") { _, _ ->
                eliminarMetodoPago(metodoPago)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun eliminarMetodoPago(metodoPago: MetodoPagoEntity) {
        val participanteId = sessionManager.obtenerUserId()
        metodoPagoViewModel.eliminarMetodoPago(metodoPago.id, participanteId, metodoPago.esPredeterminada)
    }

    private fun establecerComoPredeterminada(metodoPago: MetodoPagoEntity) {
        val participanteId = sessionManager.obtenerUserId()
        metodoPagoViewModel.establecerComoPredeterminada(metodoPago.id, participanteId)
    }

    private fun observarResultados() {
        metodoPagoViewModel.resultadoOperacion.observe(viewLifecycleOwner) { resultado ->
            when (resultado) {
                is MetodoPagoViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(requireContext(), resultado.mensaje, Toast.LENGTH_SHORT).show()
                }
                is MetodoPagoViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(requireContext(), resultado.mensaje, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
