package com.example.doggierace.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.doggierace.data.entities.ParticipanteEntity

@Dao
interface ParticipanteDao {

    // ========== INSERTAR ==========
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarParticipante(participante: ParticipanteEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarParticipantes(participantes: List<ParticipanteEntity>): List<Long>

    // ========== ACTUALIZAR ==========
    @Update
    suspend fun actualizarParticipante(participante: ParticipanteEntity): Int

    @Query("""
        UPDATE participantes 
        SET nombre = :nombre, 
            telefono = :telefono, 
            direccion = :direccion,
            ciudad = :ciudad
        WHERE id = :id
    """)
    suspend fun actualizarPerfil(
        id: Long,
        nombre: String,
        telefono: String?,
        direccion: String?,
        ciudad: String?
    ): Int

    @Query("UPDATE participantes SET foto_perfil_uri = :uri WHERE id = :id")
    suspend fun actualizarFotoPerfil(id: Long, uri: String?): Int

    @Query("UPDATE participantes SET password = :nuevaPassword WHERE id = :id")
    suspend fun actualizarPassword(id: Long, nuevaPassword: String): Int

    @Query("UPDATE participantes SET total_mascotas = :total WHERE id = :id")
    suspend fun actualizarTotalMascotas(id: Long, total: Int): Int

    @Query("""
        UPDATE participantes 
        SET total_carreras_participadas = total_carreras_participadas + 1 
        WHERE id = :id
    """)
    suspend fun incrementarCarrerasParticipadas(id: Long): Int

    // ========== ELIMINAR ==========
    @Delete
    suspend fun eliminarParticipante(participante: ParticipanteEntity): Int

    @Query("DELETE FROM participantes WHERE id = :id")
    suspend fun eliminarParticipantePorId(id: Long): Int

    @Query("DELETE FROM participantes")
    suspend fun eliminarTodosParticipantes(): Int

    // ========== CONSULTAS ==========
    @Query("SELECT * FROM participantes WHERE id = :id")
    suspend fun obtenerParticipantePorId(id: Long): ParticipanteEntity?

    @Query("SELECT * FROM participantes WHERE id = :id")
    fun obtenerParticipantePorIdLiveData(id: Long): LiveData<ParticipanteEntity?>

    @Query("SELECT * FROM participantes WHERE email = :email LIMIT 1")
    suspend fun obtenerParticipantePorEmail(email: String): ParticipanteEntity?

    @Query("""
        SELECT * FROM participantes 
        WHERE email = :email AND password = :password 
        LIMIT 1
    """)
    suspend fun login(email: String, password: String): ParticipanteEntity?

    @Query("SELECT * FROM participantes WHERE activo = 1")
    fun obtenerParticipantesActivos(): LiveData<List<ParticipanteEntity>>

    @Query("SELECT * FROM participantes ORDER BY fecha_registro DESC")
    fun obtenerTodosParticipantes(): LiveData<List<ParticipanteEntity>>

    @Query("SELECT * FROM participantes ORDER BY fecha_registro DESC")
    suspend fun obtenerTodosParticipantesSuspend(): List<ParticipanteEntity>

    @Query("SELECT * FROM participantes WHERE ciudad = :ciudad ORDER BY nombre ASC")
    fun obtenerParticipantesPorCiudad(ciudad: String): LiveData<List<ParticipanteEntity>>

    @Query("""
        SELECT * FROM participantes 
        WHERE total_carreras_participadas > 0 
        ORDER BY total_carreras_participadas DESC
        LIMIT :limite
    """)
    fun obtenerTopParticipantes(limite: Int = 10): LiveData<List<ParticipanteEntity>>

    @Query("SELECT COUNT(*) FROM participantes WHERE email = :email")
    suspend fun verificarEmailExistente(email: String): Int

    @Query("SELECT COUNT(*) FROM participantes")
    suspend fun contarParticipantes(): Int

    @Query("SELECT COUNT(*) FROM participantes WHERE activo = 1")
    suspend fun contarParticipantesActivos(): Int
}
