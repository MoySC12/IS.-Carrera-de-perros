package com.example.doggierace.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.doggierace.data.database.DoggieRaceDatabase
import com.example.doggierace.data.entities.ParticipanteEntity
import com.example.doggierace.data.repository.ParticipanteRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ParticipanteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ParticipanteRepository
    val todosParticipantes: LiveData<List<ParticipanteEntity>>
    val participantesActivos: LiveData<List<ParticipanteEntity>>

    // LiveData para resultados de operaciones
    private val _resultadoOperacion = MutableLiveData<ResultadoOperacion>()
    val resultadoOperacion: LiveData<ResultadoOperacion> = _resultadoOperacion

    private val _participanteActual = MutableLiveData<ParticipanteEntity?>()
    val participanteActual: LiveData<ParticipanteEntity?> = _participanteActual

    init {
        val participanteDao = DoggieRaceDatabase.getDatabase(application).participanteDao()
        repository = ParticipanteRepository(participanteDao)
        todosParticipantes = repository.todosParticipantes
        participantesActivos = repository.participantesActivos
    }

    // ========== OPERACIONES CRUD ==========

    fun insertarParticipante(participante: ParticipanteEntity) = viewModelScope.launch {
        try {
            val id = repository.insertarParticipante(participante)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Participante registrado con ID: $id")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al registrar: ${e.message}")
            )
        }
    }

    fun actualizarPerfil(
        id: Long,
        nombre: String,
        telefono: String?,
        direccion: String?,
        ciudad: String?
    ) = viewModelScope.launch {
        try {
            val filasActualizadas = repository.actualizarPerfil(
                id, nombre, telefono, direccion, ciudad
            )
            if (filasActualizadas > 0) {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Exito("Perfil actualizado correctamente")
                )
            } else {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("No se pudo actualizar el perfil")
                )
            }
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error: ${e.message}")
            )
        }
    }

    fun actualizarFotoPerfil(id: Long, uri: String?) = viewModelScope.launch {
        try {
            repository.actualizarFotoPerfil(id, uri)
            _resultadoOperacion.postValue(
                ResultadoOperacion.Exito("Foto actualizada")
            )
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al actualizar foto: ${e.message}")
            )
        }
    }

    fun actualizarPassword(id: Long, passwordAntigua: String, passwordNueva: String) =
        viewModelScope.launch {
            try {
                val participante = repository.obtenerParticipantePorId(id)
                if (participante?.password == passwordAntigua) {
                    repository.actualizarPassword(id, passwordNueva)
                    _resultadoOperacion.postValue(
                        ResultadoOperacion.Exito("Contraseña actualizada")
                    )
                } else {
                    _resultadoOperacion.postValue(
                        ResultadoOperacion.Error("Contraseña antigua incorrecta")
                    )
                }
            } catch (e: Exception) {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("Error: ${e.message}")
                )
            }
        }

    fun incrementarCarrerasParticipadas(id: Long) = viewModelScope.launch {
        try {
            repository.incrementarCarrerasParticipadas(id)
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al actualizar estadísticas: ${e.message}")
            )
        }
    }

    // ========== LOGIN Y REGISTRO ==========

    fun login(email: String, password: String) = viewModelScope.launch {
        try {
            val participante = repository.login(email, password)
            if (participante != null && participante.activo) {
                _participanteActual.postValue(participante)
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Exito("Login exitoso")
                )
            } else {
                _resultadoOperacion.postValue(
                    ResultadoOperacion.Error("Email o contraseña incorrectos")
                )
            }
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error en login: ${e.message}")
            )
        }
    }

    suspend fun verificarEmailExistente(email: String): Boolean {
        return withContext(Dispatchers.IO) {
            repository.verificarEmailExistente(email)
        }
    }

    fun cargarParticipantePorId(id: Long) = viewModelScope.launch {
        try {
            val participante = repository.obtenerParticipantePorId(id)
            _participanteActual.postValue(participante)
        } catch (e: Exception) {
            _resultadoOperacion.postValue(
                ResultadoOperacion.Error("Error al cargar participante: ${e.message}")
            )
        }
    }

    fun cerrarSesion() {
        _participanteActual.postValue(null)
    }

    // ========== CLASE RESULTADO ==========

    sealed class ResultadoOperacion {
        data class Exito(val mensaje: String) : ResultadoOperacion()
        data class Error(val mensaje: String) : ResultadoOperacion()
    }
    // Agregar al final de la clase ParticipanteViewModel
    suspend fun obtenerParticipantePorEmail(email: String): ParticipanteEntity? {
        return withContext(Dispatchers.IO) {
            repository.obtenerParticipantePorEmail(email)
        }
    }

}
