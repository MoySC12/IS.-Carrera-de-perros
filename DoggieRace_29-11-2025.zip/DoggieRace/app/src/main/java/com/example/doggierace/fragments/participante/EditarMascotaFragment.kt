package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.databinding.FragmentEditarMascotaBinding
import com.example.doggierace.data.entities.MascotaEntity
import com.example.doggierace.viewmodels.MascotaViewModel

class EditarMascotaFragment : Fragment() {

    private var _binding: FragmentEditarMascotaBinding? = null
    private val binding get() = _binding!!

    private val mascotaViewModel: MascotaViewModel by viewModels()
    private val args: EditarMascotaFragmentArgs by navArgs()

    private var mascotaActual: MascotaEntity? = null
    private var fotoPerroUri: String? = null
    private var cartillaUri: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditarMascotaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupClickListeners()
        cargarDatosMascota()
        observarResultados()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun setupClickListeners() {
        // Botón: Cambiar Foto del Perro
        binding.btnCambiarFotoPerro.setOnClickListener {
            // TODO: Implementar selección de foto desde galería o cámara
            Toast.makeText(
                requireContext(),
                "Función 'Cambiar Foto' en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Botón: Ver/Cambiar Cartilla
        binding.btnVerCartilla.setOnClickListener {
            // TODO: Implementar selección/visualización de cartilla
            Toast.makeText(
                requireContext(),
                "Función 'Ver Cartilla' en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Botón: Guardar Cambios
        binding.btnGuardarCambios.setOnClickListener {
            guardarCambios()
        }

        // Botón: Eliminar Mascota
        binding.btnEliminarMascota.setOnClickListener {
            mostrarDialogoEliminar()
        }
    }

    private fun cargarDatosMascota() {
        val mascotaId = args.mascotaId

        mascotaViewModel.cargarMascotaPorId(mascotaId)

        mascotaViewModel.mascotaActual.observe(viewLifecycleOwner) { mascota ->
            if (mascota != null) {
                mascotaActual = mascota
                rellenarCampos(mascota)
            } else {
                Toast.makeText(
                    requireContext(),
                    "Error al cargar la mascota",
                    Toast.LENGTH_LONG
                ).show()
                findNavController().popBackStack()
            }
        }
    }

    private fun rellenarCampos(mascota: MascotaEntity) {
        binding.etNombreMascota.setText(mascota.nombre)
        binding.etRaza.setText(mascota.raza)
        binding.etEdad.setText(mascota.edad.toString())
        binding.etPeso.setText(mascota.peso.toString())
        binding.etAltura.setText(mascota.altura.toString())
        binding.etDiscapacidad.setText(mascota.discapacidad ?: "")

        // Guardar URIs de foto y cartilla
        fotoPerroUri = mascota.fotoPerroUri
        cartillaUri = mascota.cartillaVacunacionUri

        // TODO: Cargar imagen en imgFotoPerro si existe fotoPerroUri
        // Glide.with(this).load(mascota.fotoPerroUri).into(binding.imgFotoPerro)
    }

    private fun guardarCambios() {
        // Limpiar errores previos
        limpiarErrores()

        // Obtener valores de los campos
        val nombre = binding.etNombreMascota.text.toString().trim()
        val raza = binding.etRaza.text.toString().trim()
        val edadStr = binding.etEdad.text.toString().trim()
        val pesoStr = binding.etPeso.text.toString().trim()
        val alturaStr = binding.etAltura.text.toString().trim()
        val discapacidad = binding.etDiscapacidad.text.toString().trim()

        // Validaciones
        if (!validarCampos(nombre, raza, edadStr, pesoStr, alturaStr)) {
            return
        }

        // Convertir valores numéricos
        val edad = edadStr.toIntOrNull() ?: 0
        val peso = pesoStr.toDoubleOrNull() ?: 0.0
        val altura = alturaStr.toDoubleOrNull() ?: 0.0

        // Determinar categoría automáticamente según peso
        val categoria = determinarCategoria(peso)

        // Crear entidad actualizada
        val mascotaActualizada = mascotaActual?.copy(
            nombre = nombre,
            raza = raza,
            edad = edad,
            peso = peso,
            altura = altura,
            categoria = categoria,
            discapacidad = if (discapacidad.isEmpty()) null else discapacidad,
            fotoPerroUri = fotoPerroUri,
            cartillaVacunacionUri = cartillaUri
        )

        // Actualizar en la base de datos
        if (mascotaActualizada != null) {
            mascotaViewModel.actualizarDatosMascota(
                id = mascotaActualizada.id,
                nombre = nombre,
                raza = raza,
                edad = edad,
                categoria = categoria,
                sexo = mascotaActualizada.sexo,
                peso = peso,
                color = mascotaActualizada.color
            )
        }
    }

    private fun validarCampos(
        nombre: String,
        raza: String,
        edad: String,
        peso: String,
        altura: String
    ): Boolean {

        // Validar nombre
        if (nombre.isEmpty()) {
            binding.inputLayoutNombreMascota.error = "El nombre es obligatorio"
            binding.etNombreMascota.requestFocus()
            return false
        }

        // Validar raza
        if (raza.isEmpty()) {
            binding.inputLayoutRaza.error = "La raza es obligatoria"
            binding.etRaza.requestFocus()
            return false
        }

        // Validar edad
        if (edad.isEmpty()) {
            binding.inputLayoutEdad.error = "La edad es obligatoria"
            binding.etEdad.requestFocus()
            return false
        }

        val edadNum = edad.toIntOrNull()
        if (edadNum == null || edadNum <= 0 || edadNum > 20) {
            binding.inputLayoutEdad.error = "Edad inválida (1-20 años)"
            binding.etEdad.requestFocus()
            return false
        }

        // Validar peso
        if (peso.isEmpty()) {
            binding.inputLayoutPeso.error = "El peso es obligatorio"
            binding.etPeso.requestFocus()
            return false
        }

        val pesoNum = peso.toDoubleOrNull()
        if (pesoNum == null || pesoNum <= 0 || pesoNum > 100) {
            binding.inputLayoutPeso.error = "Peso inválido (0-100 kg)"
            binding.etPeso.requestFocus()
            return false
        }

        // Validar altura
        if (altura.isEmpty()) {
            binding.inputLayoutAltura.error = "La altura es obligatoria"
            binding.etAltura.requestFocus()
            return false
        }

        val alturaNum = altura.toDoubleOrNull()
        if (alturaNum == null || alturaNum <= 0 || alturaNum > 200) {
            binding.inputLayoutAltura.error = "Altura inválida (0-200 cm)"
            binding.etAltura.requestFocus()
            return false
        }

        return true
    }

    private fun limpiarErrores() {
        binding.inputLayoutNombreMascota.error = null
        binding.inputLayoutRaza.error = null
        binding.inputLayoutEdad.error = null
        binding.inputLayoutPeso.error = null
        binding.inputLayoutAltura.error = null
    }

    private fun determinarCategoria(peso: Double): String {
        return when {
            peso < 10.0 -> "Pequeña"
            peso < 25.0 -> "Mediana"
            peso < 45.0 -> "Grande"
            else -> "XL"
        }
    }

    private fun mostrarDialogoEliminar() {
        val nombreMascota = mascotaActual?.nombre ?: "esta mascota"

        AlertDialog.Builder(requireContext())
            .setTitle("⚠️ Eliminar Mascota")
            .setMessage("¿Estás seguro de que deseas eliminar a $nombreMascota?\n\nEsta acción NO se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                eliminarMascota()
            }
            .setNegativeButton("Cancelar", null)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show()
    }

    private fun eliminarMascota() {
        val mascotaId = mascotaActual?.id ?: return
        mascotaViewModel.eliminarMascota(mascotaId)
    }

    private fun observarResultados() {
        mascotaViewModel.resultadoOperacion.observe(viewLifecycleOwner) { resultado ->
            when (resultado) {
                is MascotaViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(
                        requireContext(),
                        resultado.mensaje,
                        Toast.LENGTH_SHORT
                    ).show()
                    // Volver a la pantalla anterior
                    findNavController().popBackStack()
                }
                is MascotaViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(
                        requireContext(),
                        resultado.mensaje,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
