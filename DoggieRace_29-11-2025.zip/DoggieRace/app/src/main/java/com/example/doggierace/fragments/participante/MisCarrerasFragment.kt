// MisCarrerasFragment.kt
// TODO: Implementar cuando tengamos CarreraEntity e InscripcionEntity
// Este fragment mostrará las carreras en las que el participante inscribió sus mascotas


package com.example.doggierace.fragments.participante
//Esta ya no se usa, pero la dejo por si en el futuro se necesita.
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.doggierace.databinding.FragmentHistorialParticipanteBinding

class MisCarrerasFragment : Fragment() {

    private var _binding: FragmentHistorialParticipanteBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistorialParticipanteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
