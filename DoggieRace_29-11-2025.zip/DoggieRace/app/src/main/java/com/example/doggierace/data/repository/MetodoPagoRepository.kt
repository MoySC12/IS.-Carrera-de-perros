package com.example.doggierace.data.repositories

import androidx.lifecycle.LiveData
import com.example.doggierace.data.dao.MetodoPagoDao
import com.example.doggierace.data.entities.MetodoPagoEntity

class MetodoPagoRepository(private val metodoPagoDao: MetodoPagoDao) {

    fun obtenerMetodosPagoDeParticipante(participanteId: Long): LiveData<List<MetodoPagoEntity>> {
        return metodoPagoDao.obtenerMetodosPagoDeParticipante(participanteId)
    }

    suspend fun obtenerMetodosPagoDeParticipanteSuspend(participanteId: Long): List<MetodoPagoEntity> {
        return metodoPagoDao.obtenerMetodosPagoDeParticipanteSuspend(participanteId)
    }

    suspend fun insertarMetodoPago(metodoPago: MetodoPagoEntity): Long {
        return metodoPagoDao.insertarMetodoPago(metodoPago)
    }

    suspend fun actualizarMetodoPago(metodoPago: MetodoPagoEntity): Int {
        return metodoPagoDao.actualizarMetodoPago(metodoPago)
    }

    suspend fun eliminarMetodoPago(metodoPago: MetodoPagoEntity): Int {
        return metodoPagoDao.eliminarMetodoPago(metodoPago)
    }

    suspend fun eliminarMetodoPagoPorId(id: Long): Int {
        return metodoPagoDao.eliminarMetodoPagoPorId(id)
    }

    suspend fun obtenerMetodoPagoPorId(id: Long): MetodoPagoEntity? {
        return metodoPagoDao.obtenerMetodoPagoPorId(id)
    }

    suspend fun obtenerMetodoPagoPredeterminado(participanteId: Long): MetodoPagoEntity? {
        return metodoPagoDao.obtenerMetodoPagoPredeterminado(participanteId)
    }

    suspend fun establecerComoPredeterminada(id: Long, participanteId: Long) {
        // Primero quitar predeterminado a todos
        metodoPagoDao.quitarPredeterminadoATodos(participanteId)
        // Luego establecer el nuevo
        metodoPagoDao.establecerComoPredeterminada(id)
    }

    suspend fun contarMetodosPago(participanteId: Long): Int {
        return metodoPagoDao.contarMetodosPago(participanteId)
    }
}
