package com.example.doggierace

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.doggierace.databinding.ActivityInicioSesionBinding
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.AdministradorViewModel
import com.example.doggierace.viewmodels.ParticipanteViewModel
import kotlinx.coroutines.launch

class InicioSesionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityInicioSesionBinding
    private lateinit var sessionManager: SessionManager

    private val administradorViewModel: AdministradorViewModel by viewModels()
    private val participanteViewModel: ParticipanteViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializar SessionManager
        sessionManager = SessionManager(this)

        // Verificar si ya hay sesión activa
        if (sessionManager.estaLogueado()) {
            navegarAPantallaPrincipal()
            return
        }

        binding = ActivityInicioSesionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
        observarResultados()
    }

    private fun setupClickListeners() {
        // Botón Iniciar Sesión
        binding.btnIniciarSesion.setOnClickListener {
            intentarLogin()
        }

        // Texto de Registro
        binding.tvRegistro.setOnClickListener {
            val intent = Intent(this, RegistroActivity::class.java)
            startActivity(intent)
        }
    }

    private fun intentarLogin() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        // Validar campos
        if (!validarCampos(email, password)) {
            return
        }

        // Intentar login en ambas tablas
        lifecycleScope.launch {
            // Primero intenta login como Participante
            val participante = participanteViewModel.obtenerParticipantePorEmail(email)

            if (participante != null) {
                // Encontrado como participante
                if (participante.password == password) {
                    if (participante.activo) {
                        loginExitosoParticipante(participante.id, participante.email, participante.nombre)
                    } else {
                        Toast.makeText(
                            this@InicioSesionActivity,
                            "Tu cuenta está inactiva. Contacta al administrador",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@InicioSesionActivity,
                        "Contraseña incorrecta",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                // Si no es participante, intenta como Organizador
                val organizador = administradorViewModel.obtenerAdministradorPorEmail(email)

                if (organizador != null) {
                    if (organizador.password == password) {
                        if (organizador.activo) {
                            loginExitosoOrganizador(organizador.id, organizador.email, organizador.nombre)
                        } else {
                            Toast.makeText(
                                this@InicioSesionActivity,
                                "Tu cuenta está inactiva. Contacta al administrador",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            this@InicioSesionActivity,
                            "Contraseña incorrecta",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@InicioSesionActivity,
                        "No se encontró una cuenta con ese email",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun loginExitosoParticipante(id: Long, email: String, nombre: String) {
        // Guardar sesión
        sessionManager.guardarSesionParticipante(id, email, nombre)

        Toast.makeText(
            this,
            "Bienvenido, $nombre",
            Toast.LENGTH_SHORT
        ).show()

        // Navegar a pantalla de participante
        val intent = Intent(this, MainActivityParticipante::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun loginExitosoOrganizador(id: Long, email: String, nombre: String) {
        // Guardar sesión
        sessionManager.guardarSesionOrganizador(id, email, nombre)

        Toast.makeText(
            this,
            "Bienvenido, $nombre",
            Toast.LENGTH_SHORT
        ).show()

        // Navegar a pantalla de organizador
        val intent = Intent(this, MainActivityOrganizador::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun navegarAPantallaPrincipal() {
        val intent = if (sessionManager.esParticipante()) {
            Intent(this, MainActivityParticipante::class.java)
        } else {
            Intent(this, MainActivityOrganizador::class.java)
        }

        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun validarCampos(email: String, password: String): Boolean {
        if (email.isEmpty()) {
            binding.etEmail.error = "Ingresa tu email"
            Toast.makeText(this, "Por favor ingresa tu correo electrónico", Toast.LENGTH_SHORT).show()
            return false
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Email inválido"
            Toast.makeText(this, "Por favor ingresa un email válido", Toast.LENGTH_SHORT).show()
            return false
        }

        if (password.isEmpty()) {
            binding.etPassword.error = "Ingresa tu contraseña"
            Toast.makeText(this, "Por favor ingresa tu contraseña", Toast.LENGTH_SHORT).show()
            return false
        }

        if (password.length < 6) {
            binding.etPassword.error = "Contraseña muy corta"
            Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

    private fun observarResultados() {
        // Observar resultados de participante
        participanteViewModel.resultadoOperacion.observe(this) { resultado ->
            when (resultado) {
                is ParticipanteViewModel.ResultadoOperacion.Exito -> {
                    // Login exitoso manejado en loginExitosoParticipante()
                }
                is ParticipanteViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(this, resultado.mensaje, Toast.LENGTH_LONG).show()
                }
            }
        }

        // Observar resultados de administrador
        administradorViewModel.resultadoOperacion.observe(this) { resultado ->
            when (resultado) {
                is AdministradorViewModel.ResultadoOperacion.Exito -> {
                    // Login exitoso manejado en loginExitosoOrganizador()
                }
                is AdministradorViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(this, resultado.mensaje, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
