package com.example.doggierace.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo
import androidx.room.Index

@Entity(
    tableName = "administradores",
    indices = [Index(value = ["email"], unique = true)]
)
data class AdministradorEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,

    @ColumnInfo(name = "email")
    val email: String,

    @ColumnInfo(name = "password")
    val password: String,

    @ColumnInfo(name = "nombre")
    val nombre: String,

    @ColumnInfo(name = "telefono")
    val telefono: String? = null,

    @ColumnInfo(name = "organizacion")
    val organizacion: String? = null,

    @ColumnInfo(name = "descripcion")
    val descripcion: String? = null,

    @ColumnInfo(name = "foto_perfil_uri")
    val fotoPerfilUri: String? = null,

    @ColumnInfo(name = "codigo_verificacion")
    val codigoVerificacion: String = "ORG2025",

    @ColumnInfo(name = "fecha_registro")
    val fechaRegistro: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "activo")
    val activo: Boolean = true,

    @ColumnInfo(name = "titular_cuenta")
    val titularCuenta: String? = null,

    @ColumnInfo(name = "banco")
    val banco: String? = null,

    @ColumnInfo(name = "clabe")
    val clabe: String? = null
)
