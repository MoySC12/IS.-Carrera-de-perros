package com.example.doggierace.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo
import androidx.room.Index

@Entity(
    tableName = "participantes",
    indices = [Index(value = ["email"], unique = true)]
)
data class ParticipanteEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,

    @ColumnInfo(name = "email")
    val email: String,

    @ColumnInfo(name = "password")
    val password: String,

    @ColumnInfo(name = "nombre")
    val nombre: String,

    @ColumnInfo(name = "telefono")
    val telefono: String? = null,

    @ColumnInfo(name = "direccion")
    val direccion: String? = null,

    @ColumnInfo(name = "ciudad")
    val ciudad: String? = null,

    @ColumnInfo(name = "foto_perfil_uri")
    val fotoPerfilUri: String? = null,

    @ColumnInfo(name = "fecha_registro")
    val fechaRegistro: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "activo")
    val activo: Boolean = true,

    @ColumnInfo(name = "total_carreras_participadas")
    val totalCarrerasParticipadas: Int = 0,

    @ColumnInfo(name = "total_mascotas")
    val totalMascotas: Int = 0
)
