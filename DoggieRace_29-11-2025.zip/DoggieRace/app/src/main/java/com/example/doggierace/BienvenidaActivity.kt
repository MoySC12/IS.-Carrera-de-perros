package com.example.doggierace

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.doggierace.databinding.ActivityBienvenidaBinding
import com.example.doggierace.utils.SessionManager

class BienvenidaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBienvenidaBinding
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sessionManager = SessionManager(this)

        // Verificar si ya hay sesión activa
        if (sessionManager.estaLogueado()) {
            navegarAPantallaPrincipal()
            return
        }

        binding = ActivityBienvenidaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.btnIniciarSesion.setOnClickListener {
            val intent = Intent(this, InicioSesionActivity::class.java)
            startActivity(intent)
        }

        binding.btnRegistrarse.setOnClickListener {
            val intent = Intent(this, RegistroActivity::class.java)
            startActivity(intent)
        }
    }

    private fun navegarAPantallaPrincipal() {
        val intent = if (sessionManager.esParticipante()) {
            Intent(this, MainActivityParticipante::class.java)
        } else {
            Intent(this, MainActivityOrganizador::class.java)
        }

        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
