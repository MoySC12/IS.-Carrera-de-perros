package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.R
import com.example.doggierace.adapters.ProximasCarrerasOrganizadorAdapter
import com.example.doggierace.databinding.FragmentProximasCarrerasParticipanteBinding
import com.example.doggierace.utils.SessionManager  // ✅ CAMBIO 1
import com.example.doggierace.viewmodels.CarreraViewModel
import com.example.doggierace.viewmodels.InscripcionViewModel
import com.google.android.material.chip.Chip
import kotlinx.coroutines.launch

class ProximasCarrerasParticipanteFragment : Fragment() {

    private var _binding: FragmentProximasCarrerasParticipanteBinding? = null
    private val binding get() = _binding!!

    private val carreraViewModel: CarreraViewModel by viewModels()
    private val inscripcionViewModel: InscripcionViewModel by viewModels()
    private lateinit var carrerasAdapter: ProximasCarrerasOrganizadorAdapter
    private lateinit var sessionManager: SessionManager  // ✅ CAMBIO 2

    private var categoriaSeleccionada: String? = null
    private var participanteId: Long = 0L

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProximasCarrerasParticipanteBinding.inflate(inflater, container, false)
        sessionManager = SessionManager(requireContext())  // ✅ CAMBIO 3
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ✅ CAMBIO 4: Obtener ID del participante con SessionManager
        participanteId = sessionManager.obtenerUserId()

        setupToolbar()
        configurarRecyclerView()
        configurarChips()
        observarCarreras()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }


    private fun configurarRecyclerView() {
        carrerasAdapter = ProximasCarrerasOrganizadorAdapter { carrera ->
            val action = ProximasCarrerasParticipanteFragmentDirections
                .accionProximasCarrerasParticipanteADetalle(carrera.id)
            findNavController().navigate(action)
        }

        binding.rvProximasCarrerasParticipante.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = carrerasAdapter
        }
    }

    private fun configurarChips() {
        binding.chipGroupCategoria.setOnCheckedStateChangeListener { group, checkedIds ->
            if (checkedIds.isEmpty()) {
                categoriaSeleccionada = null
            } else {
                val chipSeleccionado = group.findViewById<Chip>(checkedIds.first())
                categoriaSeleccionada = when (chipSeleccionado.id) {
                    R.id.chipTodas -> null
                    R.id.chipObstaculos -> "Obstáculos"  // ✅ CON acento
                    R.id.chipPaseos -> "Paseos"
                    R.id.chipTrineos -> "Trineos"
                    R.id.chipCanicross -> "Canicross"
                    else -> null
                }
            }
            cargarCarrerasInscritas()  // Recargar con el filtro
        }
    }



    private fun observarCarreras() {
        cargarCarrerasInscritas()
    }

    private fun cargarCarrerasInscritas() {
        carreraViewModel.proximasCarrerasParticipante.observe(viewLifecycleOwner) { proximasCarrerasParticipante ->
            viewLifecycleOwner.lifecycleScope.launch {
                try {
                    val idsCarrerasInscritas = inscripcionViewModel.obtenerIdsCarrerasInscritasSync(participanteId)

                    val carrerasInscritas = proximasCarrerasParticipante.filter {
                        idsCarrerasInscritas.contains(it.id)
                    }

                    val carrerasFiltradas = if (categoriaSeleccionada == null) {
                        carrerasInscritas
                    } else {
                        carrerasInscritas.filter { it.categoria == categoriaSeleccionada }
                    }

                    if (carrerasFiltradas.isEmpty()) {
                        binding.layoutVacio.visibility = View.VISIBLE
                        binding.rvProximasCarrerasParticipante.visibility = View.GONE
                    } else {
                        binding.layoutVacio.visibility = View.GONE
                        binding.rvProximasCarrerasParticipante.visibility = View.VISIBLE
                        carrerasAdapter.submitList(carrerasFiltradas)
                    }
                } catch (e: Exception) {
                    binding.layoutVacio.visibility = View.VISIBLE
                    binding.rvProximasCarrerasParticipante.visibility = View.GONE
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
