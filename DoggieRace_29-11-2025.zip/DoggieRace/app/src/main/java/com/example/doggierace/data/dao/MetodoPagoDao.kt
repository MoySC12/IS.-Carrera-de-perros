package com.example.doggierace.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.doggierace.data.entities.MetodoPagoEntity

@Dao
interface MetodoPagoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarMetodoPago(metodoPago: MetodoPagoEntity): Long

    @Update
    suspend fun actualizarMetodoPago(metodoPago: MetodoPagoEntity): Int

    @Delete
    suspend fun eliminarMetodoPago(metodoPago: MetodoPagoEntity): Int

    @Query("DELETE FROM metodos_pago WHERE id = :id")
    suspend fun eliminarMetodoPagoPorId(id: Long): Int

    @Query("SELECT * FROM metodos_pago WHERE participante_id = :participanteId AND activa = 1 ORDER BY es_predeterminada DESC, fecha_agregado DESC")
    fun obtenerMetodosPagoDeParticipante(participanteId: Long): LiveData<List<MetodoPagoEntity>>

    @Query("SELECT * FROM metodos_pago WHERE participante_id = :participanteId AND activa = 1 ORDER BY es_predeterminada DESC, fecha_agregado DESC")
    suspend fun obtenerMetodosPagoDeParticipanteSuspend(participanteId: Long): List<MetodoPagoEntity>

    @Query("SELECT * FROM metodos_pago WHERE id = :id AND activa = 1")
    suspend fun obtenerMetodoPagoPorId(id: Long): MetodoPagoEntity?

    @Query("SELECT * FROM metodos_pago WHERE participante_id = :participanteId AND es_predeterminada = 1 AND activa = 1 LIMIT 1")
    suspend fun obtenerMetodoPagoPredeterminado(participanteId: Long): MetodoPagoEntity?

    @Query("UPDATE metodos_pago SET es_predeterminada = 0 WHERE participante_id = :participanteId")
    suspend fun quitarPredeterminadoATodos(participanteId: Long): Int

    @Query("UPDATE metodos_pago SET es_predeterminada = 1 WHERE id = :id")
    suspend fun establecerComoPredeterminada(id: Long): Int

    @Query("SELECT COUNT(*) FROM metodos_pago WHERE participante_id = :participanteId AND activa = 1")
    suspend fun contarMetodosPago(participanteId: Long): Int
}
