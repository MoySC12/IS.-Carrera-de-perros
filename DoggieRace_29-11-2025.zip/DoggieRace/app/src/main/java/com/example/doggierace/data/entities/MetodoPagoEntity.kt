package com.example.doggierace.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "metodos_pago",
    foreignKeys = [
        ForeignKey(
            entity = ParticipanteEntity::class,
            parentColumns = ["id"],
            childColumns = ["participante_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class MetodoPagoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "participante_id", index = true)
    val participanteId: Long,

    @ColumnInfo(name = "tipo")
    val tipo: String, // "VISA", "MASTERCARD", "AMEX"

    @ColumnInfo(name = "numero_tarjeta")
    val numeroTarjeta: String, // Últimos 4 dígitos

    @ColumnInfo(name = "nombre_titular")
    val nombreTitular: String,

    @ColumnInfo(name = "fecha_vencimiento")
    val fechaVencimiento: String, // MM/AA

    @ColumnInfo(name = "es_predeterminada")
    val esPredeterminada: Boolean = false,

    @ColumnInfo(name = "activa")
    val activa: Boolean = true,

    @ColumnInfo(name = "fecha_agregado")
    val fechaAgregado: Long = System.currentTimeMillis()


)
