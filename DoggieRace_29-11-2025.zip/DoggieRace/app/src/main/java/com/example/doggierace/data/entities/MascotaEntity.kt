package com.example.doggierace.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "mascotas",
    foreignKeys = [
        ForeignKey(
            entity = ParticipanteEntity::class,
            parentColumns = ["id"],
            childColumns = ["participante_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["participante_id"])]
)
data class MascotaEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,

    @ColumnInfo(name = "participante_id")
    val participanteId: Long,

    @ColumnInfo(name = "nombre")
    val nombre: String,

    @ColumnInfo(name = "raza")
    val raza: String,

    @ColumnInfo(name = "edad")
    val edad: Int, // En años

    @ColumnInfo(name = "peso")
    val peso: Double, // En kg

    @ColumnInfo(name = "altura")
    val altura: Double, // En cm

    @ColumnInfo(name = "categoria")
    val categoria: String = "", // Se puede calcular automáticamente según peso/altura

    @ColumnInfo(name = "sexo")
    val sexo: String = "", // "Macho" o "Hembra"

    @ColumnInfo(name = "discapacidad")
    val discapacidad: String? = null, // Opcional

    @ColumnInfo(name = "foto_perro_uri")
    val fotoPerroUri: String? = null,

    @ColumnInfo(name = "cartilla_vacunacion_uri")
    val cartillaVacunacionUri: String? = null,

    @ColumnInfo(name = "color")
    val color: String? = null,

    @ColumnInfo(name = "numero_chip")
    val numeroChip: String? = null,

    @ColumnInfo(name = "fecha_nacimiento")
    val fechaNacimiento: Long? = null,

    @ColumnInfo(name = "activa")
    val activa: Boolean = true,

    @ColumnInfo(name = "total_carreras")
    val totalCarreras: Int = 0,

    @ColumnInfo(name = "total_victorias")
    val totalVictorias: Int = 0,

    @ColumnInfo(name = "fecha_registro")
    val fechaRegistro: Long = System.currentTimeMillis()
)
