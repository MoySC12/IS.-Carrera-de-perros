package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.adapters.ProximasCarrerasOrganizadorAdapter
import com.example.doggierace.databinding.FragmentProximasCarrerasOrganizadorBinding
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.CarreraViewModel

class ProximasCarrerasOrganizadorFragment : Fragment() {

    private var _binding: FragmentProximasCarrerasOrganizadorBinding? = null
    private val binding get() = _binding!!

    private val carreraViewModel: CarreraViewModel by viewModels()
    private lateinit var sessionManager: SessionManager
    private lateinit var adapter: ProximasCarrerasOrganizadorAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProximasCarrerasOrganizadorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())

        setupToolbar()
        setupRecyclerView()
        cargarCarreras()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }


    private fun setupRecyclerView() {
        adapter = ProximasCarrerasOrganizadorAdapter { carrera ->
            // Click en un ítem - Navegar a Editar Carrera
            navegarAEditarCarrera(carrera)
        }

        binding.rvProximasCarrerasOrganizador.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = this@ProximasCarrerasOrganizadorFragment.adapter
            setHasFixedSize(true)
        }
    }

    private fun cargarCarreras() {
        val organizadorId = sessionManager.obtenerUserId()

        if (organizadorId == -1L) {
            return
        }

        // Observar carreras del organizador con estado PROXIMA
        carreraViewModel.obtenerCarrerasDeOrganizadorLiveData(organizadorId)
            .observe(viewLifecycleOwner) { proximasCarrerasParticipante ->
                // Filtrar solo las próximas
                val carrerasProximas = proximasCarrerasParticipante.filter {
                    it.estado == CarreraEntity.ESTADO_PROXIMA && it.activa
                }.sortedBy { it.fecha } // Ordenar por fecha más próxima

                if (carrerasProximas.isEmpty()) {
                    mostrarEstadoVacio()
                } else {
                    mostrarLista(carrerasProximas)
                }
            }
    }

    private fun mostrarEstadoVacio() {
        binding.rvProximasCarrerasOrganizador.visibility = View.GONE
        // TODO: Agregar TextView o layout para estado vacío
    }

    private fun mostrarLista(carreras: List<CarreraEntity>) {
        binding.rvProximasCarrerasOrganizador.visibility = View.VISIBLE
        adapter.submitList(carreras)
    }

    private fun navegarAEditarCarrera(carrera: CarreraEntity) {
        val action = ProximasCarrerasOrganizadorFragmentDirections
            .actionProximasCarrerasOrganizadorToEditarCarrera(carrera.id)
        findNavController().navigate(action)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
