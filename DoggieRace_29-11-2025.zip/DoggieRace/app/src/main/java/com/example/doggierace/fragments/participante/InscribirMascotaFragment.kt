package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.R
import com.example.doggierace.adapters.MisMascotasAdapter
import com.example.doggierace.databinding.FragmentInscribirMascotaBinding
import com.example.doggierace.data.entities.MascotaEntity
import com.example.doggierace.data.entities.MetodoPagoEntity
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.MascotaViewModel
import com.example.doggierace.viewmodels.InscripcionViewModel
import com.example.doggierace.viewmodels.CarreraViewModel
import com.example.doggierace.viewmodels.MetodoPagoViewModel
import kotlinx.coroutines.launch

class InscribirMascotaFragment : Fragment() {

    private var _binding: FragmentInscribirMascotaBinding? = null
    private val binding get() = _binding!!

    private val mascotaViewModel: MascotaViewModel by viewModels()
    private val inscripcionViewModel: InscripcionViewModel by viewModels()
    private val carreraViewModel: CarreraViewModel by viewModels()
    private val metodoPagoViewModel: MetodoPagoViewModel by viewModels()

    private val args: InscribirMascotaFragmentArgs by navArgs()
    private lateinit var sessionManager: SessionManager
    private lateinit var mascotasAdapter: MisMascotasAdapter

    private var carreraId: Long = 0L
    private var carreraNombre: String = ""
    private var edadMinimaCarrera: Int = 1
    private var costoInscripcion: Double = 0.0
    private var mascotasInscritas: Set<Long> = emptySet()
    private var metodoPagoPredeterminado: MetodoPagoEntity? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInscribirMascotaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sessionManager = SessionManager(requireContext())
        carreraId = args.carreraId
        carreraNombre = args.carreraNombre

        setupToolbar()
        configurarRecyclerView() // ✅ Configurar RecyclerView VACÍO primero
        cargarMetodoPagoPredeterminado()
        cargarDatosCarrera() // ✅ Esto llamará a cargarMascotas() cuando esté listo
    }

    private fun setupToolbar() {
        binding.toolbar.title = "Seleccionar Mascota"
        binding.toolbar.subtitle = carreraNombre
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun cargarDatosCarrera() {
        carreraViewModel.cargarCarreraPorId(carreraId)
        carreraViewModel.carreraActual.observe(viewLifecycleOwner) { carrera ->
            carrera?.let {
                edadMinimaCarrera = it.edadMinima
                costoInscripcion = it.costoInscripcion

                binding.tvInstrucciones.text =
                    "Selecciona las mascotas que deseas inscribir.\n" +
                            "✓ Edad mínima: $edadMinimaCarrera año(s)\n" +
                            "💰 Costo: $${String.format("%.2f", costoInscripcion)}"

                // ✅ AHORA SÍ cargar las mascotas
                cargarMascotas()
            }
        }
    }

    private fun cargarMetodoPagoPredeterminado() {
        val participanteId = sessionManager.obtenerUserId()
        if (participanteId == -1L) return

        lifecycleScope.launch {
            try {
                val metodosPago = metodoPagoViewModel.obtenerMetodosPagoDeParticipante(participanteId)
                metodosPago.observe(viewLifecycleOwner) { metodos ->
                    metodoPagoPredeterminado = metodos.find { it.esPredeterminada }

                    if (metodoPagoPredeterminado == null && metodos.isNotEmpty()) {
                        metodoPagoPredeterminado = metodos.first()
                    }
                }
            } catch (e: Exception) {
                // Continuar sin método de pago
            }
        }
    }

    private fun configurarRecyclerView() {
        mascotasAdapter = MisMascotasAdapter(
            onItemClick = { },
            onEditClick = null,
            onDeleteClick = null,
            onInscribirClick = { mascota ->
                validarEInscribirMascota(mascota)
            },
            onDesinscribirClick = { mascota ->
                eliminarInscripcion(mascota)
            },
            modoInscripcion = true,
            mascotasInscritasInicial = mascotasInscritas
        )

        binding.rvMascotas.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = mascotasAdapter
            setHasFixedSize(true)
        }
    }

    private fun cargarMascotas() {
        val participanteId = sessionManager.obtenerUserId()
        if (participanteId == -1L) {
            Toast.makeText(requireContext(), "Error: No hay sesión activa", Toast.LENGTH_SHORT).show()
            findNavController().popBackStack()
            return
        }

        lifecycleScope.launch {
            // ✅ Obtener mascotas inscritas
            mascotasInscritas = inscripcionViewModel.obtenerIdsMascotasInscritas(carreraId, participanteId)

            // ✅ Actualizar el adapter con los nuevos datos (NO RECREARLO)
            mascotasAdapter.actualizarMascotasInscritas(mascotasInscritas)

            // ✅ Observar mascotas UNA SOLA VEZ
            mascotaViewModel.obtenerMascotasDeParticipanteLiveData(participanteId)
                .observe(viewLifecycleOwner) { mascotas ->
                    if (mascotas.isEmpty()) {
                        mostrarEstadoVacio()
                    } else {
                        mostrarMascotas(mascotas)
                    }
                }
        }
    }

    private fun mostrarMascotas(mascotas: List<MascotaEntity>) {
        binding.rvMascotas.visibility = View.VISIBLE
        binding.layoutVacio.visibility = View.GONE
        mascotasAdapter.submitList(mascotas.toList()) // ✅ Nueva lista para forzar actualización
    }

    private fun mostrarEstadoVacio() {
        binding.rvMascotas.visibility = View.GONE
        binding.layoutVacio.visibility = View.VISIBLE
    }

    private fun validarEInscribirMascota(mascota: MascotaEntity) {
        // Validar edad mínima
        if (mascota.edad < edadMinimaCarrera) {
            Toast.makeText(
                requireContext(),
                "❌ ${mascota.nombre} no cumple con la edad mínima\n" +
                        "Requerido: $edadMinimaCarrera año(s) | Actual: ${mascota.edad} año(s)",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        // Validar metodo de pago
        if (metodoPagoPredeterminado == null) {
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Sin método de pago")
                .setMessage("No tienes un método de pago registrado.\n\n¿Deseas agregar uno ahora?")
                .setPositiveButton("Agregar") { _, _ ->
                    findNavController().navigate(R.id.fragmentAgregarMetodoPago) // ✅ ID correcto
                }
                .setNegativeButton("Cancelar", null)
                .show()
            return
        }

        // Mostrar diálogo de confirmación
        val metodoPago = metodoPagoPredeterminado!!
        val mensaje = """
            ¿Inscribir a ${mascota.nombre} en esta carrera?
            
            📋 Información de la mascota:
            ✓ Edad: ${mascota.edad} año(s)
            • Peso: ${mascota.peso} kg
            • Raza: ${mascota.raza}
            
            💳 Método de pago:
            ${metodoPago.tipo} •••• ${metodoPago.numeroTarjeta}
            
            💰 Costo: $${String.format("%.2f", costoInscripcion)}
        """.trimIndent()

        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Confirmar Inscripción")
            .setMessage(mensaje)
            .setPositiveButton("Inscribir") { _, _ ->
                inscribirMascota(mascota)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun inscribirMascota(mascota: MascotaEntity) {
        val participanteId = sessionManager.obtenerUserId()
        binding.progressBar.visibility = View.VISIBLE

        inscripcionViewModel.inscribirMascota(
            carreraId = carreraId,
            mascotaId = mascota.id,
            participanteId = participanteId,
            categoria = "",
            onSuccess = { inscripcionId ->
                binding.progressBar.visibility = View.GONE
                Toast.makeText(
                    requireContext(),
                    "✓ ${mascota.nombre} inscrito exitosamente!",
                    Toast.LENGTH_SHORT
                ).show()

                // ✅ Recargar datos de carrera (actualiza cupos) Y mascotas
                cargarDatosCarrera()
            },
            onError = { mensaje ->
                binding.progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "❌ $mensaje", Toast.LENGTH_LONG).show()
            }
        )
    }

    private fun eliminarInscripcion(mascota: MascotaEntity) {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Eliminar Inscripción")
            .setMessage("¿Deseas eliminar la inscripción de ${mascota.nombre}?")
            .setPositiveButton("Eliminar") { _, _ ->
                binding.progressBar.visibility = View.VISIBLE
                inscripcionViewModel.eliminarInscripcion(
                    carreraId = carreraId,
                    mascotaId = mascota.id,
                    onSuccess = {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(
                            requireContext(),
                            "✓ Inscripción eliminada",
                            Toast.LENGTH_SHORT
                        ).show()

                        // ✅ Recargar todo
                        cargarDatosCarrera()
                    },
                    onError = { mensaje ->
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(requireContext(), "❌ $mensaje", Toast.LENGTH_LONG).show()
                    }
                )
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
