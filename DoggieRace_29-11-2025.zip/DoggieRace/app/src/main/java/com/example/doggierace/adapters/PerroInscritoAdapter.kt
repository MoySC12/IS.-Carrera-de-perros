package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.databinding.ItemPerroInscritoBinding
import com.example.doggierace.data.entities.MascotaEntity

class PerroInscritoAdapter : ListAdapter<MascotaEntity, PerroInscritoAdapter.ViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPerroInscritoBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ViewHolder(private val binding: ItemPerroInscritoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(mascota: MascotaEntity) {
            binding.tvNombrePerro.text = mascota.nombre
            binding.tvRazaPerro.text = mascota.raza
            binding.tvCategoriaPerro.text = when {
                mascota.peso < 15 -> "Pequeña (hasta 15 kg)"
                mascota.peso in 15.0..30.0 -> "Mediana (15 - 30 kg)"
                else -> "Grande (más de 30 kg)"
            }
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<MascotaEntity>() {
        override fun areItemsTheSame(oldItem: MascotaEntity, newItem: MascotaEntity) =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: MascotaEntity, newItem: MascotaEntity) =
            oldItem == newItem
    }
}
