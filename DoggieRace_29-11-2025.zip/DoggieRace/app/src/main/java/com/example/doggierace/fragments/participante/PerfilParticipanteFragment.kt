package com.example.doggierace.fragments.participante

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.doggierace.BienvenidaActivity
import com.example.doggierace.InicioSesionActivity
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentPerfilParticipanteBinding
import com.example.doggierace.utils.AuthManager
import com.example.doggierace.utils.SessionManager

class PerfilParticipanteFragment : Fragment() {

    private var _binding: FragmentPerfilParticipanteBinding? = null
    private val binding get() = _binding!!
    private lateinit var authManager: AuthManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPerfilParticipanteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        authManager = AuthManager(requireContext())

        cargarDatosUsuario()
        setupClickListeners()
    }

    private fun cargarDatosUsuario() {
        val usuario = authManager.obtenerSesionActual()

        usuario?.let {
            // Mostrar nombre del usuario
            binding.tvNombreUsuario.text = it.nombre

            // Mostrar email del usuario
            binding.tvCorreoUsuario.text = it.email
        }
    }

    private fun setupClickListeners() {
        // ✅ Botón: Editar Perfil
        binding.btnEditarPerfil.setOnClickListener {
            findNavController().navigate(R.id.action_perfil_to_editarPerfil)
        }

        // ✅ Botón: Agregar Mascota
        binding.btnAgregarMascota.setOnClickListener {
            findNavController().navigate(R.id.action_perfil_to_agregarMascota)
        }

        // ✅ Botón: Mis Mascotas
        binding.btnMisMascotas.setOnClickListener {
            findNavController().navigate(R.id.action_perfil_to_misMascotas)
        }

        // ✅ Botón: Métodos de Pago
        binding.btnMetodosPago.setOnClickListener {
            findNavController().navigate(R.id.action_perfil_to_metodosPago)
        }

        // Botón: Cerrar Sesión
        binding.btnCerrarSesion.setOnClickListener {
            mostrarDialogoCerrarSesion()
        }
    }

    private fun mostrarDialogoCerrarSesion() {
        AlertDialog.Builder(requireContext())
            .setTitle("¿Cerrar Sesión?")
            .setMessage("¿Estás seguro de que deseas cerrar sesión?")
            .setPositiveButton("Confirmar") { dialog, _ ->
                cerrarSesion()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    // Ejemplo de uso en un Fragment
    private fun cerrarSesion() {
        val sessionManager = SessionManager(requireContext())
        sessionManager.cerrarSesion()

        // Navegar a pantalla de login
        val intent = Intent(requireContext(), InicioSesionActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        requireActivity().finish()
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
