package com.example.doggierace.models

data class ParticipanteCategoria(
    val id: String,
    val nombreDueño: String,
    val nombreMascota: String,
    var asistio: Boolean = true, // 'true' (Sí) por defecto
    var tiempo: String = ""
)
