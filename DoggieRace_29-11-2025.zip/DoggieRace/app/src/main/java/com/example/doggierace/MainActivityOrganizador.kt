package com.example.doggierace

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import com.example.doggierace.databinding.ActivityMainOrganizadorBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivityOrganizador : AppCompatActivity() {

    private lateinit var binding: ActivityMainOrganizadorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainOrganizadorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNavigation()
    }

    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment_organizador) as NavHostFragment

        val navController = navHostFragment.navController

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_navigation_organizador)

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.fragmentCarrerasOrganizador -> {
                    // ✅ Navegar a Carreras
                    navController.navigate(R.id.fragmentCarrerasOrganizador)
                    true
                }
                R.id.fragmentEnVivoOrganizador -> {
                    // ✅ Navegar a En Vivo
                    navController.navigate(R.id.fragmentEnVivoOrganizador)
                    true
                }
                R.id.fragmentPerfilOrganizador -> {
                    // ✅ Navegar a Perfil
                    navController.navigate(R.id.fragmentPerfilOrganizador)
                    true
                }
                else -> false
            }
        }
    }
}
