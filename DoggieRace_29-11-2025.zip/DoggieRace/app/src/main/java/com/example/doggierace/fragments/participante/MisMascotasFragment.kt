package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.R
import com.example.doggierace.adapters.MisMascotasAdapter
import com.example.doggierace.databinding.FragmentMisMascotasBinding
import com.example.doggierace.data.entities.MascotaEntity
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.MascotaViewModel

class MisMascotasFragment : Fragment() {

    private var _binding: FragmentMisMascotasBinding? = null
    private val binding get() = _binding!!

    private val mascotaViewModel: MascotaViewModel by viewModels()
    private lateinit var sessionManager: SessionManager
    private lateinit var adapter: MisMascotasAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMisMascotasBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        cargarMascotas()
        observarResultados()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }


    private fun setupRecyclerView() {
        adapter = MisMascotasAdapter(
            onItemClick = { mascota ->
                // Click en la card completa - Mostrar opciones
                mostrarOpcionesMascota(mascota)
            },
            onEditClick = { mascota ->
                // Click en botón Editar
                navegarAEditarMascota(mascota)
            },
            onDeleteClick = { mascota ->
                // Click en botón Eliminar
                mostrarDialogoEliminar(mascota)
            },
            onInscribirClick = null,  // No se usa en esta pantalla
            modoInscripcion = false   // Modo normal (mostrar Editar/Eliminar)
        )

        binding.rvMisMascotas.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@MisMascotasFragment.adapter
            setHasFixedSize(true)
        }
    }


    private fun setupClickListeners() {
        // Botón: Agregar Nueva Mascota
        binding.btnAgregarMascota.setOnClickListener {
            findNavController().navigate(R.id.action_misMascotas_to_agregarMascota)
        }
    }

    private fun cargarMascotas() {
        val participanteId = sessionManager.obtenerUserId()

        if (participanteId == -1L) {
            Toast.makeText(
                requireContext(),
                "Error: No hay sesión activa",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        // Observar mascotas del participante con LiveData
        mascotaViewModel.obtenerMascotasDeParticipanteLiveData(participanteId)
            .observe(viewLifecycleOwner) { mascotas ->
                if (mascotas.isEmpty()) {
                    mostrarEstadoVacio()
                } else {
                    mostrarListaMascotas(mascotas)
                }
            }
    }

    private fun mostrarEstadoVacio() {
        binding.rvMisMascotas.visibility = View.GONE
        binding.layoutVacio.visibility = View.VISIBLE  // ⬅️ Mostrar estado vacío
    }

    private fun mostrarListaMascotas(mascotas: List<MascotaEntity>) {
        binding.rvMisMascotas.visibility = View.VISIBLE
        binding.layoutVacio.visibility = View.GONE  // ⬅️ Ocultar estado vacío
        adapter.submitList(mascotas)
    }

    private fun mostrarOpcionesMascota(mascota: MascotaEntity) {
        val opciones = arrayOf("Ver/Editar", "Eliminar", "Cancelar")

        AlertDialog.Builder(requireContext())
            .setTitle(mascota.nombre)
            .setItems(opciones) { dialog, which ->
                when (which) {
                    0 -> navegarAEditarMascota(mascota)
                    1 -> mostrarDialogoEliminar(mascota)
                    2 -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun navegarAEditarMascota(mascota: MascotaEntity) {
        val action = MisMascotasFragmentDirections
            .actionMisMascotasToEditarMascota(mascota.id)
        findNavController().navigate(action)
    }


    private fun mostrarDialogoEliminar(mascota: MascotaEntity) {
        AlertDialog.Builder(requireContext())
            .setTitle("Eliminar Mascota")
            .setMessage("¿Estás seguro de que deseas eliminar a ${mascota.nombre}?\n\nEsta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                eliminarMascota(mascota)
            }
            .setNegativeButton("Cancelar", null)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show()
    }

    private fun eliminarMascota(mascota: MascotaEntity) {
        mascotaViewModel.eliminarMascota(mascota.id)
    }

    private fun observarResultados() {
        mascotaViewModel.resultadoOperacion.observe(viewLifecycleOwner) { resultado ->
            when (resultado) {
                is MascotaViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(
                        requireContext(),
                        resultado.mensaje,
                        Toast.LENGTH_SHORT
                    ).show()
                }
                is MascotaViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(
                        requireContext(),
                        resultado.mensaje,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
