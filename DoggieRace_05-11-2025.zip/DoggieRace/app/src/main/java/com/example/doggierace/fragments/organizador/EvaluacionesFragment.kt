package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.adapters.EvaluacionesAdapter
import com.example.doggierace.databinding.FragmentEvaluacionesBinding
import com.example.doggierace.models.Evaluacion

class EvaluacionesFragment : Fragment() {

    private var _binding: FragmentEvaluacionesBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEvaluacionesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupRecyclerView()
    }

    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)

        // TODO: Obtener argumentos del NavGraph
        // val carreraId = arguments?.getString("carreraId") ?: ""
        // val carreraNombre = arguments?.getString("carreraNombre") ?: "Carrera"
        // binding.toolbar.title = "Evaluaciones: $carreraNombre"
    }

    private fun setupRecyclerView() {
        // Datos de prueba (Mock Data)
        val evaluaciones = listOf(
            Evaluacion(
                participanteNombre = "Juan Pérez",
                participanteEmail = "juan.p@correo.com",
                comentario = "¡La organización fue genial! Los puntos de agua estuvieron perfectos. Gracias."
            ),
            Evaluacion(
                participanteNombre = "Ana García",
                participanteEmail = "ana.g@correo.com",
                comentario = "Me gustó, pero hizo falta sombra en la meta. El mapa del recorrido fue muy claro."
            ),
            Evaluacion(
                participanteNombre = "Miguel H.",
                participanteEmail = "miguel.h@correo.com",
                comentario = "Mi perro se divirtió mucho. Sugerencia: más botes de basura en la ruta."
            )
        )

        // Configurar adaptador
        val adapter = EvaluacionesAdapter(evaluaciones)

        // Configurar RecyclerView
        binding.rvEvaluaciones.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
