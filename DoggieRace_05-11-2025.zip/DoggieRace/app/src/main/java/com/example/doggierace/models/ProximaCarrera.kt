package com.example.doggierace.models

import java.util.Date

data class ProximaCarrera(
    val id: String,
    val nombre: String,
    val inscritos: Int,
    val cupoMaximo: Int,
    val fecha: Date,
    val lugar: String
)
