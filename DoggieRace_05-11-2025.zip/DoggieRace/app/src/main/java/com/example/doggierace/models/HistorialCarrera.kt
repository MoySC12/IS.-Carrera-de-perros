package com.example.doggierace.models

data class HistorialCarrera(
    val nombre: String,
    val lugar: String,
    val fecha: String
)
