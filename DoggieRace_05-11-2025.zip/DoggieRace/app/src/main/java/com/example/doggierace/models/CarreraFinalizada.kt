package com.example.doggierace.models

import java.util.Date

data class CarreraFinalizada(
    val id: String,
    val nombre: String,
    val fecha: Date,
    val lugar: String
)
