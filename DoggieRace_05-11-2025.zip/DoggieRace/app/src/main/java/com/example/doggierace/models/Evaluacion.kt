package com.example.doggierace.models

data class Evaluacion(
    val participanteNombre: String,
    val participanteEmail: String,
    val comentario: String
)
