package com.example.doggierace.models

data class Evento(
    val id: String,
    val nombre: String,
    val fecha: String,
    val lugar: String
)
