package com.example.doggierace

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import com.example.doggierace.databinding.ActivityMainOrganizadorBinding
import com.example.doggierace.utils.AuthManager
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivityOrganizador : AppCompatActivity() {

    private lateinit var binding: ActivityMainOrganizadorBinding
    private lateinit var authManager: AuthManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainOrganizadorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializar AuthManager
        authManager = AuthManager(this)

        setupNavigation()
    }

    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment_organizador) as NavHostFragment

        val navController = navHostFragment.navController

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_navigation_organizador)

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.fragmentEventosOrganizador -> {
                    // ✅ Navegar a Eventos
                    navController.navigate(R.id.fragmentEventosOrganizador)
                    true
                }
                R.id.fragmentEnVivoOrganizador -> {
                    // ⚠️ Toast para "En Vivo"
                    Toast.makeText(
                        this,
                        "Funcionalidad en desarrollo",
                        Toast.LENGTH_SHORT
                    ).show()
                    false
                }
                R.id.fragmentPerfilOrganizador -> {
                    // 🚪 Cerrar sesión al presionar "Perfil"
                    cerrarSesion()
                    false
                }
                else -> false
            }
        }
    }

    private fun cerrarSesion() {
        // Cerrar sesión en AuthManager
        authManager.cerrarSesion()

        // Mostrar Toast
        Toast.makeText(
            this,
            "Funcion en desarrollo. Cerrando sesión",
            Toast.LENGTH_SHORT
        ).show()

        // Redirigir a BienvenidaActivity
        val intent = Intent(this, BienvenidaActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)

        // Finalizar actividad actual
        finish()
    }
}
