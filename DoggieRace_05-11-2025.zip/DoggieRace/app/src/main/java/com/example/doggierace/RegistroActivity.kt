package com.example.doggierace

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.example.doggierace.utils.AuthManager
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class RegistroActivity : AppCompatActivity() {

    private lateinit var btnVolver: TextView
    private lateinit var etNombre: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var cardParticipante: CardView
    private lateinit var cardOrganizador: CardView
    private lateinit var btnCrearCuenta: CardView
    private lateinit var labelCodigoOrganizador: TextView
    private lateinit var tilCodigoOrganizador: TextInputLayout
    private lateinit var etCodigoOrganizador: TextInputEditText
    private lateinit var tvInfoCodigo: TextView
    private lateinit var authManager: AuthManager

    private var tipoUsuarioSeleccionado: String = ""

    // Código válido de organizador para pruebas
    private val CODIGO_ORGANIZADOR_VALIDO = "ORG2025"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        authManager = AuthManager(this)

        initializeViews()
        setupClickListeners()
    }

    private fun initializeViews() {
        btnVolver = findViewById(R.id.btnVolver)
        etNombre = findViewById(R.id.etNombre)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        cardParticipante = findViewById(R.id.cardParticipante)
        cardOrganizador = findViewById(R.id.cardOrganizador)
        btnCrearCuenta = findViewById(R.id.btnCrearCuenta)

        // Inicializar elementos del código de organizador
        labelCodigoOrganizador = findViewById(R.id.labelCodigoOrganizador)
        tilCodigoOrganizador = findViewById(R.id.tilCodigoOrganizador)
        etCodigoOrganizador = findViewById(R.id.etCodigoOrganizador)
        tvInfoCodigo = findViewById(R.id.tvInfoCodigo)
    }

    private fun setupClickListeners() {
        btnVolver.setOnClickListener {
            finish()
        }

        cardParticipante.setOnClickListener {
            seleccionarTipoUsuario("PARTICIPANTE")
        }

        cardOrganizador.setOnClickListener {
            seleccionarTipoUsuario("ORGANIZADOR")
        }

        btnCrearCuenta.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val codigoOrganizador = etCodigoOrganizador.text.toString().trim()

            if (validateInputs(nombre, email, password, codigoOrganizador)) {
                registrarUsuario(nombre, email, password)
            }
        }
    }

    private fun seleccionarTipoUsuario(tipo: String) {
        tipoUsuarioSeleccionado = tipo

        // Actualizar el estilo de las tarjetas según la selección
        if (tipo == "PARTICIPANTE") {
            cardParticipante.setCardBackgroundColor(getColor(R.color.verde_primario))
            cardOrganizador.setCardBackgroundColor(getColor(R.color.blanco))

            // Ocultar campos de código de organizador
            ocultarCampoCodigoOrganizador()

        } else {
            cardOrganizador.setCardBackgroundColor(getColor(R.color.verde_primario))
            cardParticipante.setCardBackgroundColor(getColor(R.color.blanco))

            // Mostrar campos de código de organizador
            mostrarCampoCodigoOrganizador()
        }
    }

    private fun mostrarCampoCodigoOrganizador() {
        labelCodigoOrganizador.visibility = View.VISIBLE
        tilCodigoOrganizador.visibility = View.VISIBLE
        tvInfoCodigo.visibility = View.VISIBLE
    }

    private fun ocultarCampoCodigoOrganizador() {
        labelCodigoOrganizador.visibility = View.GONE
        tilCodigoOrganizador.visibility = View.GONE
        tvInfoCodigo.visibility = View.GONE
        etCodigoOrganizador.setText("") // Limpiar el campo
    }

    private fun registrarUsuario(nombre: String, email: String, password: String) {
        val registroExitoso = authManager.registrarUsuario(
            email,
            password,
            nombre,
            tipoUsuarioSeleccionado
        )

        if (registroExitoso) {
            Toast.makeText(
                this,
                "Cuenta creada exitosamente como $tipoUsuarioSeleccionado",
                Toast.LENGTH_LONG
            ).show()
            finish()
        } else {
            Toast.makeText(
                this,
                "Este email ya está registrado",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun validateInputs(nombre: String, email: String, password: String, codigoOrganizador: String): Boolean {
        if (nombre.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa tu nombre completo", Toast.LENGTH_SHORT).show()
            return false
        }

        if (email.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa tu correo electrónico", Toast.LENGTH_SHORT).show()
            return false
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Por favor ingresa un correo válido", Toast.LENGTH_SHORT).show()
            return false
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa una contraseña", Toast.LENGTH_SHORT).show()
            return false
        }

        if (password.length < 6) {
            Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show()
            return false
        }

        if (tipoUsuarioSeleccionado.isEmpty()) {
            Toast.makeText(this, "Por favor selecciona el tipo de usuario", Toast.LENGTH_SHORT).show()
            return false
        }

        // Validación específica para organizadores
        if (tipoUsuarioSeleccionado == "ORGANIZADOR") {
            if (codigoOrganizador.isEmpty()) {
                Toast.makeText(this, "Por favor ingresa el código de organizador", Toast.LENGTH_SHORT).show()
                return false
            }

            if (codigoOrganizador != CODIGO_ORGANIZADOR_VALIDO) {
                Toast.makeText(this, "Código de organizador inválido", Toast.LENGTH_LONG).show()
                return false
            }
        }

        return true
    }
}
