package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.databinding.ItemEvaluacionBinding
import com.example.doggierace.models.Evaluacion

class EvaluacionesAdapter(
    private val evaluaciones: List<Evaluacion>
) : RecyclerView.Adapter<EvaluacionesAdapter.EvaluacionViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EvaluacionViewHolder {
        val binding = ItemEvaluacionBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EvaluacionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EvaluacionViewHolder, position: Int) {
        holder.bind(evaluaciones[position])
    }

    override fun getItemCount(): Int = evaluaciones.size

    inner class EvaluacionViewHolder(
        private val binding: ItemEvaluacionBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(evaluacion: Evaluacion) {
            binding.tvParticipanteNombre.text = evaluacion.participanteNombre
            binding.tvParticipanteEmail.text = "(${evaluacion.participanteEmail})"
            binding.tvComentario.text = evaluacion.comentario
        }
    }
}
