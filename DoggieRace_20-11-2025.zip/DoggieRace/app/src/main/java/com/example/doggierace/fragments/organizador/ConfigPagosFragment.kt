package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentConfigPagosBinding

class ConfigPagosFragment : Fragment() {

    private var _binding: FragmentConfigPagosBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentConfigPagosBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        // Configurar Toolbar
        binding.toolbar.setupWithNavController(navController)

        // Configurar selector de bancos
        setupBancoDropdown()

        // Configurar listener del botón
        setupClickListeners()
    }

    private fun setupBancoDropdown() {
        // Obtener la lista de bancos desde resources
        val bancos = resources.getStringArray(R.array.bancos_array)

        // Crear el adapter para el AutoCompleteTextView
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            bancos
        )

        // Asignar el adapter al AutoCompleteTextView
        binding.actvBanco.setAdapter(adapter)
    }

    private fun setupClickListeners() {
        // Botón: Guardar Cuenta
        binding.btnGuardarCuenta.setOnClickListener {
            guardarCuenta()
        }
    }

    private fun guardarCuenta() {
        // Obtener datos de los campos
        val titular = binding.etTitular.text.toString().trim()
        val banco = binding.actvBanco.text.toString().trim()
        val clabe = binding.etClabe.text.toString().trim()

        // Limpiar errores previos
        binding.inputLayoutTitular.error = null
        binding.inputLayoutBanco.error = null
        binding.inputLayoutClabe.error = null

        // Validación: Nombre del Titular
        if (titular.isEmpty()) {
            binding.inputLayoutTitular.error = "El nombre del titular es obligatorio"
            return
        }

        // Validación: Banco
        if (banco.isEmpty() || banco == "Selecciona un banco...") {
            binding.inputLayoutBanco.error = "Selecciona un banco"
            return
        }

        // Validación: CLABE (debe tener exactamente 18 dígitos)
        if (clabe.length != 18) {
            binding.inputLayoutClabe.error = "La CLABE debe tener 18 dígitos"
            return
        }

        // TODO: Guardar en base de datos o enviar al servidor
        // Por ahora, solo mostramos un Toast

        Toast.makeText(
            requireContext(),
            "Cuenta de pago guardada",
            Toast.LENGTH_SHORT
        ).show()

        // Volver a la pantalla anterior
        findNavController().popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
