package com.example.doggierace.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.doggierace.models.Usuario
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class AuthManager(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("DoggieRaceAuth", Context.MODE_PRIVATE)

    private val gson = Gson()

    // Registrar nuevo usuario
    fun registrarUsuario(email: String, password: String, nombre: String, tipoUsuario: String): Boolean {
        // Verificar si el usuario ya existe
        if (usuarioExiste(email)) {
            return false
        }

        // Obtener lista actual de usuarios
        val usuarios = obtenerTodosLosUsuarios().toMutableList()

        // Agregar nuevo usuario
        val nuevoUsuario = Usuario(email, password, nombre, tipoUsuario)
        usuarios.add(nuevoUsuario)

        // Guardar lista actualizada
        val usuariosJson = gson.toJson(usuarios)
        sharedPreferences.edit().putString("usuarios", usuariosJson).apply()

        return true
    }

    // Iniciar sesión
    fun iniciarSesion(email: String, password: String): Usuario? {
        val usuarios = obtenerTodosLosUsuarios()

        return usuarios.find {
            it.email.equals(email, ignoreCase = true) && it.password == password
        }
    }

    // Guardar sesión actual
    fun guardarSesion(usuario: Usuario) {
        val usuarioJson = gson.toJson(usuario)
        sharedPreferences.edit()
            .putString("sesion_actual", usuarioJson)
            .putBoolean("sesion_activa", true)
            .apply()
    }

    // Obtener sesión actual
    fun obtenerSesionActual(): Usuario? {
        val usuarioJson = sharedPreferences.getString("sesion_actual", null) ?: return null
        return gson.fromJson(usuarioJson, Usuario::class.java)
    }

    // Verificar si hay sesión activa
    fun tieneSesionActiva(): Boolean {
        return sharedPreferences.getBoolean("sesion_activa", false)
    }

    // Cerrar sesión
    fun cerrarSesion() {
        sharedPreferences.edit()
            .remove("sesion_actual")
            .putBoolean("sesion_activa", false)
            .apply()
    }

    // Verificar si un usuario ya existe
    private fun usuarioExiste(email: String): Boolean {
        val usuarios = obtenerTodosLosUsuarios()
        return usuarios.any { it.email.equals(email, ignoreCase = true) }
    }

    // Obtener todos los usuarios registrados
    private fun obtenerTodosLosUsuarios(): List<Usuario> {
        val usuariosJson = sharedPreferences.getString("usuarios", null) ?: return emptyList()
        val type = object : TypeToken<List<Usuario>>() {}.type
        return gson.fromJson(usuariosJson, type)
    }
}
