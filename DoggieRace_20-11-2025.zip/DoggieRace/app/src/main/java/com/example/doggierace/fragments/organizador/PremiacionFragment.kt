package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.databinding.FragmentPremiacionBinding

class PremiacionFragment : Fragment() {

    private var _binding: FragmentPremiacionBinding? = null
    private val binding get() = _binding!!

    // Argumentos recibidos
    private var categoriaId: String? = null
    private var categoriaNombre: String? = null
    private var carreraNombre: String? = null
    private var horaSalida: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            categoriaId = it.getString("categoriaId")
            categoriaNombre = it.getString("categoriaNombre")
            carreraNombre = it.getString("carreraNombre")
            horaSalida = it.getString("horaSalida")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPremiacionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        // Configurar Toolbar
        binding.toolbar.setupWithNavController(navController)

        // Cargar datos del header
        cargarDatosCategoria()

        // Botón: Guardar Premiación
        binding.btnGuardarPremiacion.setOnClickListener {
            guardarPremiacion()
        }
    }

    private fun cargarDatosCategoria() {
        binding.tvCarreraNombre.text = carreraNombre ?: "Carrera del Bosque"
        binding.tvCategoriaNombre.text = "Categoría: ${categoriaNombre ?: "Razas Pequeñas"}"
        binding.tvCategoriaHora.text = "⏰ Hora de Salida: ${horaSalida ?: "9:00 AM"}"
    }

    private fun guardarPremiacion() {
        // Obtener datos del 1er lugar
        val dueno1 = binding.etDueno1.text.toString().trim()
        val mascota1 = binding.etMascota1.text.toString().trim()
        val tiempo1 = binding.etTiempo1.text.toString().trim()

        // Obtener datos del 2do lugar
        val dueno2 = binding.etDueno2.text.toString().trim()
        val mascota2 = binding.etMascota2.text.toString().trim()
        val tiempo2 = binding.etTiempo2.text.toString().trim()

        // Obtener datos del 3er lugar
        val dueno3 = binding.etDueno3.text.toString().trim()
        val mascota3 = binding.etMascota3.text.toString().trim()
        val tiempo3 = binding.etTiempo3.text.toString().trim()

        // Validación básica (al menos el 1er lugar debe estar completo)
        if (dueno1.isEmpty() || mascota1.isEmpty() || tiempo1.isEmpty()) {
            Toast.makeText(
                requireContext(),
                "Por favor, completa al menos el 1er lugar",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // TODO: Guardar en base de datos
        // Por ahora, solo mostramos un resumen
        Toast.makeText(
            requireContext(),
            "Premiación guardada correctamente",
            Toast.LENGTH_SHORT
        ).show()

        // Volver a la pantalla anterior
        findNavController().popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
