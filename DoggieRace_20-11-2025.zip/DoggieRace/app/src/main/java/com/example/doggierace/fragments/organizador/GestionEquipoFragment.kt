package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentGestionEquipoBinding

class GestionEquipoFragment : Fragment() {

    private var _binding: FragmentGestionEquipoBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGestionEquipoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        // Configurar Toolbar
        binding.toolbar.setupWithNavController(navController)

        // Configurar listener del botón
        setupClickListeners()
    }

    private fun setupClickListeners() {
        // Botón: Desbloquear Código
        binding.btnDesbloquearCodigo.setOnClickListener {
            desbloquearCodigo()
        }
    }

    private fun desbloquearCodigo() {
        val passwordIngresada = binding.etPassword.text.toString()

        // --- SIMULACIÓN DE VALIDACIÓN ---
        // En una app real, esto se verificaría contra Firebase Auth o un ViewModel
        val passwordCorrecta = "12345" // Contraseña de prueba

        if (passwordIngresada == passwordCorrecta) {
            // ✅ Contraseña Correcta: Mostrar Estado 2 (Desbloqueado)
            binding.containerBloqueado.visibility = View.GONE
            binding.containerDesbloqueado.visibility = View.VISIBLE

            // Desactivar campos
            binding.btnDesbloquearCodigo.isEnabled = false
            binding.btnDesbloquearCodigo.text = "Código Desbloqueado"
            binding.inputLayoutPassword.isEnabled = false
            binding.inputLayoutPassword.error = null // Limpiar error

            // TODO: En una app real, cargar el código desde la base de datos
            // Por ahora, usa el código hardcoded en el XML
        } else {
            // ❌ Contraseña Incorrecta
            binding.inputLayoutPassword.error = "Contraseña incorrecta"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
