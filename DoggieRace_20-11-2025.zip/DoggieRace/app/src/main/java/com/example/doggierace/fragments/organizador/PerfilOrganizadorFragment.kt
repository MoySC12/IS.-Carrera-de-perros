package com.example.doggierace.fragments.organizador

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.doggierace.BienvenidaActivity
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentPerfilOrganizadorBinding
import com.example.doggierace.utils.AuthManager

class PerfilOrganizadorFragment : Fragment() {

    private var _binding: FragmentPerfilOrganizadorBinding? = null
    private val binding get() = _binding!!
    private lateinit var authManager: AuthManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPerfilOrganizadorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inicializar AuthManager
        authManager = AuthManager(requireContext())

        // Cargar datos del perfil
        cargarDatosPerfil()

        // Configurar listeners de navegación
        setupClickListeners()
    }

    private fun cargarDatosPerfil() {
        val usuario = authManager.obtenerSesionActual()

        usuario?.let {
            // Mostrar nombre del organizador
            binding.tvNombreOrganizador.text = it.nombre

            // Mostrar email del organizador
            binding.tvCorreoOrganizador.text = it.email
        }
    }

    private fun setupClickListeners() {
        val navController = findNavController()

        // Botón: Editar Perfil
        binding.btnEditarPerfil.setOnClickListener {
            navController.navigate(R.id.fragmentEditarPerfilOrganizador)
        }

        // Botón: Gestión de Equipo (RF4)
        binding.btnGestionEquipo.setOnClickListener {
            navController.navigate(R.id.fragmentGestionEquipo)
        }

        // Botón: Configuración de Pagos
        binding.btnConfigPagos.setOnClickListener {
            navController.navigate(R.id.fragmentConfigPagos)
        }

        // Botón: Cerrar Sesión
        binding.btnCerrarSesion.setOnClickListener {
            mostrarDialogoCerrarSesion()
        }
    }

    private fun mostrarDialogoCerrarSesion() {
        AlertDialog.Builder(requireContext())
            .setTitle("¿Cerrar Sesión?")
            .setMessage("¿Estás seguro de que deseas cerrar sesión?")
            .setPositiveButton("Confirmar") { dialog, _ ->
                cerrarSesion()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun cerrarSesion() {
        // Cerrar sesión en AuthManager
        authManager.cerrarSesion()

        Toast.makeText(
            requireContext(),
            "Sesión cerrada correctamente",
            Toast.LENGTH_SHORT
        ).show()

        // Redirigir a BienvenidaActivity
        val intent = Intent(requireContext(), BienvenidaActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)

        // Finalizar la actividad actual
        requireActivity().finish()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
