package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.R
import com.example.doggierace.databinding.ItemCategoriaEnvivoBinding
import com.example.doggierace.models.CategoriaEnVivo
import java.text.SimpleDateFormat
import java.util.Locale

class CategoriaEnVivoAdapter(
    private val categorias: List<CategoriaEnVivo>,
    private val onItemClick: (CategoriaEnVivo) -> Unit
) : RecyclerView.Adapter<CategoriaEnVivoAdapter.CategoriaViewHolder>() {

    inner class CategoriaViewHolder(val binding: ItemCategoriaEnvivoBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoriaViewHolder {
        val binding = ItemCategoriaEnvivoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CategoriaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CategoriaViewHolder, position: Int) {
        val categoria = categorias[position]
        val context = holder.itemView.context

        // Nombre de la categoría
        holder.binding.tvNombreCategoria.text = "Categoría: ${categoria.nombre}"

        // Hora de salida formateada
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val horaFormateada = sdf.format(categoria.horaSalida)
        holder.binding.tvHoraSalida.text = "⏰ Hora de Salida: $horaFormateada"

        // Lógica visual: destacar la categoría "EN_CURSO"
        if (categoria.estado == "EN_CURSO") {
            // Destacar la tarjeta activa con verde_primario
            val colorVerde = ContextCompat.getColor(context, R.color.verde_primario)
            holder.binding.cardCategoriaEnvivo.strokeColor = colorVerde
            holder.binding.cardCategoriaEnvivo.strokeWidth =
                (2 * context.resources.displayMetrics.density).toInt() // 2dp
        } else {
            // Estilo por defecto
            val colorGris = ContextCompat.getColor(context, R.color.gris_neutro)
            holder.binding.cardCategoriaEnvivo.strokeColor = colorGris
            holder.binding.cardCategoriaEnvivo.strokeWidth =
                (1 * context.resources.displayMetrics.density).toInt() // 1dp
        }

        // Click listener
        holder.itemView.setOnClickListener {
            onItemClick(categoria)
        }
    }

    override fun getItemCount(): Int = categorias.size
}
