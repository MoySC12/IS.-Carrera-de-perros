package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.R
import com.example.doggierace.adapters.EventoAdapter
import com.example.doggierace.databinding.FragmentInicioBinding
import com.example.doggierace.models.Evento
import com.example.doggierace.utils.AuthManager

class InicioFragment : Fragment() {

    private var _binding: FragmentInicioBinding? = null
    private val binding get() = _binding!!
    private lateinit var authManager: AuthManager
    private lateinit var eventoAdapter: EventoAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInicioBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inicializar AuthManager
        authManager = AuthManager(requireContext())

        // Cargar el saludo personalizado
        cargarSaludoUsuario()

        val navController = findNavController()

        // Click en la card de próxima carrera
        binding.cardProximaCarrera.setOnClickListener {
            navController.navigate(R.id.accion_inicio_a_detalle_evento)
        }

        // Click en "Ver todas mis carreras"
        binding.tvVerTodas.setOnClickListener {
            navController.navigate(R.id.accion_inicio_a_todas_carreras)
        }

        // Configurar RecyclerView de eventos disponibles
        configurarRecyclerView()
    }

    private fun cargarSaludoUsuario() {
        val usuario = authManager.obtenerSesionActual()

        usuario?.let {
            // Mostrar saludo personalizado con el nombre del usuario
            binding.tvSaludo.text = "¡Hola, ${it.nombre}!"
        }
    }

    private fun configurarRecyclerView() {
        // Datos de ejemplo
        val eventosDisponibles = listOf(
            Evento("1", "Carrera de Verano", "30 de Nov. - 09:00 AM", "Centro de Toluca"),
            Evento("2", "Canicross Navideño", "19 de Dic. - 08:30 AM", "Paseo Colón")
        )

        eventoAdapter = EventoAdapter(eventosDisponibles) { evento ->
            // Click en un evento
            findNavController().navigate(R.id.accion_inicio_a_detalle_evento)
        }

        binding.rvEventosDisponibles.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = eventoAdapter
            setHasFixedSize(true)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
