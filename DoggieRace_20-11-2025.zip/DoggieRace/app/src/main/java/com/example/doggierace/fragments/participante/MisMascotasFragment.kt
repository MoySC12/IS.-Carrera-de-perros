package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.R
import com.example.doggierace.adapters.MisMascotasAdapter
import com.example.doggierace.databinding.FragmentMisMascotasBinding
import com.example.doggierace.models.Mascota

class MisMascotasFragment : Fragment() {

    private var _binding: FragmentMisMascotasBinding? = null
    private val binding get() = _binding!!

    private lateinit var mascotasAdapter: MisMascotasAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMisMascotasBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
    }

    // ✅ Agregar este método
    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupRecyclerView() {
        // Datos de prueba (mock data)
        val mascotas = listOf(
            Mascota(
                id = "1",
                nombre = "Fido",
                edad = 3,
                raza = "Golden Retriever"
            ),
            Mascota(
                id = "2",
                nombre = "Luna",
                edad = 1,
                raza = "Border Collie"
            )
        )

        // Configurar adaptador con navegación
        mascotasAdapter = MisMascotasAdapter(mascotas) { mascotaId ->
            // Navegar a Editar Mascota con el ID
            val bundle = Bundle().apply {
                putString("mascotaId", mascotaId)
            }
            findNavController().navigate(
                R.id.action_misMascotas_to_editarMascota,
                bundle
            )
        }

        // Configurar RecyclerView
        binding.rvMisMascotas.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = mascotasAdapter
        }
    }

    private fun setupClickListeners() {
        binding.btnAgregarMascota.setOnClickListener {
            // Navegar a Agregar Mascota
            findNavController().navigate(R.id.action_misMascotas_to_agregarMascota)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
