package com.example.doggierace.fragments.organizador

import android.app.DatePickerDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentEditarCarreraBinding
import java.text.SimpleDateFormat
import java.util.*

class EditarCarreraFragment : Fragment() {

    private var _binding: FragmentEditarCarreraBinding? = null
    private val binding get() = _binding!!

    private var imagenCircuitoUri: Uri? = null

    // Launcher para seleccionar imagen de la galería
    private val seleccionarImagenLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            imagenCircuitoUri = it
            binding.imgCircuitoActual.setImageURI(it)
            binding.imgCircuitoActual.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditarCarreraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupDropdownTipoCarrera()
        setupClickListeners()
        cargarDatosCarrera()
    }

    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupDropdownTipoCarrera() {
        val tiposCarrera = arrayOf("Pista", "Campo Abierto", "Trineo")
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            tiposCarrera
        )
        binding.autocompleteTipoCarrera.setAdapter(adapter)
    }

    private fun setupClickListeners() {
        // Botón: Cambiar Imagen
        binding.btnCambiarImagen.setOnClickListener {
            seleccionarImagenLauncher.launch("image/*")
        }

        // Campo: Fecha (DatePicker)
        binding.etFecha.setOnClickListener {
            mostrarDatePicker()
        }

        // Botón: Guardar Cambios
        binding.btnGuardarCambios.setOnClickListener {
            guardarCambios()
        }
    }

    private fun cargarDatosCarrera() {
        // TODO: Aquí cargarías los datos reales de la carrera desde la base de datos
        // Por ahora, los datos ya están pre-cargados en el XML
        // En producción, recibirías el ID de la carrera por Safe Args y consultarías la BD
    }

    private fun mostrarDatePicker() {
        val calendario = Calendar.getInstance()
        val anio = calendario.get(Calendar.YEAR)
        val mes = calendario.get(Calendar.MONTH)
        val dia = calendario.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                // Formatear fecha seleccionada
                val fechaSeleccionada = Calendar.getInstance()
                fechaSeleccionada.set(year, month, dayOfMonth)

                val formatoFecha = SimpleDateFormat("dd 'de' MMMM", Locale.forLanguageTag("es-ES"))

                binding.etFecha.setText(formatoFecha.format(fechaSeleccionada.time))
            },
            anio,
            mes,
            dia
        )

        datePickerDialog.show()
    }

    private fun guardarCambios() {
        val nombre = binding.etNombre.text.toString().trim()
        val tipoCarrera = binding.autocompleteTipoCarrera.text.toString().trim()
        val fecha = binding.etFecha.text.toString().trim()
        val lugar = binding.etLugar.text.toString().trim()
        val cupo = binding.etCupo.text.toString().trim()
        val edadMinima = binding.etEdadMinima.text.toString().trim()
        val prohibiciones = binding.etProhibiciones.text.toString().trim()

        // Validar campos obligatorios
        var isValid = true

        if (nombre.isEmpty()) {
            binding.inputLayoutNombre.error = "El nombre es obligatorio"
            isValid = false
        } else {
            binding.inputLayoutNombre.error = null
        }

        if (tipoCarrera.isEmpty()) {
            binding.inputLayoutTipoCarrera.error = "Selecciona un tipo de carrera"
            isValid = false
        } else {
            binding.inputLayoutTipoCarrera.error = null
        }

        if (fecha.isEmpty()) {
            binding.inputLayoutFecha.error = "La fecha es obligatoria"
            isValid = false
        } else {
            binding.inputLayoutFecha.error = null
        }

        if (lugar.isEmpty()) {
            binding.inputLayoutLugar.error = "El lugar es obligatorio"
            isValid = false
        } else {
            binding.inputLayoutLugar.error = null
        }

        if (cupo.isEmpty()) {
            binding.inputLayoutCupo.error = "El cupo es obligatorio"
            isValid = false
        } else {
            binding.inputLayoutCupo.error = null
        }

        if (edadMinima.isEmpty()) {
            binding.inputLayoutEdadMinima.error = "La edad mínima es obligatoria"
            isValid = false
        } else {
            binding.inputLayoutEdadMinima.error = null
        }

        // Si todos los campos son válidos
        if (isValid) {
            // TODO: Actualizar carrera en base de datos/API
            Toast.makeText(
                requireContext(),
                "Cambios guardados exitosamente",
                Toast.LENGTH_SHORT
            ).show()

            // Volver a la pantalla anterior
            findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
