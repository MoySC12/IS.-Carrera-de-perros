package com.example.doggierace.models

import java.util.Date

data class CategoriaEnVivo(
    val id: String,
    val nombre: String,
    val horaSalida: Date,
    val estado: String // "PENDIENTE", "EN_CURSO", "FINALIZADA"
)
