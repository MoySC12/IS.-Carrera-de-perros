package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.adapters.CategoriaEnVivoAdapter
import com.example.doggierace.databinding.FragmentEventoEnVivoBinding
import com.example.doggierace.models.CategoriaEnVivo
import java.text.SimpleDateFormat
import java.util.Locale
import com.example.doggierace.R

class EventoEnVivoFragment : Fragment() {

    private var _binding: FragmentEventoEnVivoBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEventoEnVivoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        // Nombre de la carrera activa hoy
        binding.tvNombreCarreraHoy.text = "Carrera del Bosque"

        // Datos de prueba (Mock Data)
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val listaMock = listOf(
            CategoriaEnVivo("cat2", "Razas Grandes", sdf.parse("10:00")!!, "PENDIENTE"),
            CategoriaEnVivo("cat1", "Razas Pequeñas", sdf.parse("09:00")!!, "EN_CURSO"),
            CategoriaEnVivo("cat4", "Veteranos", sdf.parse("08:00")!!, "FINALIZADA"),
            CategoriaEnVivo("cat3", "Cachorros", sdf.parse("11:00")!!, "PENDIENTE")
        )

        // Filtrar y ordenar la lista
        val listaFiltradaYOrdenada = listaMock
            .filter { it.estado != "FINALIZADA" }
            .sortedWith(
                compareBy(
                    { it.estado != "EN_CURSO" }, // Pone "EN_CURSO" (false) primero
                    { it.horaSalida } // Luego ordena por hora
                )
            )

        // Configurar RecyclerView
        val adapter = CategoriaEnVivoAdapter(listaFiltradaYOrdenada) { categoria ->
            // Navegar a Control de Categoría
            val sdfDisplay = SimpleDateFormat("hh:mm a", Locale.getDefault())
            val horaFormateada = sdfDisplay.format(categoria.horaSalida)

            val bundle = Bundle().apply {
                putString("categoriaId", categoria.id)
                putString("categoriaNombre", categoria.nombre)
                putString("carreraNombre", "Carrera del Bosque")
                putString("horaSalida", horaFormateada)
            }

            navController.navigate(
                R.id.action_eventoEnVivo_to_controlCategoria,
                bundle
            )
        }


        binding.rvCategoriasEnVivo.layoutManager = LinearLayoutManager(requireContext())
        binding.rvCategoriasEnVivo.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}