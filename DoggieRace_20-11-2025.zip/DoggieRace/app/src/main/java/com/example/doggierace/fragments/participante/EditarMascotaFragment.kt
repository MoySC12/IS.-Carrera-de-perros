package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.databinding.FragmentEditarMascotaBinding
import com.example.doggierace.models.Mascota

class EditarMascotaFragment : Fragment() {

    private var _binding: FragmentEditarMascotaBinding? = null
    private val binding get() = _binding!!

    private var mascotaId: String? = null  // ✅ Variable simple para el ID

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditarMascotaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ✅ Recibir argumentos usando Bundle tradicional
        mascotaId = arguments?.getString("mascotaId")

        setupToolbar()
        cargarDatosMascota()
        setupClickListeners()
    }

    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun cargarDatosMascota() {
        // TODO: Cargar datos reales desde ViewModel o base de datos
        // Por ahora, datos de prueba
        val mascota = obtenerMascotaPorId(mascotaId ?: "id1")

        // Simulamos peso y altura (en producción vendrían del modelo)
        binding.etNombreMascota.setText(mascota.nombre)
        binding.etRaza.setText(mascota.raza)
        binding.etEdad.setText(mascota.edad.toString())
        binding.etPeso.setText("28.5")
        binding.etAltura.setText("58")
        binding.etDiscapacidad.setText("Ninguna")
    }

    private fun obtenerMascotaPorId(id: String): Mascota {
        // Datos de prueba (mock data)
        val mascotas = listOf(
            Mascota(
                id = "id1",
                nombre = "Fido",
                edad = 3,
                raza = "Golden Retriever"
            ),
            Mascota(
                id = "id2",
                nombre = "Luna",
                edad = 1,
                raza = "Border Collie"
            )
        )

        return mascotas.find { it.id == id } ?: mascotas.first()
    }

    private fun setupClickListeners() {
        // Botón: Cambiar Foto del Perro
        binding.btnCambiarFotoPerro.setOnClickListener {
            Toast.makeText(
                requireContext(),
                "Función 'Cambiar Foto' en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
            // TODO: Implementar selección de foto
        }

        // Botón: Ver/Cambiar Cartilla
        binding.btnVerCartilla.setOnClickListener {
            Toast.makeText(
                requireContext(),
                "Función 'Ver/Cambiar Cartilla' en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
            // TODO: Implementar visualización/cambio de cartilla
        }

        // Botón: Guardar Cambios
        binding.btnGuardarCambios.setOnClickListener {
            guardarCambios()
        }

        // Botón: Eliminar Mascota
        binding.btnEliminarMascota.setOnClickListener {
            mostrarDialogoEliminar()
        }
    }

    private fun guardarCambios() {
        val nombre = binding.etNombreMascota.text.toString().trim()
        val raza = binding.etRaza.text.toString().trim()
        val edad = binding.etEdad.text.toString().trim()
        val peso = binding.etPeso.text.toString().trim()
        val altura = binding.etAltura.text.toString().trim()

        // Validar campos obligatorios
        if (nombre.isEmpty()) {
            binding.inputLayoutNombreMascota.error = "El nombre es obligatorio"
            return
        }

        if (raza.isEmpty()) {
            binding.inputLayoutRaza.error = "La raza es obligatoria"
            return
        }

        if (edad.isEmpty()) {
            binding.inputLayoutEdad.error = "La edad es obligatoria"
            return
        }

        if (peso.isEmpty()) {
            binding.inputLayoutPeso.error = "El peso es obligatorio"
            return
        }

        if (altura.isEmpty()) {
            binding.inputLayoutAltura.error = "La altura es obligatoria"
            return
        }

        // Limpiar errores
        binding.inputLayoutNombreMascota.error = null
        binding.inputLayoutRaza.error = null
        binding.inputLayoutEdad.error = null
        binding.inputLayoutPeso.error = null
        binding.inputLayoutAltura.error = null

        // TODO: Guardar cambios en base de datos/API
        Toast.makeText(
            requireContext(),
            "Cambios guardados exitosamente",
            Toast.LENGTH_SHORT
        ).show()

        // Volver a la pantalla anterior
        findNavController().popBackStack()
    }

    private fun mostrarDialogoEliminar() {
        AlertDialog.Builder(requireContext())
            .setTitle("Eliminar Mascota")
            .setMessage("¿Estás seguro de que deseas eliminar a ${binding.etNombreMascota.text}? Esta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { dialog, _ ->
                eliminarMascota()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun eliminarMascota() {
        // TODO: Eliminar mascota de base de datos/API
        Toast.makeText(
            requireContext(),
            "Mascota eliminada",
            Toast.LENGTH_SHORT
        ).show()

        // Volver a la pantalla anterior
        findNavController().popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
