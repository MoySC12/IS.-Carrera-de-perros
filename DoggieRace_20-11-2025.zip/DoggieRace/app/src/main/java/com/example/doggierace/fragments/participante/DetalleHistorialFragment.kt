package com.example.doggierace.fragments.participante


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController  // ✅ AGREGAR
import androidx.navigation.ui.setupWithNavController   // ✅ AGREGAR
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.adapters.ResultadosPerrosAdapter
import com.example.doggierace.databinding.FragmentDetalleHistorialBinding
import com.example.doggierace.models.ResultadoPerro


class DetalleHistorialFragment : Fragment() {

    private var _binding: FragmentDetalleHistorialBinding? = null
    private val binding get() = _binding!!

    private lateinit var resultadosAdapter: ResultadosPerrosAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetalleHistorialBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupResultados()
        setupComentario()
    }


    // ✅ Agregar este método
    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }
    private fun setupResultados() {
        // Datos de prueba (mock data)
        val resultados = listOf(
            ResultadoPerro(
                nombre = "Fido",
                tiempo = "15:32 min",
                lugar = "#8 (Cat. Pequeña)"
            ),
            ResultadoPerro(
                nombre = "Luna",
                tiempo = "16:01 min",
                lugar = "#10 (Cat. Pequeña)"
            )
        )

        // Configurar adaptador
        resultadosAdapter = ResultadosPerrosAdapter(resultados)

        // Configurar RecyclerView
        binding.rvResultadosPerros.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = resultadosAdapter
        }
    }

    private fun setupComentario() {
        binding.btnEnviarComentario.setOnClickListener {
            val comentario = binding.etComentario.text.toString().trim()

            if (comentario.isNotEmpty()) {
                // Lógica para enviar el comentario (por ahora un Toast)
                Toast.makeText(
                    requireContext(),
                    "Comentario enviado: $comentario",
                    Toast.LENGTH_SHORT
                ).show()

                // Opcional: Limpiar el campo y deshabilitar el botón
                binding.etComentario.text?.clear()
                binding.btnEnviarComentario.isEnabled = false
            } else {
                Toast.makeText(
                    requireContext(),
                    "El comentario está vacío",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // ✅ Agregar este método


}
