package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentEditarPerfilOrganizadorBinding

class EditarPerfilOrganizadorFragment : Fragment() {

    private var _binding: FragmentEditarPerfilOrganizadorBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditarPerfilOrganizadorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        // Configurar Toolbar
        binding.toolbar.setupWithNavController(navController)

        // Cargar datos actuales
        cargarDatosActuales()

        // Configurar listeners
        setupClickListeners()
    }

    private fun cargarDatosActuales() {
        // TODO: Cargar desde base de datos o SharedPreferences
        // Por ahora, datos simulados
        binding.etNombre.setText("Juan")
        binding.etApellidos.setText("Pérez García")
        binding.etCorreo.setText("juan.perez@ejemplo.com")
    }

    private fun setupClickListeners() {
        // Botón: Editar Foto
        binding.btnEditarFoto.setOnClickListener {
            // TODO: Abrir selector de imagen (galería/cámara)
            Toast.makeText(
                requireContext(),
                "Funcionalidad de editar foto pendiente",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Botón: Guardar Cambios
        binding.btnGuardarCambios.setOnClickListener {
            guardarCambios()
        }
    }

    private fun guardarCambios() {
        // Obtener datos de los campos
        val nombre = binding.etNombre.text.toString().trim()
        val apellidos = binding.etApellidos.text.toString().trim()
        val correo = binding.etCorreo.text.toString().trim()

        val passActual = binding.etPassActual.text.toString()
        val passNueva = binding.etPassNueva.text.toString()
        val passConfirmar = binding.etPassConfirmar.text.toString()

        // Validación básica de campos obligatorios
        if (nombre.isEmpty()) {
            binding.inputLayoutNombre.error = "El nombre es obligatorio"
            return
        }

        if (apellidos.isEmpty()) {
            binding.inputLayoutApellidos.error = "Los apellidos son obligatorios"
            return
        }

        if (correo.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
            binding.inputLayoutCorreo.error = "Ingresa un correo válido"
            return
        }

        // Validación de contraseña (solo si se intenta cambiar)
        if (passNueva.isNotEmpty() || passConfirmar.isNotEmpty()) {
            if (passActual.isEmpty()) {
                binding.inputLayoutPassActual.error = "Ingresa tu contraseña actual"
                return
            }

            if (passNueva.isEmpty()) {
                binding.inputLayoutPassNueva.error = "Ingresa la nueva contraseña"
                return
            }

            if (passNueva != passConfirmar) {
                binding.inputLayoutPassConfirmar.error = "Las contraseñas no coinciden"
                return
            }

            if (passNueva.length < 6) {
                binding.inputLayoutPassNueva.error = "La contraseña debe tener al menos 6 caracteres"
                return
            }
        }

        // Limpiar errores
        binding.inputLayoutNombre.error = null
        binding.inputLayoutApellidos.error = null
        binding.inputLayoutCorreo.error = null
        binding.inputLayoutPassActual.error = null
        binding.inputLayoutPassNueva.error = null
        binding.inputLayoutPassConfirmar.error = null

        // TODO: Guardar en base de datos o enviar al servidor
        // Por ahora, solo mostramos un Toast

        Toast.makeText(
            requireContext(),
            "Cambios guardados",
            Toast.LENGTH_SHORT
        ).show()

        // Volver a la pantalla anterior
        findNavController().popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
