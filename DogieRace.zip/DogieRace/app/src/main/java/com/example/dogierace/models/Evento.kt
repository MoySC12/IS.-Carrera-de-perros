package com.example.dogierace.models

data class Evento(
    val id: String,
    val nombre: String,
    val fecha: String,
    val lugar: String
)
