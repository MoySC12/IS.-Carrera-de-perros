package com.example.dogierace.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dogierace.R
import com.example.dogierace.adapters.EventoAdapter
import com.example.dogierace.databinding.FragmentTodasCarrerasBinding
import com.example.dogierace.models.Evento

class TodasCarrerasFragment : Fragment() {

    private var _binding: FragmentTodasCarrerasBinding? = null
    private val binding get() = _binding!!

    private lateinit var eventoAdapter: EventoAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTodasCarrerasBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        // Configurar Toolbar con Navigation
        binding.toolbar.setupWithNavController(navController)

        // Configurar RecyclerView
        configurarRecyclerView()
    }

    private fun configurarRecyclerView() {
        // Datos de ejemplo
        val todasCarreras = listOf(
            Evento("1", "Carrera del Bosque", "15 de Noviembre", "Parque Sierra Morelos"),
            Evento("2", "Carrera de Pista", "22 de Noviembre", "Deportivo Agripín García"),
            Evento("3", "Canicross Navideño", "19 de Diciembre", "Paseo Colón")
        )

        eventoAdapter = EventoAdapter(todasCarreras) { evento ->
            // Click en un evento
            findNavController().navigate(R.id.accion_todas_carreras_a_detalle)
        }

        binding.rvTodasMisCarreras.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = eventoAdapter
            setHasFixedSize(true)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
