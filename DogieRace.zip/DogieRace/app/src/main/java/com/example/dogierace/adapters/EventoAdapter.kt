package com.example.dogierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.dogierace.databinding.ItemEventoBinding
import com.example.dogierace.models.Evento

class EventoAdapter(
    private val eventos: List<Evento>,
    private val onEventoClick: (Evento) -> Unit
) : RecyclerView.Adapter<EventoAdapter.EventoViewHolder>() {

    inner class EventoViewHolder(private val binding: ItemEventoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(evento: Evento) {
            binding.tvNombreEvento.text = evento.nombre
            binding.tvFechaEvento.text = "📅 ${evento.fecha}"
            binding.tvLugarEvento.text = "📍 ${evento.lugar}"

            binding.root.setOnClickListener {
                onEventoClick(evento)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventoViewHolder {
        val binding = ItemEventoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EventoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EventoViewHolder, position: Int) {
        holder.bind(eventos[position])
    }

    override fun getItemCount(): Int = eventos.size
}
