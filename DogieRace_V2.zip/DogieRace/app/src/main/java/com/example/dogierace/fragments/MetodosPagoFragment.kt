package com.example.dogierace.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dogierace.R
import com.example.dogierace.adapters.MetodosPagoAdapter
import com.example.dogierace.databinding.FragmentMetodosPagoBinding
import com.example.dogierace.models.MetodoPago

class MetodosPagoFragment : Fragment() {

    private var _binding: FragmentMetodosPagoBinding? = null
    private val binding get() = _binding!!

    private lateinit var metodosPagoAdapter: MetodosPagoAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMetodosPagoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
    }

    // ✅ Agregar este método
    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }
    private fun setupRecyclerView() {
        // Datos de prueba (mock data)
        val tarjetas = listOf(
            MetodoPago(
                id = "id1",
                ultimosCuatro = "1234",
                vencimiento = "12/26",
                tipoIcono = R.drawable.ic_credit_card
            ),
            MetodoPago(
                id = "id2",
                ultimosCuatro = "5678",
                vencimiento = "08/25",
                tipoIcono = R.drawable.ic_credit_card
            )
        )

        // Configurar adaptador con listener de eliminar
        metodosPagoAdapter = MetodosPagoAdapter(tarjetas) { metodoPagoId ->
            mostrarDialogoEliminar(metodoPagoId)
        }

        // Configurar RecyclerView
        binding.rvMetodosPago.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = metodosPagoAdapter
        }
    }

    private fun setupClickListeners() {
        // Botón: Agregar Método de Pago
        binding.btnAgregarMetodoPago.setOnClickListener {
            findNavController().navigate(R.id.action_metodosPago_to_agregarMetodoPago)
        }
    }

    private fun mostrarDialogoEliminar(metodoPagoId: String) {
        AlertDialog.Builder(requireContext())
            .setTitle("Eliminar Tarjeta")
            .setMessage("¿Estás seguro de que deseas eliminar este método de pago?")
            .setPositiveButton("Eliminar") { dialog, _ ->
                eliminarTarjeta(metodoPagoId)
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun eliminarTarjeta(metodoPagoId: String) {
        // TODO: Eliminar tarjeta de base de datos/API
        Toast.makeText(
            requireContext(),
            "Tarjeta eliminada",
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
