package com.example.dogierace.models

data class Mascota(
    val id: String,
    val nombre: String,
    val edad: Int,
    val raza: String,
    val peso: Double = 0.0,
    val altura: Int = 0,
    val discapacidad: String? = null,
    val fotoUrl: String? = null,
    val cartillaUrl: String? = null
)
