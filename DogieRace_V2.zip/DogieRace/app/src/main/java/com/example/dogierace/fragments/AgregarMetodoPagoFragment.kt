package com.example.dogierace.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.dogierace.databinding.FragmentAgregarMetodoPagoBinding

class AgregarMetodoPagoFragment : Fragment() {

    private var _binding: FragmentAgregarMetodoPagoBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAgregarMetodoPagoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupClickListeners()
    }

    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupClickListeners() {
        // Botón: Guardar Método
        binding.btnGuardarMetodo.setOnClickListener {
            guardarMetodo()
        }
    }

    private fun guardarMetodo() {
        val nombreTitular = binding.etNombreTitular.text.toString().trim()
        val numeroTarjeta = binding.etNumeroTarjeta.text.toString().trim()
        val vencimiento = binding.etVencimiento.text.toString().trim()
        val ccv = binding.etCcv.text.toString().trim()

        // Validar campos obligatorios
        var isValid = true

        if (nombreTitular.isEmpty()) {
            binding.inputLayoutNombreTitular.error = "El nombre del titular es obligatorio"
            isValid = false
        } else {
            binding.inputLayoutNombreTitular.error = null
        }

        if (numeroTarjeta.isEmpty()) {
            binding.inputLayoutNumeroTarjeta.error = "El número de tarjeta es obligatorio"
            isValid = false
        } else if (numeroTarjeta.length < 13 || numeroTarjeta.length > 16) {
            binding.inputLayoutNumeroTarjeta.error = "Número de tarjeta inválido (13-16 dígitos)"
            isValid = false
        } else {
            binding.inputLayoutNumeroTarjeta.error = null
        }

        if (vencimiento.isEmpty()) {
            binding.inputLayoutVencimiento.error = "El vencimiento es obligatorio"
            isValid = false
        } else if (!validarFormatoVencimiento(vencimiento)) {
            binding.inputLayoutVencimiento.error = "Formato inválido (MM/AA)"
            isValid = false
        } else {
            binding.inputLayoutVencimiento.error = null
        }

        if (ccv.isEmpty()) {
            binding.inputLayoutCcv.error = "El CCV es obligatorio"
            isValid = false
        } else if (ccv.length < 3 || ccv.length > 4) {
            binding.inputLayoutCcv.error = "CCV inválido (3-4 dígitos)"
            isValid = false
        } else {
            binding.inputLayoutCcv.error = null
        }

        // Si todos los campos son válidos
        if (isValid) {
            // TODO: Guardar método de pago en base de datos/API
            Toast.makeText(
                requireContext(),
                "Método de pago guardado exitosamente",
                Toast.LENGTH_SHORT
            ).show()

            // Volver a la pantalla anterior
            findNavController().popBackStack()
        }
    }

    private fun validarFormatoVencimiento(vencimiento: String): Boolean {
        // Validar formato MM/AA
        if (vencimiento.length != 5 || vencimiento[2] != '/') {
            return false
        }

        val partes = vencimiento.split("/")
        if (partes.size != 2) return false

        val mes = partes[0].toIntOrNull() ?: return false
        val anio = partes[1].toIntOrNull() ?: return false

        // Validar mes entre 01-12
        if (mes < 1 || mes > 12) return false

        // Validar año (entre 25-99 para simplificar)
        if (anio < 25) return false

        return true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
