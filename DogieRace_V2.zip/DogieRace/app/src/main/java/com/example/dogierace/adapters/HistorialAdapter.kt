package com.example.dogierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.dogierace.databinding.ItemHistorialCarreraBinding
import com.example.dogierace.models.HistorialCarrera

class HistorialAdapter(
    private val carreras: List<HistorialCarrera>,
    private val onItemClick: (HistorialCarrera) -> Unit
) : RecyclerView.Adapter<HistorialAdapter.HistorialViewHolder>() {

    inner class HistorialViewHolder(private val binding: ItemHistorialCarreraBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(carrera: HistorialCarrera) {
            binding.tvNombreCarrera.text = carrera.nombre
            binding.tvLugarCarrera.text = carrera.lugar
            binding.tvFechaCarrera.text = carrera.fecha

            binding.root.setOnClickListener {
                onItemClick(carrera)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistorialViewHolder {
        val binding = ItemHistorialCarreraBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return HistorialViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HistorialViewHolder, position: Int) {
        holder.bind(carreras[position])
    }

    override fun getItemCount(): Int = carreras.size
}
