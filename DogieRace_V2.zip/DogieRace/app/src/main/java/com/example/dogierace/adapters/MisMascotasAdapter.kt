package com.example.dogierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.dogierace.databinding.ItemMascotaBinding
import com.example.dogierace.models.Mascota

class MisMascotasAdapter(
    private val mascotas: List<Mascota>,
    private val onItemClick: (String) -> Unit
) : RecyclerView.Adapter<MisMascotasAdapter.MascotaViewHolder>() {

    inner class MascotaViewHolder(private val binding: ItemMascotaBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(mascota: Mascota) {
            binding.tvNombreMascota.text = "🐶 ${mascota.nombre}"
            binding.tvEdadMascota.text = "Edad: ${mascota.edad} año${if (mascota.edad != 1) "s" else ""}"
            binding.tvRazaMascota.text = "Raza: ${mascota.raza}"

            // Click listener
            binding.root.setOnClickListener {
                onItemClick(mascota.id)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MascotaViewHolder {
        val binding = ItemMascotaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MascotaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MascotaViewHolder, position: Int) {
        holder.bind(mascotas[position])
    }

    override fun getItemCount(): Int = mascotas.size
}
