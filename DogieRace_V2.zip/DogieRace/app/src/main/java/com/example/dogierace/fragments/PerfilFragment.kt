package com.example.dogierace.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.dogierace.R
import com.example.dogierace.databinding.FragmentPerfilBinding

class PerfilFragment : Fragment() {

    private var _binding: FragmentPerfilBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPerfilBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListeners()
    }

    private fun setupClickListeners() {
        // ✅ Botón: Editar Perfil
        binding.btnEditarPerfil.setOnClickListener {
            findNavController().navigate(R.id.action_perfil_to_editarPerfil)
        }

        // ✅ Botón: Agregar Mascota
        binding.btnAgregarMascota.setOnClickListener {
            findNavController().navigate(R.id.action_perfil_to_agregarMascota)
        }

        // ✅ Botón: Mis Mascotas
        binding.btnMisMascotas.setOnClickListener {
            findNavController().navigate(R.id.action_perfil_to_misMascotas)
        }

        // ✅ Botón: Métodos de Pago
        binding.btnMetodosPago.setOnClickListener {
            findNavController().navigate(R.id.action_perfil_to_metodosPago)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
