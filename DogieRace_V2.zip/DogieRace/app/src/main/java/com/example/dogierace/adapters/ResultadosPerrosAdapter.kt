package com.example.dogierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.dogierace.databinding.ItemResultadoPerroBinding
import com.example.dogierace.models.ResultadoPerro

class ResultadosPerrosAdapter(
    private val resultados: List<ResultadoPerro>
) : RecyclerView.Adapter<ResultadosPerrosAdapter.ResultadoViewHolder>() {

    inner class ResultadoViewHolder(private val binding: ItemResultadoPerroBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(resultado: ResultadoPerro) {
            binding.tvNombrePerro.text = "🐶 ${resultado.nombre}"
            binding.tvTiempoPerro.text = "Tiempo: ${resultado.tiempo}"
            binding.tvLugarPerro.text = "Lugar: ${resultado.lugar}"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultadoViewHolder {
        val binding = ItemResultadoPerroBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ResultadoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ResultadoViewHolder, position: Int) {
        holder.bind(resultados[position])
    }

    override fun getItemCount(): Int = resultados.size
}
