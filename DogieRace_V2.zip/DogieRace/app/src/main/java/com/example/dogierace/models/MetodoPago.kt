package com.example.dogierace.models

data class MetodoPago(
    val id: String,
    val ultimosCuatro: String,
    val vencimiento: String,
    val tipoIcono: Int // R.drawable.ic_credit_card
)
