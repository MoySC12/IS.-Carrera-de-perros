package com.example.dogierace.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dogierace.R
import com.example.dogierace.adapters.HistorialAdapter
import com.example.dogierace.databinding.FragmentHistorialBinding
import com.example.dogierace.models.HistorialCarrera

class HistorialFragment : Fragment() {

    private var _binding: FragmentHistorialBinding? = null
    private val binding get() = _binding!!

    private lateinit var historialAdapter: HistorialAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistorialBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        // Datos de prueba (mock data)
        val carreras = listOf(
            HistorialCarrera(
                nombre = "Carrera del Bosque",
                lugar = "Parque Sierra Morelos",
                fecha = "15 de Noviembre"
            ),
            HistorialCarrera(
                nombre = "Carrera \"El Nevado\"",
                lugar = "Faldas del Nevado",
                fecha = "01 de Octubre"
            ),
            HistorialCarrera(
                nombre = "Rally Canino",
                lugar = "Centro de Toluca",
                fecha = "20 de Septiembre"
            )
        )

        // Configurar adaptador con navegación
        historialAdapter = HistorialAdapter(carreras) { carrera ->
            // Navegar al detalle de la carrera
            findNavController().navigate(R.id.accion_historial_a_detalle)
        }

        // Configurar RecyclerView
        binding.rvHistorial.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = historialAdapter
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
