package com.example.dogierace.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dogierace.R
import com.example.dogierace.adapters.EventoAdapter
import com.example.dogierace.databinding.FragmentTodasCarrerasBinding
import com.example.dogierace.models.Evento

class TodasCarrerasFragment : Fragment() {

    private var _binding: FragmentTodasCarrerasBinding? = null
    private val binding get() = _binding!!

    private lateinit var eventosAdapter: EventoAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTodasCarrerasBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()  // ✅ Agregar esta línea
        setupRecyclerView()
    }

    // ✅ Agregar este método
    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupRecyclerView() {
        // ... tu código existente
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
