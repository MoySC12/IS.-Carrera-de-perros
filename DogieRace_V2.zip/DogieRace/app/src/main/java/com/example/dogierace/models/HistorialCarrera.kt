package com.example.dogierace.models

data class HistorialCarrera(
    val nombre: String,
    val lugar: String,
    val fecha: String
)
