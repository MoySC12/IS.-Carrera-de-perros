package com.example.dogierace.models

data class ResultadoPerro(
    val nombre: String,
    val tiempo: String,
    val lugar: String
)
