package com.example.dogierace.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.dogierace.databinding.FragmentAgregarMascotaBinding

class AgregarMascotaFragment : Fragment() {

    private var _binding: FragmentAgregarMascotaBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAgregarMascotaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupClickListeners()
    }

    // ✅ Agregar este método
    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupClickListeners() {
        // Botón: Agregar Foto del Perro
        binding.btnAgregarFotoPerro.setOnClickListener {
            Toast.makeText(
                requireContext(),
                "Función 'Agregar Foto' en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
            // TODO: Implementar selección de foto desde galería o cámara
        }

        // Botón: Subir Cartilla de Vacunación
        binding.btnSubirCartilla.setOnClickListener {
            Toast.makeText(
                requireContext(),
                "Función 'Subir Cartilla' en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
            // TODO: Implementar selección de archivo/foto de cartilla
        }

        // Botón: Guardar Mascota
        binding.btnGuardarMascota.setOnClickListener {
            guardarMascota()
        }
    }

    private fun guardarMascota() {
        val nombre = binding.etNombreMascota.text.toString().trim()
        val raza = binding.etRaza.text.toString().trim()
        val edad = binding.etEdad.text.toString().trim()
        val peso = binding.etPeso.text.toString().trim()
        val altura = binding.etAltura.text.toString().trim()
        val discapacidad = binding.etDiscapacidad.text.toString().trim()

        // Validar campos obligatorios
        if (nombre.isEmpty()) {
            binding.inputLayoutNombreMascota.error = "El nombre es obligatorio"
            return
        }

        if (raza.isEmpty()) {
            binding.inputLayoutRaza.error = "La raza es obligatoria"
            return
        }

        if (edad.isEmpty()) {
            binding.inputLayoutEdad.error = "La edad es obligatoria"
            return
        }

        if (peso.isEmpty()) {
            binding.inputLayoutPeso.error = "El peso es obligatorio"
            return
        }

        if (altura.isEmpty()) {
            binding.inputLayoutAltura.error = "La altura es obligatoria"
            return
        }

        // Limpiar errores
        binding.inputLayoutNombreMascota.error = null
        binding.inputLayoutRaza.error = null
        binding.inputLayoutEdad.error = null
        binding.inputLayoutPeso.error = null
        binding.inputLayoutAltura.error = null

        // TODO: Guardar mascota en base de datos/API
        Toast.makeText(
            requireContext(),
            "Mascota '$nombre' guardada exitosamente",
            Toast.LENGTH_SHORT
        ).show()

        // Volver a la pantalla anterior
        findNavController().popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
