package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.adapters.CarrerasFinalizadasAdapter
import com.example.doggierace.databinding.FragmentCarrerasFinalizadasBinding
import com.example.doggierace.models.CarreraFinalizada
import java.text.SimpleDateFormat
import java.util.*
import com.example.doggierace.R

class CarrerasFinalizadasFragment : Fragment() {

    private var _binding: FragmentCarrerasFinalizadasBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCarrerasFinalizadasBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupRecyclerView()
    }

    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupRecyclerView() {
        // Datos de prueba (Mock Data) - DESORDENADOS
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val listaDesordenada = listOf(
            CarreraFinalizada(
                id = "c3",
                nombre = "Carrera de Septiembre",
                fecha = sdf.parse("15/09/2025")!!,
                lugar = "Centro de Toluca"
            ),
            CarreraFinalizada(
                id = "c1",
                nombre = "Carrera 'El Nevado'",
                fecha = sdf.parse("01/11/2025")!!,
                lugar = "Faldas del Nevado"
            ),
            CarreraFinalizada(
                id = "c2",
                nombre = "Carrera de Octubre",
                fecha = sdf.parse("20/10/2025")!!,
                lugar = "Deportivo Agripín García"
            )
        )

        // Ordenar la lista por fecha (más RECIENTE primero)
        val listaOrdenada = listaDesordenada.sortedByDescending { it.fecha }

        // Configurar adaptador
        val adapter = CarrerasFinalizadasAdapter(listaOrdenada) { carrera ->
            // Click en un ítem - Navegar a Evaluaciones
            Toast.makeText(
                requireContext(),
                "Ver evaluaciones de: ${carrera.nombre}",
                Toast.LENGTH_SHORT
            ).show()

            // Navegar a pantalla de evaluaciones
            findNavController().navigate(R.id.action_carrerasFinalizadas_to_evaluaciones)
        }


        // Configurar RecyclerView
        binding.rvCarrerasFinalizadas.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
