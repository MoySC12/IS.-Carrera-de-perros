package com.example.doggierace.models

data class Usuario(
    val email: String,
    val password: String,
    val nombre: String,
    val tipoUsuario: String  // "PARTICIPANTE" o "ORGANIZADOR"
)
