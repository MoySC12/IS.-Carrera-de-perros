package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.databinding.ItemMetodoPagoBinding
import com.example.doggierace.models.MetodoPago

class MetodosPagoAdapter(
    private val tarjetas: List<MetodoPago>,
    private val onDeleteClick: (String) -> Unit
) : RecyclerView.Adapter<MetodosPagoAdapter.MetodoPagoViewHolder>() {

    inner class MetodoPagoViewHolder(private val binding: ItemMetodoPagoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(tarjeta: MetodoPago) {
            // Formatear número de tarjeta
            binding.tvCardNumber.text = "**** **** **** ${tarjeta.ultimosCuatro}"

            // Formatear fecha de vencimiento
            binding.tvCardExpiry.text = "Vence: ${tarjeta.vencimiento}"

            // Configurar icono
            binding.imgCardIcon.setImageResource(tarjeta.tipoIcono)

            // Click en eliminar
            binding.btnEliminarTarjeta.setOnClickListener {
                onDeleteClick(tarjeta.id)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MetodoPagoViewHolder {
        val binding = ItemMetodoPagoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MetodoPagoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MetodoPagoViewHolder, position: Int) {
        holder.bind(tarjetas[position])
    }

    override fun getItemCount(): Int = tarjetas.size
}
