package com.example.doggierace

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.example.doggierace.utils.AuthManager
import com.google.android.material.textfield.TextInputEditText

class InicioSesionActivity : AppCompatActivity() {

    private lateinit var btnVolver: TextView
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var tvOlvidoPassword: TextView
    private lateinit var btnIngresar: CardView
    private lateinit var authManager: AuthManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inicio_sesion)

        authManager = AuthManager(this)

        // Verificar si ya hay sesión activa
        if (authManager.tieneSesionActiva()) {
            val usuario = authManager.obtenerSesionActual()
            usuario?.let { redirigirSegunTipoUsuario(it.tipoUsuario) }
            finish()
            return
        }

        initializeViews()
        setupClickListeners()
    }

    private fun initializeViews() {
        btnVolver = findViewById(R.id.btnVolver)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        tvOlvidoPassword = findViewById(R.id.tvOlvidoPassword)
        btnIngresar = findViewById(R.id.btnIngresar)
    }

    private fun setupClickListeners() {
        btnVolver.setOnClickListener {
            finish()
        }

        tvOlvidoPassword.setOnClickListener {
            Toast.makeText(this, "Funcionalidad en desarrollo", Toast.LENGTH_SHORT).show()
        }

        btnIngresar.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (validateInputs(email, password)) {
                iniciarSesion(email, password)
            }
        }
    }

    private fun iniciarSesion(email: String, password: String) {
        val usuario = authManager.iniciarSesion(email, password)

        if (usuario != null) {
            // Guardar sesión
            authManager.guardarSesion(usuario)

            Toast.makeText(
                this,
                "Bienvenido, ${usuario.nombre}",
                Toast.LENGTH_SHORT
            ).show()

            // Redirigir según tipo de usuario
            redirigirSegunTipoUsuario(usuario.tipoUsuario)

            finish()
        } else {
            Toast.makeText(
                this,
                "Email o contraseña incorrectos",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun redirigirSegunTipoUsuario(tipoUsuario: String) {
        val intent = when (tipoUsuario) {
            "ORGANIZADOR" -> Intent(this, MainActivityOrganizador::class.java)
            "PARTICIPANTE" -> Intent(this, MainActivity::class.java)  // Cambia a tu MainActivity de participante
            else -> Intent(this, MainActivity::class.java)
        }
        startActivity(intent)
    }

    private fun validateInputs(email: String, password: String): Boolean {
        if (email.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa tu correo electrónico", Toast.LENGTH_SHORT).show()
            return false
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Por favor ingresa un correo válido", Toast.LENGTH_SHORT).show()
            return false
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa tu contraseña", Toast.LENGTH_SHORT).show()
            return false
        }

        if (password.length < 6) {
            Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }
}
