package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.databinding.ItemProximaCarreraBinding
import com.example.doggierace.models.ProximaCarrera
import java.text.SimpleDateFormat
import java.util.*

class ProximasCarrerasAdapter(
    private val carreras: List<ProximaCarrera>,
    private val onItemClick: (ProximaCarrera) -> Unit
) : RecyclerView.Adapter<ProximasCarrerasAdapter.ProximaCarreraViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProximaCarreraViewHolder {
        val binding = ItemProximaCarreraBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ProximaCarreraViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProximaCarreraViewHolder, position: Int) {
        holder.bind(carreras[position])
    }

    override fun getItemCount(): Int = carreras.size

    inner class ProximaCarreraViewHolder(
        private val binding: ItemProximaCarreraBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(carrera: ProximaCarrera) {
            // Nombre de la carrera
            binding.tvNombreCarrera.text = carrera.nombre

            // Inscritos
            binding.tvInscritos.text = "Inscritos: ${carrera.inscritos} / ${carrera.cupoMaximo}"

            // Fecha (formatear de Date a String)
            val formatoFecha = SimpleDateFormat("dd 'de' MMMM", Locale.forLanguageTag("es-ES"))

            binding.tvFechaCarrera.text = formatoFecha.format(carrera.fecha)

            // Lugar
            binding.tvLugarCarrera.text = carrera.lugar

            // Click listener
            binding.root.setOnClickListener {
                onItemClick(carrera)
            }
        }
    }
}
