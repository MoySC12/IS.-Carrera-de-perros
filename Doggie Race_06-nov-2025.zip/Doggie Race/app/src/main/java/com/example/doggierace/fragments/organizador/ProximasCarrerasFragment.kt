package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.R
import com.example.doggierace.adapters.ProximasCarrerasAdapter
import com.example.doggierace.databinding.FragmentProximasCarrerasBinding
import com.example.doggierace.models.ProximaCarrera
import java.text.SimpleDateFormat
import java.util.*

class ProximasCarrerasFragment : Fragment() {

    private var _binding: FragmentProximasCarrerasBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProximasCarrerasBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupRecyclerView()
    }

    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupRecyclerView() {
        // Datos de prueba (Mock Data) - DESORDENADOS
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val listaDesordenada = listOf(
            ProximaCarrera(
                id = "c2",
                nombre = "Carrera de Pista",
                inscritos = 12,
                cupoMaximo = 100,
                fecha = sdf.parse("22/11/2025")!!,
                lugar = "Deportivo Agripín García"
            ),
            ProximaCarrera(
                id = "c3",
                nombre = "Carrera Navideña",
                inscritos = 5,
                cupoMaximo = 75,
                fecha = sdf.parse("19/12/2025")!!,
                lugar = "Centro de Toluca"
            ),
            ProximaCarrera(
                id = "c1",
                nombre = "Carrera del Bosque",
                inscritos = 0,
                cupoMaximo = 50,
                fecha = sdf.parse("15/11/2025")!!,
                lugar = "Parque Sierra Morelos"
            )
        )

        // Ordenar la lista por fecha (más próxima primero)
        val listaOrdenada = listaDesordenada.sortedBy { it.fecha }

        // Configurar adaptador
        val adapter = ProximasCarrerasAdapter(listaOrdenada) { carrera ->
            // Click en un ítem - Navegar a Editar Carrera
            Toast.makeText(
                requireContext(),
                "Editando: ${carrera.nombre}",
                Toast.LENGTH_SHORT
            ).show()

            // Navegación simple (sin Safe Args por ahora)
            findNavController().navigate(R.id.action_proximasCarreras_to_editarCarrera)
        }

        // Configurar RecyclerView
        binding.rvProximasCarreras.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
