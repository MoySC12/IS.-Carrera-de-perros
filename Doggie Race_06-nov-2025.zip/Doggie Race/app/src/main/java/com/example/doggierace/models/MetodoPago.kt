package com.example.doggierace.models

data class MetodoPago(
    val id: String,
    val ultimosCuatro: String,
    val vencimiento: String,
    val tipoIcono: Int
)
