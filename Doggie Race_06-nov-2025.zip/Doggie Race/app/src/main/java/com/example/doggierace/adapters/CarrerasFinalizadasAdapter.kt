package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.databinding.ItemCarreraFinalizadaBinding
import com.example.doggierace.models.CarreraFinalizada
import java.text.SimpleDateFormat
import java.util.*

class CarrerasFinalizadasAdapter(
    private val carreras: List<CarreraFinalizada>,
    private val onItemClick: (CarreraFinalizada) -> Unit
) : RecyclerView.Adapter<CarrerasFinalizadasAdapter.CarreraFinalizadaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarreraFinalizadaViewHolder {
        val binding = ItemCarreraFinalizadaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CarreraFinalizadaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CarreraFinalizadaViewHolder, position: Int) {
        holder.bind(carreras[position])
    }

    override fun getItemCount(): Int = carreras.size

    inner class CarreraFinalizadaViewHolder(
        private val binding: ItemCarreraFinalizadaBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(carrera: CarreraFinalizada) {
            // Nombre de la carrera
            binding.tvNombreCarrera.text = carrera.nombre

            // Fecha (formatear de Date a String)
            val formatoFecha = SimpleDateFormat("dd 'de' MMMM", Locale.forLanguageTag("es-ES"))

            binding.tvFechaCarrera.text = formatoFecha.format(carrera.fecha)

            // Lugar
            binding.tvLugarCarrera.text = carrera.lugar

            // Click listener
            binding.root.setOnClickListener {
                onItemClick(carrera)
            }
        }
    }
}
