package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.doggierace.R
import com.example.doggierace.databinding.FragmentEventosOrganizadorBinding

class EventosOrganizadorFragment : Fragment() {

    private var _binding: FragmentEventosOrganizadorBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEventosOrganizadorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupClickListeners()
    }

    private fun setupClickListeners() {
        val navController = findNavController()

        // Botón: Crear Nueva Carrera
        binding.cardCrearCarrera.setOnClickListener {
            navController.navigate(R.id.action_eventosOrganizador_to_crearCarrera)
        }

        // Botón: Próximas Carreras
        binding.cardProximasCarreras.setOnClickListener {
            findNavController().navigate(R.id.action_eventosOrganizador_to_proximasCarreras)
        }

        // Botón: Carreras Finalizadas
        binding.cardCarrerasFinalizadas.setOnClickListener {
            findNavController().navigate(R.id.action_eventosOrganizador_to_carrerasFinalizadas)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
