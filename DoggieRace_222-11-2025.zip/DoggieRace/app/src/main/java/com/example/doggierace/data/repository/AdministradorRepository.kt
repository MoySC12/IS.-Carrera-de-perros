package com.example.doggierace.data.repository

import androidx.lifecycle.LiveData
import com.example.doggierace.data.dao.AdministradorDao
import com.example.doggierace.data.entities.AdministradorEntity

class AdministradorRepository(private val administradorDao: AdministradorDao) {

    // LiveData - se actualiza automáticamente
    val todosAdministradores: LiveData<List<AdministradorEntity>> =
        administradorDao.obtenerTodosAdministradores()

    val administradoresActivos: LiveData<List<AdministradorEntity>> =
        administradorDao.obtenerAdministradoresActivos()

    // ========== OPERACIONES CRUD ==========

    suspend fun insertarAdministrador(administrador: AdministradorEntity): Long {
        return administradorDao.insertarAdministrador(administrador)
    }

    suspend fun actualizarAdministrador(administrador: AdministradorEntity): Int {
        return administradorDao.actualizarAdministrador(administrador)
    }

    suspend fun actualizarPerfil(
        id: Long,
        nombre: String,
        telefono: String?,
        organizacion: String?,
        descripcion: String?
    ): Int {
        return administradorDao.actualizarPerfil(id, nombre, telefono, organizacion, descripcion)
    }

    suspend fun actualizarFotoPerfil(id: Long, uri: String?): Int {
        return administradorDao.actualizarFotoPerfil(id, uri)
    }

    suspend fun actualizarPassword(id: Long, nuevaPassword: String): Int {
        return administradorDao.actualizarPassword(id, nuevaPassword)
    }

    suspend fun eliminarAdministrador(id: Long): Int {
        return administradorDao.eliminarAdministradorPorId(id)
    }

    // ========== CONSULTAS ==========

    suspend fun obtenerAdministradorPorId(id: Long): AdministradorEntity? {
        return administradorDao.obtenerAdministradorPorId(id)
    }

    fun obtenerAdministradorPorIdLiveData(id: Long): LiveData<AdministradorEntity?> {
        return administradorDao.obtenerAdministradorPorIdLiveData(id)
    }

    suspend fun obtenerAdministradorPorEmail(email: String): AdministradorEntity? {
        return administradorDao.obtenerAdministradorPorEmail(email)
    }

    suspend fun login(email: String, password: String): AdministradorEntity? {
        return administradorDao.login(email, password)
    }

    suspend fun verificarEmailExistente(email: String): Boolean {
        return administradorDao.verificarEmailExistente(email) > 0
    }

    suspend fun contarAdministradores(): Int {
        return administradorDao.contarAdministradores()
    }
}
