package com.example.doggierace.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.doggierace.databinding.ItemMascotaBinding
import com.example.doggierace.data.entities.MascotaEntity

class MisMascotasAdapter(
    private val onItemClick: (MascotaEntity) -> Unit = {},
    private val onEditClick: ((MascotaEntity) -> Unit)? = null,
    private val onDeleteClick: ((MascotaEntity) -> Unit)? = null,
    private val onInscribirClick: ((MascotaEntity) -> Unit)? = null,
    private val modoInscripcion: Boolean = false
) : ListAdapter<MascotaEntity, MisMascotasAdapter.MascotaViewHolder>(MascotaDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MascotaViewHolder {
        val binding = ItemMascotaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MascotaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MascotaViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class MascotaViewHolder(
        private val binding: ItemMascotaBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(mascota: MascotaEntity) {
            binding.apply {
                // Nombre
                tvNombreMascota.text = mascota.nombre

                // Raza
                tvRazaMascota.text = mascota.raza

                // Edad y peso (combinados)
                val detalles = "${mascota.edad} años • ${mascota.peso} kg"
                tvEdadPeso.text = detalles

                // Categoría según peso
                val categoria = when {
                    mascota.peso <= 15 -> "Pequeña"
                    mascota.peso <= 30 -> "Mediana"
                    mascota.peso <= 45 -> "Grande"
                    else -> "XL"
                }
                tvCategoriaMascota.text = categoria

                // Modo inscripción
                if (modoInscripcion && onInscribirClick != null) {
                    // Mostrar solo botón "Inscribir"
                    btnInscribir.visibility = View.VISIBLE
                    btnEditar.visibility = View.GONE
                    btnEliminar.visibility = View.GONE

                    btnInscribir.setOnClickListener {
                        onInscribirClick.invoke(mascota)
                    }
                } else {
                    // Mostrar botones normales (Editar/Eliminar)
                    btnInscribir.visibility = View.GONE
                    btnEditar.visibility = if (onEditClick != null) View.VISIBLE else View.GONE
                    btnEliminar.visibility = if (onDeleteClick != null) View.VISIBLE else View.GONE

                    btnEditar.setOnClickListener {
                        onEditClick?.invoke(mascota)
                    }

                    btnEliminar.setOnClickListener {
                        onDeleteClick?.invoke(mascota)
                    }
                }

                // Click en la card completa
                root.setOnClickListener {
                    onItemClick(mascota)
                }
            }
        }

    }

    class MascotaDiffCallback : DiffUtil.ItemCallback<MascotaEntity>() {
        override fun areItemsTheSame(oldItem: MascotaEntity, newItem: MascotaEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: MascotaEntity, newItem: MascotaEntity): Boolean {
            return oldItem == newItem
        }
    }
}
