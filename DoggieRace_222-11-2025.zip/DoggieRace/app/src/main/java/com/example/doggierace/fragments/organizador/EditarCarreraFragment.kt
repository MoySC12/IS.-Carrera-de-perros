package com.example.doggierace.fragments.organizador


import android.app.DatePickerDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.databinding.FragmentEditarCarreraBinding
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.utils.ImageHelper
import com.example.doggierace.viewmodels.CarreraViewModel
import java.text.SimpleDateFormat
import java.util.*
import com.example.doggierace.R


class EditarCarreraFragment : Fragment() {

    private var _binding: FragmentEditarCarreraBinding? = null
    private val binding get() = _binding!!

    private val carreraViewModel: CarreraViewModel by viewModels()
    private val args: EditarCarreraFragmentArgs by navArgs()

    private var carreraActual: CarreraEntity? = null
    private var imagenCircuitoUri: Uri? = null
    private var fechaSeleccionadaTimestamp: Long = 0

    private val seleccionarImagenLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            imagenCircuitoUri = it
            binding.imgCircuitoActual.setImageURI(it)
            binding.imgCircuitoActual.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditarCarreraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupDropdownCategoria()
        setupClickListeners()
        cargarDatosCarrera()
        observarResultados()
    }

    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupDropdownCategoria() {
        val categorias = resources.getStringArray(R.array.tipos_carrera)
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            categorias
        )
        binding.autocompleteTipoCarrera.setAdapter(adapter)
    }



    private fun setupClickListeners() {
        binding.btnCambiarImagen.setOnClickListener {
            seleccionarImagenLauncher.launch("image/*")
        }

        binding.etFecha.setOnClickListener {
            mostrarDatePicker()
        }

        binding.btnGuardarCambios.setOnClickListener {
            guardarCambios()
        }
    }

    private fun cargarDatosCarrera() {
        val carreraId = args.carreraId

        carreraViewModel.cargarCarreraPorId(carreraId)

        carreraViewModel.carreraActual.observe(viewLifecycleOwner) { carrera ->
            if (carrera != null) {
                carreraActual = carrera
                rellenarCampos(carrera)
            } else {
                Toast.makeText(requireContext(), "Error al cargar la carrera", Toast.LENGTH_LONG).show()
                findNavController().popBackStack()
            }
        }
    }

    private fun rellenarCampos(carrera: CarreraEntity) {
        binding.etNombre.setText(carrera.nombre)
        binding.autocompleteTipoCarrera.setText(carrera.categoria, false)

        // Formatear fecha
        val formatoFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        binding.etFecha.setText(formatoFecha.format(Date(carrera.fecha)))
        fechaSeleccionadaTimestamp = carrera.fecha

        binding.etLugar.setText(carrera.ubicacion)
        binding.etCupo.setText(carrera.cuposTotales.toString())

        // Extraer edad mínima de requisitos (si existe)
        val edadMinima = extraerEdadMinima(carrera.requisitos)
        binding.etEdadMinima.setText(edadMinima)

        binding.etProhibiciones.setText(carrera.descripcion)

        // Cargar imagen desde el path guardado
        carrera.imagenUri?.let { path ->
            val bitmap = ImageHelper.cargarImagenDesdePath(path)
            if (bitmap != null) {
                binding.imgCircuitoActual.setImageBitmap(bitmap)
                binding.imgCircuitoActual.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            } else {
                // Mostrar placeholder si no se puede cargar
                binding.imgCircuitoActual.setImageResource(android.R.drawable.ic_menu_gallery)
                binding.imgCircuitoActual.scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            }
        } ?: run {
            // No hay imagen guardada
            binding.imgCircuitoActual.setImageResource(android.R.drawable.ic_menu_gallery)
            binding.imgCircuitoActual.scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
        }
    }



    private fun extraerEdadMinima(requisitos: String?): String {
        // Extraer número de requisitos (ejemplo: "Edad mínima: 2 años" -> "2")
        return requisitos?.let {
            val regex = "\\d+".toRegex()
            regex.find(it)?.value ?: "0"
        } ?: "0"
    }

    private fun mostrarDatePicker() {
        val calendario = Calendar.getInstance()
        if (fechaSeleccionadaTimestamp > 0) {
            calendario.timeInMillis = fechaSeleccionadaTimestamp
        }

        val anio = calendario.get(Calendar.YEAR)
        val mes = calendario.get(Calendar.MONTH)
        val dia = calendario.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                val fechaSeleccionada = Calendar.getInstance()
                fechaSeleccionada.set(year, month, dayOfMonth)

                fechaSeleccionadaTimestamp = fechaSeleccionada.timeInMillis

                val formatoFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                binding.etFecha.setText(formatoFecha.format(fechaSeleccionada.time))
            },
            anio,
            mes,
            dia
        )

        datePickerDialog.datePicker.minDate = System.currentTimeMillis()
        datePickerDialog.show()
    }

    private fun guardarCambios() {
        limpiarErrores()

        val nombre = binding.etNombre.text.toString().trim()
        val categoria = binding.autocompleteTipoCarrera.text.toString().trim()
        val fecha = binding.etFecha.text.toString().trim()
        val ubicacion = binding.etLugar.text.toString().trim()
        val cupoStr = binding.etCupo.text.toString().trim()
        val edadMinimaStr = binding.etEdadMinima.text.toString().trim()
        val prohibiciones = binding.etProhibiciones.text.toString().trim()

        if (!validarCampos(nombre, categoria, fecha, ubicacion, cupoStr, edadMinimaStr)) {
            return
        }

        val cupo = cupoStr.toIntOrNull() ?: 0

        // Si se seleccionó una nueva imagen, guardarla
        var imagenPath = carreraActual?.imagenUri
        imagenCircuitoUri?.let { uri ->
            // Eliminar imagen anterior si existe
            carreraActual?.imagenUri?.let { pathAnterior ->
                ImageHelper.eliminarImagen(pathAnterior)
            }

            // Guardar nueva imagen
            val nombreArchivo = "carrera_${carreraActual?.id ?: System.currentTimeMillis()}"
            imagenPath = ImageHelper.guardarImagenEnAlmacenamiento(requireContext(), uri, nombreArchivo)
        }

        // Actualizar carrera
        val carreraActualizada = carreraActual?.copy(
            nombre = nombre,
            descripcion = prohibiciones.ifEmpty { "Sin descripción" },
            fecha = fechaSeleccionadaTimestamp,
            ubicacion = ubicacion,
            direccion = ubicacion,
            categoria = categoria,
            cuposTotales = cupo,
            cuposDisponibles = cupo - carreraActual!!.totalInscritos,
            imagenUri = imagenPath,
            requisitos = "Edad mínima: $edadMinimaStr años"
        )

        if (carreraActualizada != null) {
            carreraViewModel.actualizarCarrera(carreraActualizada)
        }
    }


    private fun validarCampos(
        nombre: String,
        categoria: String,
        fecha: String,
        ubicacion: String,
        cupo: String,
        edadMinima: String
    ): Boolean {

        if (nombre.isEmpty()) {
            binding.inputLayoutNombre.error = "El nombre es obligatorio"
            binding.etNombre.requestFocus()
            return false
        }

        if (categoria.isEmpty()) {
            binding.inputLayoutTipoCarrera.error = "Selecciona una categoría"
            binding.autocompleteTipoCarrera.requestFocus()
            return false
        }

        if (fecha.isEmpty()) {
            binding.inputLayoutFecha.error = "La fecha es obligatoria"
            binding.etFecha.requestFocus()
            return false
        }

        if (ubicacion.isEmpty()) {
            binding.inputLayoutLugar.error = "El lugar es obligatorio"
            binding.etLugar.requestFocus()
            return false
        }

        if (cupo.isEmpty()) {
            binding.inputLayoutCupo.error = "El cupo es obligatorio"
            binding.etCupo.requestFocus()
            return false
        }

        val cupoNum = cupo.toIntOrNull()
        if (cupoNum == null || cupoNum <= 0) {
            binding.inputLayoutCupo.error = "Cupo inválido"
            binding.etCupo.requestFocus()
            return false
        }

        if (edadMinima.isEmpty()) {
            binding.inputLayoutEdadMinima.error = "La edad mínima es obligatoria"
            binding.etEdadMinima.requestFocus()
            return false
        }

        val edadNum = edadMinima.toIntOrNull()
        if (edadNum == null || edadNum < 0 || edadNum > 20) {
            binding.inputLayoutEdadMinima.error = "Edad inválida (0-20 años)"
            binding.etEdadMinima.requestFocus()
            return false
        }

        return true
    }

    private fun limpiarErrores() {
        binding.inputLayoutNombre.error = null
        binding.inputLayoutTipoCarrera.error = null
        binding.inputLayoutFecha.error = null
        binding.inputLayoutLugar.error = null
        binding.inputLayoutCupo.error = null
        binding.inputLayoutEdadMinima.error = null
    }

    private fun observarResultados() {
        carreraViewModel.resultadoOperacion.observe(viewLifecycleOwner) { resultado ->
            when (resultado) {
                is CarreraViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(requireContext(), "Cambios guardados", Toast.LENGTH_SHORT).show()
                    findNavController().popBackStack()
                }
                is CarreraViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(requireContext(), resultado.mensaje, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
