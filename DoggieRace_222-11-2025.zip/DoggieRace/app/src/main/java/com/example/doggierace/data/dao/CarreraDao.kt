package com.example.doggierace.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.data.entities.InscripcionEntity

@Dao
interface CarreraDao {

    // ========== INSERTAR ==========
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarCarrera(carrera: CarreraEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarCarreras(carreras: List<CarreraEntity>): List<Long>

    // ========== ACTUALIZAR ==========
    @Update
    suspend fun actualizarCarrera(carrera: CarreraEntity): Int

    @Query("""
        UPDATE carreras 
        SET nombre = :nombre,
            descripcion = :descripcion,
            fecha = :fecha,
            hora_inicio = :horaInicio,
            ubicacion = :ubicacion,
            direccion = :direccion,
            ciudad = :ciudad,
            categoria = :categoria,
            precio_inscripcion = :precioInscripcion,
            cupos_totales = :cuposTotales
        WHERE id = :id
    """)
    suspend fun actualizarDatosCarrera(
        id: Long,
        nombre: String,
        descripcion: String,
        fecha: Long,
        horaInicio: String,
        ubicacion: String,
        direccion: String,
        ciudad: String,
        categoria: String,
        precioInscripcion: Double,
        cuposTotales: Int
    ): Int

    @Query("UPDATE carreras SET estado = :estado WHERE id = :id")
    suspend fun actualizarEstado(id: Long, estado: String): Int

    @Query("UPDATE carreras SET cupos_disponibles = cupos_disponibles - 1, total_inscritos = total_inscritos + 1 WHERE id = :id AND cupos_disponibles > 0")
    suspend fun decrementarCupoDisponible(id: Long): Int

    @Query("UPDATE carreras SET cupos_disponibles = cupos_disponibles + 1, total_inscritos = total_inscritos - 1 WHERE id = :id")
    suspend fun incrementarCupoDisponible(id: Long): Int

    @Query("UPDATE carreras SET imagen_uri = :uri WHERE id = :id")
    suspend fun actualizarImagenCarrera(id: Long, uri: String?): Int

    @Query("UPDATE carreras SET activa = :activa WHERE id = :id")
    suspend fun actualizarEstadoActiva(id: Long, activa: Boolean): Int

    // ========== ELIMINAR ==========
    @Delete
    suspend fun eliminarCarrera(carrera: CarreraEntity): Int

    @Query("DELETE FROM carreras WHERE id = :id")
    suspend fun eliminarCarreraPorId(id: Long): Int

    @Query("DELETE FROM carreras WHERE organizador_id = :organizadorId")
    suspend fun eliminarCarrerasDeOrganizador(organizadorId: Long): Int

    @Query("DELETE FROM carreras")
    suspend fun eliminarProximasCarrerasParticipante(): Int

    // ========== CONSULTAS ==========
    @Query("SELECT * FROM carreras WHERE id = :id")
    suspend fun obtenerCarreraPorId(id: Long): CarreraEntity?

    @Query("SELECT * FROM carreras WHERE id = :id")
    fun obtenerCarreraPorIdLiveData(id: Long): LiveData<CarreraEntity?>

    @Query("SELECT * FROM carreras WHERE organizador_id = :organizadorId ORDER BY fecha DESC")
    fun obtenerCarrerasDeOrganizador(organizadorId: Long): LiveData<List<CarreraEntity>>

    @Query("SELECT * FROM carreras WHERE organizador_id = :organizadorId ORDER BY fecha DESC")
    suspend fun obtenerCarrerasDeOrganizadorSuspend(organizadorId: Long): List<CarreraEntity>

    @Query("SELECT * FROM carreras WHERE estado = :estado AND activa = 1 ORDER BY fecha ASC")
    fun obtenerCarrerasPorEstado(estado: String): LiveData<List<CarreraEntity>>

    @Query("SELECT * FROM carreras WHERE estado = 'PROXIMA' AND activa = 1 AND fecha >= :fechaActual ORDER BY fecha ASC")
    fun obtenerProximasCarrerasOrganizador(fechaActual: Long): LiveData<List<CarreraEntity>>

    @Query("SELECT * FROM carreras WHERE estado = 'FINALIZADA' ORDER BY fecha DESC")
    fun obtenerCarrerasFinalizadas(): LiveData<List<CarreraEntity>>

    @Query("SELECT * FROM carreras WHERE categoria = :categoria AND estado = 'PROXIMA' AND activa = 1 ORDER BY fecha ASC")
    fun obtenerCarrerasPorCategoria(categoria: String): LiveData<List<CarreraEntity>>

    @Query("SELECT * FROM carreras WHERE ciudad = :ciudad AND estado = 'PROXIMA' AND activa = 1 ORDER BY fecha ASC")
    fun obtenerCarrerasPorCiudad(ciudad: String): LiveData<List<CarreraEntity>>

    @Query("SELECT * FROM carreras WHERE activa = 1 ORDER BY fecha DESC")
    fun obtenerProximasCarrerasParticipante(): LiveData<List<CarreraEntity>>

    @Query("SELECT * FROM carreras WHERE activa = 1 ORDER BY fecha DESC")
    suspend fun obtenerProximasCarrerasParticipanteSuspend(): List<CarreraEntity>

    @Query("SELECT * FROM carreras WHERE cupos_disponibles > 0 AND estado = 'PROXIMA' AND activa = 1 ORDER BY fecha ASC")
    fun obtenerCarrerasConCuposDisponibles(): LiveData<List<CarreraEntity>>

    @Query("SELECT COUNT(*) FROM carreras WHERE organizador_id = :organizadorId")
    suspend fun contarCarrerasDeOrganizador(organizadorId: Long): Int

    @Query("SELECT COUNT(*) FROM carreras WHERE organizador_id = :organizadorId AND estado = :estado")
    suspend fun contarCarrerasPorEstado(organizadorId: Long, estado: String): Int

    @Query("SELECT COUNT(*) FROM carreras")
    suspend fun contarProximasCarrerasParticipante(): Int

    @Query("""
        SELECT * FROM carreras 
        WHERE (nombre LIKE '%' || :busqueda || '%' 
           OR ubicacion LIKE '%' || :busqueda || '%'
           OR ciudad LIKE '%' || :busqueda || '%')
           AND activa = 1
        ORDER BY fecha ASC
    """)
    fun buscarCarreras(busqueda: String): LiveData<List<CarreraEntity>>

    @Query("SELECT * FROM carreras WHERE fecha BETWEEN :fechaInicio AND :fechaFin AND activa = 1 ORDER BY fecha ASC")
    fun obtenerCarrerasPorRangoFecha(fechaInicio: Long, fechaFin: Long): LiveData<List<CarreraEntity>>

    // Obtener carreras por lista de IDs
    @Query("SELECT * FROM carreras WHERE id IN (:ids) AND estado = 'PROXIMA' ORDER BY fecha ASC")
    suspend fun obtenerCarrerasPorIds(ids: List<Long>): List<CarreraEntity>



    // ========== CONSULTAS PARA PARTICIPANTES ==========

    /**
     * Obtiene carreras donde el participante NO tiene ninguna inscripción
     * Para mostrar en "Carreras Disponibles"
     */
    @Query("""
    SELECT * FROM carreras
    WHERE id NOT IN (
        SELECT DISTINCT carreraId 
        FROM inscripciones
        WHERE participanteId = :participanteId 
        AND activa = 1
    )
    AND estado = 'PROXIMA'
    AND activa = 1
    AND fecha >= :fechaActual
    AND cupos_disponibles > 0
    ORDER BY fecha ASC
""")
    fun obtenerCarrerasSinInscripcion(
        participanteId: Long,
        fechaActual: Long
    ): LiveData<List<CarreraEntity>>

    /**
     * Obtiene la próxima carrera donde el participante SÍ tiene inscripción
     * Para mostrar en "Tu Próxima Carrera"
     */
    @Query("""
    SELECT * FROM carreras 
    WHERE id IN (
        SELECT DISTINCT carreraId FROM inscripciones 
        WHERE participanteId = :participanteId AND activa = 1
    )
    AND estado = 'PROXIMA' 
    AND activa = 1 
    AND fecha >= :fechaActual
    ORDER BY fecha ASC
    LIMIT 1
""")
    fun obtenerProximaCarreraConInscripcion(participanteId: Long, fechaActual: Long): LiveData<CarreraEntity?>

    /**
     * Obtiene todas las carreras próximas donde el participante SÍ tiene inscripción
     * Para mostrar en "Mis Carreras" / "Ver todas mis próximas carreras"
     */
    @Query("""
    SELECT * FROM carreras 
    WHERE id IN (
        SELECT DISTINCT carreraId FROM inscripciones 
        WHERE participanteId = :participanteId AND activa = 1
    )
    AND estado = 'PROXIMA' 
    AND activa = 1 
    AND fecha >= :fechaActual
    ORDER BY fecha ASC
""")
    fun obtenerCarrerasInscritasProximas(participanteId: Long, fechaActual: Long): LiveData<List<CarreraEntity>>

    /**
     * Obtiene todas las carreras finalizadas donde el participante tuvo inscripción
     * Para mostrar en historial
     */
    @Query("""
    SELECT * FROM carreras 
    WHERE id IN (
        SELECT DISTINCT carreraId FROM inscripciones 
        WHERE participanteId = :participanteId AND activa = 1
    )
    AND estado = 'FINALIZADA' 
    AND activa = 1
    ORDER BY fecha DESC
""")
    fun obtenerCarrerasInscritasFinalizadas(participanteId: Long): LiveData<List<CarreraEntity>>

    /**
     * Obtiene TODAS las carreras donde el participante tiene inscripción (próximas + finalizadas)
     */
    @Query("""
    SELECT * FROM carreras 
    WHERE id IN (
        SELECT DISTINCT carreraId FROM inscripciones 
        WHERE participanteId = :participanteId AND activa = 1
    )
    AND activa = 1
    ORDER BY fecha DESC
""")
    fun obtenerProximasCarrerasParticipanteInscritas(participanteId: Long): LiveData<List<CarreraEntity>>

    @Query("""
    SELECT * FROM carreras 
    WHERE estado = 'PROXIMA' 
    AND activa = 1
    AND fecha >= :fechaActual
    ORDER BY fecha ASC
""")
    fun obtenerCarrerasDisponibles(
        fechaActual: Long = System.currentTimeMillis()
    ): LiveData<List<CarreraEntity>>

}
