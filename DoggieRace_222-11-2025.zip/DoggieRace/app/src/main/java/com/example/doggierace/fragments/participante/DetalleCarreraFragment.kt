package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.adapters.PerroInscritoAdapter
import com.example.doggierace.databinding.FragmentDetalleCarreraBinding
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.utils.ImageHelper
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.CarreraViewModel
import com.example.doggierace.viewmodels.InscripcionViewModel
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class DetalleCarreraFragment : Fragment() {

    private var _binding: FragmentDetalleCarreraBinding? = null
    private val binding get() = _binding!!

    private val carreraViewModel: CarreraViewModel by viewModels()
    private val inscripcionViewModel: InscripcionViewModel by viewModels()
    private val args: DetalleCarreraFragmentArgs by navArgs()

    private lateinit var sessionManager: SessionManager
    private lateinit var perroAdapter: PerroInscritoAdapter

    private var carreraActual: CarreraEntity? = null
    private var participanteId: Long = 0L

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetalleCarreraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())
        participanteId = sessionManager.obtenerUserId()

        setupToolbar()
        configurarRecyclerView()
        cargarDetalleCarrera()
        setupClickListeners()
    }

    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun configurarRecyclerView() {
        perroAdapter = PerroInscritoAdapter()
        binding.rvPerrosInscritos.adapter = perroAdapter
    }

    private fun cargarDetalleCarrera() {
        val carreraId = args.carreraId

        carreraViewModel.cargarCarreraPorId(carreraId)

        carreraViewModel.carreraActual.observe(viewLifecycleOwner) { carrera ->
            if (carrera != null) {
                carreraActual = carrera
                mostrarDetalles(carrera)
                cargarPerrosInscritos(carrera.id)
            } else {
                Toast.makeText(requireContext(), "Carrera no encontrada", Toast.LENGTH_LONG).show()
                findNavController().popBackStack()
            }
        }
    }


    private fun cargarPerrosInscritos(carreraId: Long) {
        // ✅ Usar coroutine (suspend) en vez de LiveData
        lifecycleScope.launch {
            val mascotas = inscripcionViewModel.obtenerMascotasInscritasSync(carreraId, participanteId)
            if (mascotas.isNotEmpty()) {
                binding.tvPerrosInscritos.visibility = View.VISIBLE
                binding.rvPerrosInscritos.visibility = View.VISIBLE
                perroAdapter.submitList(mascotas)
            } else {
                binding.tvPerrosInscritos.visibility = View.GONE
                binding.rvPerrosInscritos.visibility = View.GONE
            }
        }
    }



    private fun mostrarDetalles(carrera: CarreraEntity) {
        // Título
        binding.toolbar.title = carrera.nombre
        binding.tvTituloCarrera.text = carrera.nombre

        // Fecha y hora
        val formatoFecha = SimpleDateFormat("dd 'de' MMMM, yyyy", Locale.forLanguageTag("es-ES"))
        val fechaTexto = "${formatoFecha.format(Date(carrera.fecha))} - ${carrera.horaInicio}"
        binding.tvFechaDetalle.text = fechaTexto

        // Lugar
        val lugarCompleto = if (carrera.ciudad.isNotEmpty() && carrera.ciudad != "Ciudad") {
            "${carrera.ubicacion}, ${carrera.ciudad}"
        } else {
            carrera.ubicacion
        }
        binding.tvLugarDetalle.text = lugarCompleto

        // Tipo de carrera (Obstáculos, Paseos, Trineos, Canicross)
        binding.tvTipoCarrera.text = carrera.categoria

        // Categorías de perros permitidos (por ahora siempre todas)
        binding.tvCategorias.text = """• Pequeña (hasta 15 kg)
• Mediana (15-30 kg)
• Grande (30-45 kg)
• XL (más de 45 kg)"""

        // Requisitos
        if (!carrera.requisitos.isNullOrEmpty()) {
            binding.tvRequisitos.text = carrera.requisitos
        } else {
            binding.tvRequisitos.text = "• Vacunas al día\n• Certificado de salud"
        }

        // Descripción/Seguridad
        binding.tvSeguridad.text = carrera.descripcion.ifEmpty {
            "Veterinario en sitio y puntos de hidratación"
        }

        // Costo
        val formatoPrecio = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
        val precioTexto = if (carrera.precioInscripcion > 0) {
            "${formatoPrecio.format(carrera.precioInscripcion)} por perro"
        } else {
            "Gratis"
        }
        binding.tvCosto.text = precioTexto

        // Cupos disponibles
        val cuposTexto = "${carrera.cuposDisponibles} cupos disponibles de ${carrera.cuposTotales}"
        binding.tvCuposDisponibles.text = cuposTexto

        // ========== CARGAR IMAGEN DEL CIRCUITO ==========
        carrera.imagenUri?.let { path ->
            val bitmap = ImageHelper.cargarImagenDesdePath(path)
            if (bitmap != null) {
                binding.imgMapaEstatico.setImageBitmap(bitmap)
                binding.imgMapaEstatico.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            } else {
                // Mostrar placeholder si no se puede cargar
                binding.imgMapaEstatico.setImageResource(android.R.drawable.ic_menu_gallery)
                binding.imgMapaEstatico.scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            }
        } ?: run {
            // No hay imagen guardada - mostrar placeholder
            binding.imgMapaEstatico.setImageResource(android.R.drawable.ic_menu_gallery)
            binding.imgMapaEstatico.scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
        }

        // Estado del botón según cupos
        actualizarEstadoBoton(carrera)
    }



    private fun actualizarEstadoBoton(carrera: CarreraEntity) {
        lifecycleScope.launch {
            // Verificar si ya tiene inscripciones
            val tieneInscripciones = inscripcionViewModel.participanteTieneInscripcion(
                carrera.id,
                participanteId
            )

            if (tieneInscripciones) {
                // Ya tiene mascotas inscritas
                val cantidad = inscripcionViewModel.contarInscripcionesDeParticipante(
                    carrera.id,
                    participanteId
                )

                binding.btnInscribirPerro.isEnabled = true
                binding.btnInscribirPerro.text = if (cantidad == 1) {
                    "Mis Inscripciones (1 mascota)"
                } else {
                    "Mis Inscripciones ($cantidad mascotas)"
                }

                binding.btnInscribirPerro.setOnClickListener {
                    // Mostrar/Ocultar lista de inscritos
                    if (binding.rvPerrosInscritos.visibility == View.VISIBLE) {
                        binding.rvPerrosInscritos.visibility = View.GONE
                        binding.tvPerrosInscritos.visibility = View.GONE
                    } else {
                        binding.rvPerrosInscritos.visibility = View.VISIBLE
                        binding.tvPerrosInscritos.visibility = View.VISIBLE
                        cargarPerrosInscritos(carrera.id)
                    }
                }
            } else {
                // No tiene inscripciones - Permitir inscribir
                if (carrera.cuposDisponibles <= 0) {
                    binding.btnInscribirPerro.isEnabled = false
                    binding.btnInscribirPerro.text = "Sin cupos disponibles"
                } else if (carrera.estado != CarreraEntity.ESTADO_PROXIMA) {
                    binding.btnInscribirPerro.isEnabled = false
                    binding.btnInscribirPerro.text = "Inscripciones cerradas"
                } else {
                    binding.btnInscribirPerro.isEnabled = true
                    binding.btnInscribirPerro.text = "Inscribir Mascota"

                    binding.btnInscribirPerro.setOnClickListener {
                        inscribirPerro(carrera)
                    }
                }
            }
        }
    }


    private fun setupClickListeners() {
        binding.btnInscribirPerro.setOnClickListener {
            carreraActual?.let { carrera ->
                if (carrera.cuposDisponibles > 0) {
                    inscribirPerro(carrera)
                } else {
                    Toast.makeText(
                        requireContext(),
                        "No hay cupos disponibles",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun inscribirPerro(carrera: CarreraEntity) {
        // Navegar a la pantalla de selección de mascota
        val action = DetalleCarreraFragmentDirections
            .accionDetalleAInscribir(
                carreraId = carrera.id.toLong(),
                carreraNombre = carrera.nombre
            )
        findNavController().navigate(action)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
