package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.adapters.MisMascotasAdapter
import com.example.doggierace.databinding.FragmentInscribirMascotaBinding
import com.example.doggierace.data.entities.MascotaEntity
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.MascotaViewModel
import com.example.doggierace.viewmodels.InscripcionViewModel

class InscribirMascotaFragment : Fragment() {

    private var _binding: FragmentInscribirMascotaBinding? = null
    private val binding get() = _binding!!

    private val mascotaViewModel: MascotaViewModel by viewModels()
    private val inscripcionViewModel: InscripcionViewModel by viewModels()
    private val args: InscribirMascotaFragmentArgs by navArgs()

    private lateinit var sessionManager: SessionManager
    private lateinit var mascotasAdapter: MisMascotasAdapter

    private var carreraId: String = ""
    private var carreraNombre: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInscribirMascotaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())
        carreraId = args.carreraId.toString()
        carreraNombre = args.carreraNombre

        setupToolbar()
        configurarRecyclerView()
        cargarMascotas()
    }

    private fun setupToolbar() {
        binding.toolbar.title = "Seleccionar Mascota"
        binding.toolbar.subtitle = carreraNombre
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun configurarRecyclerView() {
        mascotasAdapter = MisMascotasAdapter(
            onItemClick = { },
            onEditClick = null,
            onDeleteClick = null,
            onInscribirClick = { mascota ->
                mostrarDialogoCategoria(mascota)
            },
            modoInscripcion = true
        )

        binding.rvMascotas.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = mascotasAdapter
            setHasFixedSize(true)
        }
    }

    private fun cargarMascotas() {
        val participanteId = sessionManager.obtenerUserId()

        if (participanteId == -1L) {
            Toast.makeText(requireContext(), "Error: No hay sesión activa", Toast.LENGTH_SHORT).show()
            findNavController().popBackStack()
            return
        }

        mascotaViewModel.obtenerMascotasDeParticipanteLiveData(participanteId)
            .observe(viewLifecycleOwner) { mascotas ->
                if (mascotas.isEmpty()) {
                    mostrarEstadoVacio()
                } else {
                    mostrarMascotas(mascotas)
                }
            }
    }

    private fun mostrarMascotas(mascotas: List<MascotaEntity>) {
        binding.rvMascotas.visibility = View.VISIBLE
        binding.layoutVacio.visibility = View.GONE
        mascotasAdapter.submitList(mascotas)
    }

    private fun mostrarEstadoVacio() {
        binding.rvMascotas.visibility = View.GONE
        binding.layoutVacio.visibility = View.VISIBLE
    }

    private fun mostrarDialogoCategoria(mascota: MascotaEntity) {
        val categoria = when {
            mascota.peso <= 15 -> "Pequeña"
            mascota.peso <= 30 -> "Mediana"
            mascota.peso <= 45 -> "Grande"
            else -> "XL"
        }

        val mensaje = """
            ¿Inscribir a ${mascota.nombre} en esta carrera?
            
            Categoría: $categoria (${mascota.peso} kg)
        """.trimIndent()

        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Confirmar Inscripción")
            .setMessage(mensaje)
            .setPositiveButton("Inscribir") { _, _ ->
                inscribirMascota(mascota, categoria)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun inscribirMascota(mascota: MascotaEntity, categoria: String) {
        val participanteId = sessionManager.obtenerUserId()

        binding.progressBar.visibility = View.VISIBLE

        inscripcionViewModel.inscribirMascota(
            carreraId = carreraId.toLong(),  // ✅ CONVERSIÓN AQUÍ
            mascotaId = mascota.id,
            participanteId = participanteId,
            categoria = categoria,
            onSuccess = { inscripcionId ->
                binding.progressBar.visibility = View.GONE
                Toast.makeText(
                    requireContext(),
                    "¡${mascota.nombre} inscrito exitosamente!",
                    Toast.LENGTH_SHORT
                ).show()
                findNavController().popBackStack()
            },
            onError = { mensaje ->
                binding.progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), mensaje, Toast.LENGTH_LONG).show()
            }
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
