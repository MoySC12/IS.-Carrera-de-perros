package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.doggierace.databinding.FragmentControlCategoriaBinding
import com.example.doggierace.R

class ControlCategoriaFragment : Fragment() {

    private var _binding: FragmentControlCategoriaBinding? = null
    private val binding get() = _binding!!

    // Argumentos recibidos del navigation
    private var categoriaId: String? = null
    private var categoriaNombre: String? = null
    private var carreraNombre: String? = null
    private var horaSalida: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Obtener argumentos (cuando implementes SafeArgs)
        arguments?.let {
            categoriaId = it.getString("categoriaId")
            categoriaNombre = it.getString("categoriaNombre")
            carreraNombre = it.getString("carreraNombre")
            horaSalida = it.getString("horaSalida")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentControlCategoriaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        // Configurar Toolbar con botón de regreso
        binding.toolbar.setupWithNavController(navController)

        // Cargar datos en la vista
        cargarDatosCategoria()

        // Configurar listeners de botones
        setupClickListeners()
    }

    private fun cargarDatosCategoria() {
        // Datos de prueba (o desde argumentos)
        binding.tvCarreraNombre.text = carreraNombre ?: "Carrera del Bosque"
        binding.tvCategoriaNombre.text = "Categoría: ${categoriaNombre ?: "Razas Pequeñas"}"
        binding.tvCategoriaHora.text = "⏰ Hora de Salida: ${horaSalida ?: "9:00 AM"}"
    }

    private fun setupClickListeners() {
        val navController = findNavController()

        // Botón: Asistencia y Tiempos (RF5)
        binding.btnAsistenciaTiempos.setOnClickListener {
            val bundle = Bundle().apply {
                putString("categoriaId", categoriaId)
                putString("categoriaNombre", categoriaNombre)
                putString("carreraNombre", carreraNombre)
                putString("horaSalida", horaSalida)
            }

            navController.navigate(R.id.fragmentAsistenciaTiempos, bundle)
        }

        // Botón: Premiación (RF6)
        binding.btnPremiacion.setOnClickListener {
            val bundle = Bundle().apply {
                putString("categoriaId", categoriaId)
                putString("categoriaNombre", categoriaNombre)
                putString("carreraNombre", carreraNombre)
                putString("horaSalida", horaSalida)
            }

            navController.navigate(R.id.fragmentPremiacion, bundle)
        }

        // Botón: Finalizar Categoría
        binding.btnFinalizarCategoria.setOnClickListener {
            mostrarDialogoFinalizarCategoria()
        }
    }


    private fun mostrarDialogoFinalizarCategoria() {
        AlertDialog.Builder(requireContext())
            .setTitle("¿Finalizar Categoría?")
            .setMessage("Esta acción marcará la categoría como completada y la moverá al historial. ¿Estás seguro?")
            .setPositiveButton("Confirmar") { dialog, _ ->
                // Marcar categoría como finalizada (aquí guardarías en BD)
                Toast.makeText(
                    requireContext(),
                    "Categoría Finalizada",
                    Toast.LENGTH_SHORT
                ).show()

                dialog.dismiss()

                // Volver a la pantalla anterior (Carrera en Vivo)
                findNavController().popBackStack()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
