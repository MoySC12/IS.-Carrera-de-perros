package com.example.doggierace.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "carreras",
    foreignKeys = [
        ForeignKey(
            entity = AdministradorEntity::class,
            parentColumns = ["id"],
            childColumns = ["organizador_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["organizador_id"]),
        Index(value = ["fecha"]),
        Index(value = ["estado"])
    ]
)
data class CarreraEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,

    @ColumnInfo(name = "organizador_id")
    val organizadorId: Long,

    @ColumnInfo(name = "nombre")
    val nombre: String,

    @ColumnInfo(name = "descripcion")
    val descripcion: String,

    @ColumnInfo(name = "fecha")
    val fecha: Long, // Timestamp de la fecha del carrra

    @ColumnInfo(name = "hora_inicio")
    val horaInicio: String, // Ejemplo: "09:00"

    @ColumnInfo(name = "ubicacion")
    val ubicacion: String,

    @ColumnInfo(name = "direccion")
    val direccion: String,

    @ColumnInfo(name = "ciudad")
    val ciudad: String,

    @ColumnInfo(name = "categoria")
    val categoria: String, // "Pequeña", "Mediana", "Grande", "XL", "Todas"

    @ColumnInfo(name = "precio_inscripcion")
    val precioInscripcion: Double,

    @ColumnInfo(name = "cupos_totales")
    val cuposTotales: Int,

    @ColumnInfo(name = "cupos_disponibles")
    val cuposDisponibles: Int,

    @ColumnInfo(name = "estado")
    val estado: String, // "PROXIMA", "EN_CURSO", "FINALIZADA", "CANCELADA"

    @ColumnInfo(name = "imagen_uri")
    val imagenUri: String? = null,

    @ColumnInfo(name = "requisitos")
    val requisitos: String? = null, // Requisitos adicionales

    @ColumnInfo(name = "premios")
    val premios: String? = null, // Descripción de premios

    @ColumnInfo(name = "distancia_metros")
    val distanciaMetros: Int? = null, // Longitud de la pista

    @ColumnInfo(name = "total_inscritos")
    val totalInscritos: Int = 0,

    @ColumnInfo(name = "fecha_creacion")
    val fechaCreacion: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "fecha_limite_inscripcion")
    val fechaLimiteInscripcion: Long? = null,

    @ColumnInfo(name = "activa")
    val activa: Boolean = true
) {
    companion object {
        const val ESTADO_PROXIMA = "PROXIMA"
        const val ESTADO_EN_CURSO = "EN_CURSO"
        const val ESTADO_FINALIZADA = "FINALIZADA"
        const val ESTADO_CANCELADA = "CANCELADA"

        const val CATEGORIA_PEQUENA = "Pequeña"
        const val CATEGORIA_MEDIANA = "Mediana"
        const val CATEGORIA_GRANDE = "Grande"
        const val CATEGORIA_XL = "XL"
        const val CATEGORIA_TODAS = "Todas"
    }
}
