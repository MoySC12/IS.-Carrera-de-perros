package com.example.doggierace.fragments.participante

import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController  // ✅ AGREGAR
import androidx.navigation.ui.setupWithNavController   // ✅ AGREGAR
import com.example.doggierace.databinding.FragmentEditarPerfilParticipanteBinding


class EditarPerfilParticipanteFragment : Fragment() {

    private var _binding: FragmentEditarPerfilParticipanteBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditarPerfilParticipanteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupClickListeners()
        cargarDatosUsuario()
    }

    // ✅ Agregar este método
    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupClickListeners() {
        // Botón: Editar Foto
        binding.btnEditarFoto.setOnClickListener {
            Toast.makeText(
                requireContext(),
                "Función 'Editar Foto' en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
            // TODO: Implementar selección de imagen de galería o cámara
        }

        // Botón: Guardar Cambios
        binding.btnGuardarCambios.setOnClickListener {
            guardarCambios()
        }
    }

    private fun cargarDatosUsuario() {
        // TODO: Cargar datos reales del usuario desde base de datos/API
        // Por ahora usamos datos de prueba
        binding.etNombre.setText("Carlos")
        binding.etApellidos.setText("Rodríguez García")
        binding.etCorreo.setText("carlos.rodriguez@ejemplo.com")
    }

    private fun guardarCambios() {
        // Obtener valores de los campos
        val nombre = binding.etNombre.text.toString().trim()
        val apellidos = binding.etApellidos.text.toString().trim()
        val correo = binding.etCorreo.text.toString().trim()
        val passActual = binding.etPassActual.text.toString()
        val passNueva = binding.etPassNueva.text.toString()
        val passConfirmar = binding.etPassConfirmar.text.toString()

        // Validar campos obligatorios
        if (nombre.isEmpty()) {
            binding.inputLayoutNombre.error = "El nombre es obligatorio"
            return
        } else {
            binding.inputLayoutNombre.error = null
        }

        if (apellidos.isEmpty()) {
            binding.inputLayoutApellidos.error = "Los apellidos son obligatorios"
            return
        } else {
            binding.inputLayoutApellidos.error = null
        }

        if (correo.isEmpty()) {
            binding.inputLayoutCorreo.error = "El correo es obligatorio"
            return
        } else {
            binding.inputLayoutCorreo.error = null
        }

        // Validar formato de correo
        if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
            binding.inputLayoutCorreo.error = "Correo inválido"
            return
        } else {
            binding.inputLayoutCorreo.error = null
        }

        // Validar cambio de contraseña (si se están llenando los campos)
        if (passActual.isNotEmpty() || passNueva.isNotEmpty() || passConfirmar.isNotEmpty()) {
            if (passActual.isEmpty()) {
                binding.inputLayoutPassActual.error = "Ingresa tu contraseña actual"
                return
            } else {
                binding.inputLayoutPassActual.error = null
            }

            if (passNueva.isEmpty()) {
                binding.inputLayoutPassNueva.error = "Ingresa una nueva contraseña"
                return
            } else {
                binding.inputLayoutPassNueva.error = null
            }

            if (passNueva.length < 6) {
                binding.inputLayoutPassNueva.error = "Mínimo 6 caracteres"
                return
            } else {
                binding.inputLayoutPassNueva.error = null
            }

            if (passConfirmar.isEmpty()) {
                binding.inputLayoutPassConfirmar.error = "Confirma tu nueva contraseña"
                return
            } else {
                binding.inputLayoutPassConfirmar.error = null
            }

            if (passNueva != passConfirmar) {
                binding.inputLayoutPassConfirmar.error = "Las contraseñas no coinciden"
                return
            } else {
                binding.inputLayoutPassConfirmar.error = null
            }
        }

        // TODO: Guardar cambios en base de datos/API
        Toast.makeText(
            requireContext(),
            "Cambios guardados exitosamente",
            Toast.LENGTH_SHORT
        ).show()

        // Limpiar campos de contraseña después de guardar
        binding.etPassActual.text?.clear()
        binding.etPassNueva.text?.clear()
        binding.etPassConfirmar.text?.clear()

        // Opcional: Regresar a la pantalla anterior
        // findNavController().navigateUp()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


}
