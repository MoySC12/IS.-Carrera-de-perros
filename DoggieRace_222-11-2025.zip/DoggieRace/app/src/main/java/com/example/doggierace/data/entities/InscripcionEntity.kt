package com.example.doggierace.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "inscripciones",
    foreignKeys = [
        ForeignKey(
            entity = CarreraEntity::class,
            parentColumns = ["id"],
            childColumns = ["carreraId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = MascotaEntity::class,
            parentColumns = ["id"],
            childColumns = ["mascotaId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ParticipanteEntity::class,  // ⬅️ CAMBIAR A ParticipanteEntity
            parentColumns = ["id"],
            childColumns = ["participanteId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        androidx.room.Index(value = ["carreraId"]),
        androidx.room.Index(value = ["mascotaId"]),
        androidx.room.Index(value = ["participanteId"])
    ]
)
data class InscripcionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "carreraId")
    val carreraId: Long,

    @ColumnInfo(name = "mascotaId")
    val mascotaId: Long,

    @ColumnInfo(name = "participanteId")
    val participanteId: Long,

    @ColumnInfo(name = "fechaInscripcion")
    val fechaInscripcion: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "estadoPago")
    val estadoPago: String = ESTADO_PENDIENTE,

    @ColumnInfo(name = "numeroParticipante")
    val numeroParticipante: Int = 0,

    @ColumnInfo(name = "categoria")
    val categoria: String = "",

    @ColumnInfo(name = "activa")
    val activa: Boolean = true
) {
    companion object {
        const val ESTADO_PENDIENTE = "PENDIENTE"
        const val ESTADO_PAGADO = "PAGADO"
        const val ESTADO_CANCELADO = "CANCELADO"
    }
}
