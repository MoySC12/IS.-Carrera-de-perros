package com.example.doggierace.data.repositories

import androidx.lifecycle.LiveData
import com.example.doggierace.data.dao.InscripcionDao
import com.example.doggierace.data.entities.InscripcionEntity
import com.example.doggierace.data.entities.MascotaEntity

class InscripcionRepository(private val inscripcionDao: InscripcionDao) {

    // ========== INSERTAR ==========

    suspend fun insertar(inscripcion: InscripcionEntity): Long {
        return inscripcionDao.insertar(inscripcion)
    }

    suspend fun insertarTodas(inscripciones: List<InscripcionEntity>) {
        inscripcionDao.insertarTodas(inscripciones)
    }

    // ========== ACTUALIZAR ==========

    suspend fun actualizar(inscripcion: InscripcionEntity) {
        inscripcionDao.actualizar(inscripcion)
    }

    suspend fun actualizarEstadoPago(inscripcionId: Long, estadoPago: String) {
        inscripcionDao.actualizarEstadoPago(inscripcionId, estadoPago)
    }

    suspend fun cancelarInscripcion(inscripcionId: Long) {
        inscripcionDao.actualizarEstado(inscripcionId, false)
    }

    // ========== ELIMINAR ==========

    suspend fun eliminar(inscripcion: InscripcionEntity) {
        inscripcionDao.eliminar(inscripcion)
    }

    suspend fun eliminarPorId(inscripcionId: Long) {
        inscripcionDao.eliminarPorId(inscripcionId)
    }

    // ========== CONSULTAS BÁSICAS ==========

    suspend fun obtenerPorId(inscripcionId: Long): InscripcionEntity? {
        return inscripcionDao.obtenerPorId(inscripcionId)
    }

    fun obtenerPorIdLiveData(inscripcionId: Long): LiveData<InscripcionEntity?> {
        return inscripcionDao.obtenerPorIdLiveData(inscripcionId)
    }

    fun obtenerTodasActivas(): LiveData<List<InscripcionEntity>> {
        return inscripcionDao.obtenerTodasActivas()
    }

    // ========== CONSULTAS POR PARTICIPANTE ==========

    fun obtenerInscripcionesDeParticipante(participanteId: Long): LiveData<List<InscripcionEntity>> {
        return inscripcionDao.obtenerInscripcionesDeParticipante(participanteId)
    }

    suspend fun obtenerInscripcionesDeParticipanteSync(participanteId: Long): List<InscripcionEntity> {
        return inscripcionDao.obtenerInscripcionesDeParticipanteSync(participanteId)
    }

    // ========== CONSULTAS POR CARRERA ==========

    fun obtenerInscripcionesDeCarrera(carreraId: Long): LiveData<List<InscripcionEntity>> {
        return inscripcionDao.obtenerInscripcionesDeCarrera(carreraId)
    }

    suspend fun obtenerInscripcionesDeCarreraSync(carreraId: Long): List<InscripcionEntity> {
        return inscripcionDao.obtenerInscripcionesDeCarreraSync(carreraId)
    }

    suspend fun contarInscripcionesDeCarrera(carreraId: Long): Int {
        return inscripcionDao.contarInscripcionesDeCarrera(carreraId)
    }

    fun contarInscripcionesDeCarreraLiveData(carreraId: Long): LiveData<Int> {
        return inscripcionDao.contarInscripcionesDeCarreraLiveData(carreraId)
    }

    // ========== CONSULTAS POR MASCOTA ==========

    fun obtenerInscripcionesDeMascota(mascotaId: Long): LiveData<List<InscripcionEntity>> {
        return inscripcionDao.obtenerInscripcionesDeMascota(mascotaId)
    }

    suspend fun obtenerInscripcionesDeMascotaSync(mascotaId: Long): List<InscripcionEntity> {
        return inscripcionDao.obtenerInscripcionesDeMascotaSync(mascotaId)
    }

    // ========== VALIDACIONES ==========

    suspend fun existeInscripcion(carreraId: Long, mascotaId: Long): Boolean {
        return inscripcionDao.existeInscripcion(carreraId, mascotaId)
    }

    suspend fun participanteTieneInscripcion(carreraId: Long, participanteId: Long): Boolean {
        return inscripcionDao.participanteTieneInscripcion(carreraId, participanteId)
    }

    // ========== CONSULTAS COMBINADAS ==========

    suspend fun obtenerInscripcionesDeParticipanteEnCarrera(
        participanteId: Long,
        carreraId: Long
    ): List<InscripcionEntity> {
        return inscripcionDao.obtenerInscripcionesDeParticipanteEnCarrera(participanteId, carreraId)
    }

    suspend fun obtenerIdsCarrerasInscritas(participanteId: Long): List<Long> {
        return inscripcionDao.obtenerIdsCarrerasInscritas(participanteId)
    }

    fun obtenerIdsCarrerasInscritasLiveData(participanteId: Long): LiveData<List<Long>> {
        return inscripcionDao.obtenerIdsCarrerasInscritasLiveData(participanteId)
    }

    // ========== OBTENER MASCOTAS INSCRITAS ==========

    fun obtenerMascotasInscritasEnCarrera(carreraId: Long, participanteId: Long): LiveData<List<MascotaEntity>> {
        return inscripcionDao.obtenerMascotasInscritasEnCarrera(carreraId, participanteId)
    }
    // Agrega este método al final de InscripcionRepository.kt
    suspend fun obtenerMascotasInscritasSync(carreraId: Long, participanteId: Long): List<MascotaEntity> {
        return inscripcionDao.obtenerMascotasInscritasSync(carreraId, participanteId)
    }


}
