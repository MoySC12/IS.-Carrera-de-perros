package com.example.doggierace.fragments.organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doggierace.R
import com.example.doggierace.adapters.CarrerasFinalizadasAdapter
import com.example.doggierace.databinding.FragmentCarrerasFinalizadasOrganizadorBinding
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.utils.SessionManager
import com.example.doggierace.viewmodels.CarreraViewModel

class CarrerasFinalizadasFragment : Fragment() {

    private var _binding: FragmentCarrerasFinalizadasOrganizadorBinding? = null
    private val binding get() = _binding!!

    private val carreraViewModel: CarreraViewModel by viewModels()
    private lateinit var sessionManager: SessionManager
    private lateinit var adapter: CarrerasFinalizadasAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCarrerasFinalizadasOrganizadorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionManager = SessionManager(requireContext())

        setupToolbar()
        setupRecyclerView()
        cargarCarreras()
    }

    private fun setupToolbar() {
        val navController = findNavController()
        binding.toolbar.setupWithNavController(navController)
    }

    private fun setupRecyclerView() {
        adapter = CarrerasFinalizadasAdapter { carrera ->
            // Click en un ítem - Navegar a Evaluaciones
            navegarAEvaluaciones(carrera)
        }

        binding.rvCarrerasFinalizadas.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = this@CarrerasFinalizadasFragment.adapter
            setHasFixedSize(true)
        }
    }

    private fun cargarCarreras() {
        val organizadorId = sessionManager.obtenerUserId()

        if (organizadorId == -1L) {
            return
        }

        // Observar carreras del organizador con estado FINALIZADA
        carreraViewModel.obtenerCarrerasDeOrganizadorLiveData(organizadorId)
            .observe(viewLifecycleOwner) { proximasCarrerasParticipante ->
                // Filtrar solo las finalizadas
                val carrerasFinalizadas = proximasCarrerasParticipante.filter {
                    it.estado == CarreraEntity.ESTADO_FINALIZADA
                }.sortedByDescending { it.fecha } // Ordenar por fecha más reciente

                if (carrerasFinalizadas.isEmpty()) {
                    mostrarEstadoVacio()
                } else {
                    mostrarLista(carrerasFinalizadas)
                }
            }
    }

    private fun mostrarEstadoVacio() {
        binding.rvCarrerasFinalizadas.visibility = View.GONE
        // TODO: Agregar TextView o layout para estado vacío
    }

    private fun mostrarLista(carreras: List<CarreraEntity>) {
        binding.rvCarrerasFinalizadas.visibility = View.VISIBLE
        adapter.submitList(carreras)
    }

    private fun navegarAEvaluaciones(carrera: CarreraEntity) {
        Toast.makeText(
            requireContext(),
            "Ver evaluaciones de: ${carrera.nombre}",
            Toast.LENGTH_SHORT
        ).show()

        // Navegar a evaluaciones (cuando esté implementado)
        findNavController().navigate(R.id.action_carrerasFinalizadas_to_evaluaciones)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
