package com.example.doggierace

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.doggierace.databinding.ActivityRegistroBinding
import com.example.doggierace.data.entities.AdministradorEntity
import com.example.doggierace.data.entities.ParticipanteEntity
import com.example.doggierace.viewmodels.AdministradorViewModel
import com.example.doggierace.viewmodels.ParticipanteViewModel
import kotlinx.coroutines.launch

class RegistroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegistroBinding
    private val administradorViewModel: AdministradorViewModel by viewModels()
    private val participanteViewModel: ParticipanteViewModel by viewModels()

    private var tipoUsuarioSeleccionado: String = ""
    private val CODIGO_ORGANIZADOR_VALIDO = "ORG2025"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
        observarResultados()
    }

    private fun setupClickListeners() {
        binding.btnVolver.setOnClickListener {
            finish()
        }

        binding.cardParticipante.setOnClickListener {
            seleccionarTipoUsuario("PARTICIPANTE")
        }

        binding.cardOrganizador.setOnClickListener {
            seleccionarTipoUsuario("ORGANIZADOR")
        }

        binding.btnCrearCuenta.setOnClickListener {
            registrarUsuario()
        }
    }

    private fun seleccionarTipoUsuario(tipo: String) {
        tipoUsuarioSeleccionado = tipo

        if (tipo == "PARTICIPANTE") {
            binding.cardParticipante.setCardBackgroundColor(getColor(R.color.verde_primario))
            binding.cardOrganizador.setCardBackgroundColor(getColor(R.color.blanco))
            ocultarCampoCodigoOrganizador()
        } else {
            binding.cardOrganizador.setCardBackgroundColor(getColor(R.color.verde_primario))
            binding.cardParticipante.setCardBackgroundColor(getColor(R.color.blanco))
            mostrarCampoCodigoOrganizador()
        }
    }

    private fun mostrarCampoCodigoOrganizador() {
        binding.labelCodigoOrganizador.visibility = View.VISIBLE
        binding.tilCodigoOrganizador.visibility = View.VISIBLE
        binding.tvInfoCodigo.visibility = View.VISIBLE
    }

    private fun ocultarCampoCodigoOrganizador() {
        binding.labelCodigoOrganizador.visibility = View.GONE
        binding.tilCodigoOrganizador.visibility = View.GONE
        binding.tvInfoCodigo.visibility = View.GONE
        binding.etCodigoOrganizador.setText("")
    }

    private fun registrarUsuario() {
        val nombre = binding.etNombre.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val codigoOrganizador = binding.etCodigoOrganizador.text.toString().trim()

        if (!validarCampos(nombre, email, password, codigoOrganizador)) {
            return
        }

        lifecycleScope.launch {
            // Verificar email en ambas tablas
            val emailExisteAdmin = administradorViewModel.verificarEmailExistente(email)
            val emailExisteParticipante = participanteViewModel.verificarEmailExistente(email)

            if (emailExisteAdmin || emailExisteParticipante) {
                Toast.makeText(
                    this@RegistroActivity,
                    "Este email ya está registrado",
                    Toast.LENGTH_SHORT
                ).show()
                binding.etEmail.error = "Email ya registrado"
            } else {
                when (tipoUsuarioSeleccionado) {
                    "ORGANIZADOR" -> registrarOrganizador(nombre, email, password, codigoOrganizador)
                    "PARTICIPANTE" -> registrarParticipante(nombre, email, password)
                }
            }
        }
    }

    private fun registrarOrganizador(nombre: String, email: String, password: String, codigo: String) {
        val nuevoAdmin = AdministradorEntity(
            email = email,
            password = password,
            nombre = nombre,
            codigoVerificacion = codigo
        )
        administradorViewModel.insertarAdministrador(nuevoAdmin)
    }

    private fun registrarParticipante(nombre: String, email: String, password: String) {
        val nuevoParticipante = ParticipanteEntity(
            email = email,
            password = password,
            nombre = nombre
        )
        participanteViewModel.insertarParticipante(nuevoParticipante)
    }

    private fun observarResultados() {
        // Observar resultados de administrador
        administradorViewModel.resultadoOperacion.observe(this) { resultado ->
            when (resultado) {
                is AdministradorViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(
                        this,
                        "Cuenta de organizador creada exitosamente",
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                }
                is AdministradorViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(this, resultado.mensaje, Toast.LENGTH_LONG).show()
                }
            }
        }

        // Observar resultados de participante
        participanteViewModel.resultadoOperacion.observe(this) { resultado ->
            when (resultado) {
                is ParticipanteViewModel.ResultadoOperacion.Exito -> {
                    Toast.makeText(
                        this,
                        "Cuenta de participante creada exitosamente",
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                }
                is ParticipanteViewModel.ResultadoOperacion.Error -> {
                    Toast.makeText(this, resultado.mensaje, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun validarCampos(
        nombre: String,
        email: String,
        password: String,
        codigoOrganizador: String
    ): Boolean {

        if (nombre.isEmpty()) {
            binding.etNombre.error = "Ingresa tu nombre completo"
            Toast.makeText(this, "Por favor ingresa tu nombre completo", Toast.LENGTH_SHORT).show()
            return false
        }

        if (email.isEmpty()) {
            binding.etEmail.error = "Ingresa tu correo"
            Toast.makeText(this, "Por favor ingresa tu correo electrónico", Toast.LENGTH_SHORT).show()
            return false
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Correo inválido"
            Toast.makeText(this, "Por favor ingresa un correo válido", Toast.LENGTH_SHORT).show()
            return false
        }

        if (password.isEmpty()) {
            binding.etPassword.error = "Ingresa una contraseña"
            Toast.makeText(this, "Por favor ingresa una contraseña", Toast.LENGTH_SHORT).show()
            return false
        }

        if (password.length < 6) {
            binding.etPassword.error = "Mínimo 6 caracteres"
            Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show()
            return false
        }

        if (tipoUsuarioSeleccionado.isEmpty()) {
            Toast.makeText(this, "Por favor selecciona el tipo de usuario", Toast.LENGTH_SHORT).show()
            return false
        }

        if (tipoUsuarioSeleccionado == "ORGANIZADOR") {
            if (codigoOrganizador.isEmpty()) {
                binding.etCodigoOrganizador.error = "Ingresa el código"
                Toast.makeText(this, "Por favor ingresa el código de organizador", Toast.LENGTH_SHORT).show()
                return false
            }

            if (codigoOrganizador != CODIGO_ORGANIZADOR_VALIDO) {
                binding.etCodigoOrganizador.error = "Código inválido"
                Toast.makeText(this, "Código de organizador inválido", Toast.LENGTH_LONG).show()
                return false
            }
        }

        return true
    }
}
