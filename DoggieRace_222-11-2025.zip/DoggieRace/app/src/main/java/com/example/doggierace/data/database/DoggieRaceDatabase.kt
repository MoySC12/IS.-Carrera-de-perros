package com.example.doggierace.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.doggierace.data.entities.AdministradorEntity
import com.example.doggierace.data.entities.ParticipanteEntity
import com.example.doggierace.data.entities.MascotaEntity
import com.example.doggierace.data.entities.CarreraEntity
import com.example.doggierace.data.entities.InscripcionEntity  // ⬅️ AGREGAR
import com.example.doggierace.data.dao.AdministradorDao
import com.example.doggierace.data.dao.ParticipanteDao
import com.example.doggierace.data.dao.MascotaDao
import com.example.doggierace.data.dao.CarreraDao
import com.example.doggierace.data.dao.InscripcionDao  // ⬅️ AGREGAR

@Database(
    entities = [
        AdministradorEntity::class,
        ParticipanteEntity::class,
        MascotaEntity::class,
        CarreraEntity::class,
        InscripcionEntity::class  // ⬅️ AGREGAR
    ],
    version = 7,  // ⬅️ INCREMENTAR A 7
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class DoggieRaceDatabase : RoomDatabase() {

    abstract fun administradorDao(): AdministradorDao
    abstract fun participanteDao(): ParticipanteDao
    abstract fun mascotaDao(): MascotaDao
    abstract fun carreraDao(): CarreraDao
    abstract fun inscripcionDao(): InscripcionDao  // ⬅️ AGREGAR

    companion object {
        @Volatile
        private var INSTANCE: DoggieRaceDatabase? = null

        fun getDatabase(context: Context): DoggieRaceDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DoggieRaceDatabase::class.java,
                    "doggierace_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
